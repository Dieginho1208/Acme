"""Runtime configuration.

The only setting is the database file. By default the application uses
``inventory_mock.db`` in the project folder; set the ``ACME_DB`` environment
variable (or pass ``--db`` on the command line) to use another file.
"""

import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DB_NAME = "inventory_mock.db"


def default_db_path() -> Path:
    """Database path from ``ACME_DB`` or the default mock database."""
    return Path(os.environ.get("ACME_DB") or PROJECT_ROOT / DEFAULT_DB_NAME)
