"""Acme Logistics Suite.

A desktop inventory, dispatch, billing and accounts-receivable system built with
Python, Tkinter and SQLite. The package is split into two layers:

* :mod:`acme.core` -- the model: database access and every business rule.
  It never imports Tkinter, so it can be unit tested and reused headless.
* :mod:`acme.ui` -- the views and their controllers, written with Tkinter/ttk.
"""

__version__ = "1.0.0"
APP_NAME = "Acme Logistics Suite"
