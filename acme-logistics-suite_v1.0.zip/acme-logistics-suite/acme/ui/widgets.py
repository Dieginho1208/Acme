"""Reusable widgets: data tables, cards, KPI tiles, form dialogs and background tasks."""

import datetime as dt
import queue
import threading
import tkinter as tk
from dataclasses import dataclass, field
from tkinter import messagebox, ttk
from typing import Any, Callable, Optional, Sequence

from acme.core.errors import BusinessRuleError
from acme.ui.theme import COLORS, FONTS, STATUS_COLORS


# --------------------------------------------------------------------------- background work
def run_in_background(widget: tk.Misc, work: Callable[[], Any],
                      on_done: Callable[[Any], None],
                      on_error: Optional[Callable[[Exception], None]] = None) -> None:
    """Run ``work()`` in a thread and deliver its result on the Tk main thread.

    Tkinter is not thread safe, so the worker never touches widgets: it puts
    the outcome in a queue that the main loop polls with ``after()``.
    """
    results: queue.Queue = queue.Queue(maxsize=1)

    def worker() -> None:
        try:
            results.put((True, work()))
        except Exception as exc:  # noqa: BLE001 - reported to the UI below
            results.put((False, exc))

    def poll() -> None:
        try:
            ok, value = results.get_nowait()
        except queue.Empty:
            widget.after(40, poll)
            return
        if ok:
            on_done(value)
        elif on_error:
            on_error(value)
        else:
            show_error(widget, value)

    threading.Thread(target=worker, daemon=True).start()
    widget.after(40, poll)


def show_error(parent: tk.Misc, exc: Exception) -> None:
    """Show a business error as-is, or a generic message for unexpected errors."""
    if isinstance(exc, BusinessRuleError):
        messagebox.showwarning("Not possible", str(exc), parent=parent)
    else:
        messagebox.showerror("Unexpected error",
                             f"Something went wrong:\n\n{type(exc).__name__}: {exc}",
                             parent=parent)


def parse_date(text: str, what: str = "the date") -> dt.date:
    """Parse ``YYYY-MM-DD`` or raise a user-facing error."""
    try:
        return dt.date.fromisoformat((text or "").strip())
    except ValueError as exc:
        raise BusinessRuleError(f"Please enter {what} as YYYY-MM-DD.") from exc


# --------------------------------------------------------------------------- data table
@dataclass
class Column:
    """Column of a :class:`DataTable`."""

    key: str
    title: str
    width: int = 110
    anchor: str = "w"
    fmt: Optional[Callable[[Any], str]] = None
    stretch: bool = False


class DataTable(ttk.Frame):
    """A ``ttk.Treeview`` with typed columns, zebra rows, status colors and sorting.

    Args:
        columns: the :class:`Column` definitions.
        key: row field used as the item id (``None`` uses the row position).
        row_style: optional ``row -> status`` function; the status picks a color
            from :data:`~acme.ui.theme.STATUS_COLORS`.
        on_select / on_activate: callbacks for selection and double-click/Enter.
    """

    def __init__(self, parent, columns: Sequence[Column], height: int = 12,
                 key: Optional[str] = "id", row_style: Optional[Callable] = None,
                 on_select: Optional[Callable] = None, on_activate: Optional[Callable] = None,
                 selectmode: str = "browse"):
        super().__init__(parent, style="Surface.TFrame")
        self.columns = list(columns)
        self.key = key
        self.row_style = row_style
        self._rows: dict = {}
        self._order: list = []
        self._sort = (None, False)
        self.tree = ttk.Treeview(self, columns=[c.key for c in self.columns], show="headings",
                                 height=height, selectmode=selectmode)
        for col in self.columns:
            self.tree.heading(col.key, text=col.title, anchor=col.anchor,
                              command=lambda k=col.key: self._sort_by(k))
            self.tree.column(col.key, width=col.width, anchor=col.anchor, stretch=col.stretch,
                             minwidth=40)
        scroll = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        self.tree.tag_configure("alt", background=COLORS["row_alt"])
        for status, (fg, bg) in STATUS_COLORS.items():
            self.tree.tag_configure(status, foreground=COLORS[fg], background=COLORS[bg])
        if on_select:
            self.tree.bind("<<TreeviewSelect>>", lambda _e: on_select(self.selected()))
        if on_activate:
            self.tree.bind("<Double-1>", lambda _e: self._activate(on_activate))
            self.tree.bind("<Return>", lambda _e: self._activate(on_activate))

    def set_rows(self, rows) -> None:
        """Replace the table content, keeping the selection when possible."""
        previous = self.tree.selection()
        self._rows = {}
        self._order = []
        for position, row in enumerate(rows):
            iid = str(row[self.key]) if self.key else str(position)
            self._rows[iid] = row
            self._order.append(iid)
        if self._sort[0]:
            self._apply_sort()
        self._render()
        keep = [iid for iid in previous if iid in self._rows]
        if keep:
            self.tree.selection_set(keep)
            self.tree.see(keep[0])

    def selected(self):
        """Return the selected row (or ``None``)."""
        selection = self.tree.selection()
        return self._rows.get(selection[0]) if selection else None

    def selected_rows(self) -> list:
        """All selected rows (for ``selectmode="extended"``)."""
        return [self._rows[iid] for iid in self.tree.selection() if iid in self._rows]

    def rows(self) -> list:
        """Rows in display order."""
        return [self._rows[iid] for iid in self._order]

    def select_first(self) -> None:
        """Select the first row, if any."""
        if self._order:
            self.tree.selection_set(self._order[0])
            self.tree.focus(self._order[0])

    # ------------------------------------------------------------------ internals
    def _render(self) -> None:
        self.tree.delete(*self.tree.get_children())
        for index, iid in enumerate(self._order):
            row = self._rows[iid]
            values = []
            for col in self.columns:
                raw = self._value(row, col.key)
                values.append(col.fmt(raw) if col.fmt and raw is not None
                              else "" if raw is None else raw)
            tags = []
            status = self.row_style(row) if self.row_style else None
            if status in STATUS_COLORS:
                tags.append(status)
            elif index % 2:
                tags.append("alt")
            self.tree.insert("", "end", iid=iid, values=values, tags=tags)

    @staticmethod
    def _value(row, key):
        try:
            return row[key]
        except (KeyError, IndexError, TypeError):
            return getattr(row, key, None)

    def _sort_by(self, key: str) -> None:
        current, descending = self._sort
        self._sort = (key, not descending if current == key else False)
        self._apply_sort()
        self._render()

    def _apply_sort(self) -> None:
        key, descending = self._sort

        def sort_key(iid):
            value = self._value(self._rows[iid], key)
            return (value is None, value if not isinstance(value, str) else value.lower())
        self._order.sort(key=sort_key, reverse=descending)

    def _activate(self, callback) -> None:
        row = self.selected()
        if row is not None:
            callback(row)


# --------------------------------------------------------------------------- layout pieces
class Card(ttk.Frame):
    """A white panel with an optional title; put content in ``card.body``."""

    def __init__(self, parent, title: str = "", padding: int = 14):
        super().__init__(parent, style="Surface.TFrame", padding=padding)
        self.configure(borderwidth=1, relief="solid")
        if title:
            ttk.Label(self, text=title, style="Section.TLabel").pack(anchor="w", pady=(0, 8))
        self.body = ttk.Frame(self, style="Surface.TFrame")
        self.body.pack(fill="both", expand=True)


class KpiTile(tk.Frame):
    """A dashboard figure: big value, caption and an accent color."""

    def __init__(self, parent, caption: str, accent: str = "primary"):
        super().__init__(parent, bg=COLORS["surface"], highlightthickness=1,
                         highlightbackground=COLORS["border"], padx=14, pady=10)
        tk.Frame(self, bg=COLORS[accent], width=4).pack(side="left", fill="y", padx=(0, 12))
        text = tk.Frame(self, bg=COLORS["surface"])
        text.pack(side="left", fill="both", expand=True)
        self.value = tk.Label(text, text="...", font=FONTS["kpi_bold"], bg=COLORS["surface"],
                              fg=COLORS["text"], anchor="w")
        self.value.pack(anchor="w")
        tk.Label(text, text=caption, font=FONTS["small"], bg=COLORS["surface"],
                 fg=COLORS["muted"], anchor="w").pack(anchor="w")

    def set(self, value: str) -> None:
        """Show a new value."""
        self.value.configure(text=value)


def button_row(parent, buttons: Sequence[tuple], style_bg: str = "TFrame") -> ttk.Frame:
    """Build a row of buttons from ``(text, command, style)`` tuples.

    Returns the frame; each button is also available as ``frame.buttons[text]``.
    """
    frame = ttk.Frame(parent, style=style_bg)
    frame.buttons = {}
    for spec in buttons:
        text, command = spec[0], spec[1]
        style = spec[2] if len(spec) > 2 else "TButton"
        btn = ttk.Button(frame, text=text, command=command, style=style)
        btn.pack(side="left", padx=(0, 6))
        frame.buttons[text] = btn
    return frame


# --------------------------------------------------------------------------- dialogs
@dataclass
class Field:
    """One input of a :class:`FormDialog`.

    ``kind`` is ``entry``, ``password``, ``combo`` (``options`` are
    ``(value, label)`` pairs), ``check`` or ``text`` (multi-line).
    """

    key: str
    label: str
    kind: str = "entry"
    default: Any = ""
    options: list = field(default_factory=list)
    width: int = 34
    hint: str = ""


class FormDialog(tk.Toplevel):
    """Modal form. ``on_submit(values)`` performs the action.

    If ``on_submit`` raises :class:`BusinessRuleError` the message is shown
    inside the dialog and the dialog stays open so the user can fix the input.
    """

    def __init__(self, parent, title: str, fields: Sequence[Field],
                 on_submit: Callable[[dict], None], submit_text: str = "Save",
                 intro: str = ""):
        super().__init__(parent)
        self.withdraw()
        self.title(title)
        self.configure(bg=COLORS["surface"])
        self.resizable(False, False)
        self.transient(parent.winfo_toplevel())
        self.on_submit = on_submit
        self.fields = list(fields)
        self.inputs: dict = {}
        self.submitted = False

        body = ttk.Frame(self, style="Surface.TFrame", padding=18)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text=title, style="Section.TLabel").grid(row=0, column=0, columnspan=2,
                                                                 sticky="w")
        row = 1
        if intro:
            ttk.Label(body, text=intro, style="SurfaceMuted.TLabel", wraplength=420,
                      justify="left").grid(row=row, column=0, columnspan=2, sticky="w",
                                           pady=(4, 6))
            row += 1
        for spec in self.fields:
            row = self._add_field(body, spec, row)
        self.error = ttk.Label(body, text="", style="Error.TLabel", wraplength=420,
                               justify="left")
        self.error.grid(row=row, column=0, columnspan=2, sticky="w", pady=(8, 0))
        buttons = ttk.Frame(body, style="Surface.TFrame")
        buttons.grid(row=row + 1, column=0, columnspan=2, sticky="e", pady=(12, 0))
        ttk.Button(buttons, text="Cancel", command=self.destroy).pack(side="right")
        ttk.Button(buttons, text=submit_text, style="Primary.TButton",
                   command=self._submit).pack(side="right", padx=(0, 6))
        self.bind("<Escape>", lambda _e: self.destroy())
        self.bind("<Return>", self._on_return)
        center_on(self, parent)
        self.deiconify()
        self.grab_set()
        first = next(iter(self.inputs.values()), None)
        if isinstance(first, (ttk.Entry, ttk.Combobox)):
            first.focus_set()

    def _add_field(self, body, spec: Field, row: int) -> int:
        if spec.kind == "check":
            var = tk.BooleanVar(value=bool(spec.default))
            ttk.Checkbutton(body, text=spec.label, variable=var,
                            style="Surface.TCheckbutton").grid(row=row, column=1, sticky="w",
                                                               pady=4)
            self.inputs[spec.key] = var
            return row + 1
        ttk.Label(body, text=spec.label, style="Surface.TLabel").grid(
            row=row, column=0, sticky="nw", padx=(0, 12), pady=5)
        if spec.kind == "combo":
            labels = [label for _value, label in spec.options]
            widget = ttk.Combobox(body, values=labels, state="readonly", width=spec.width - 2)
            default = next((label for value, label in spec.options if value == spec.default),
                           labels[0] if labels else "")
            widget.set(default)
        elif spec.kind == "text":
            widget = tk.Text(body, width=spec.width, height=4, font=FONTS["body"],
                             relief="solid", borderwidth=1, wrap="word")
            widget.insert("1.0", spec.default or "")
        else:
            widget = ttk.Entry(body, width=spec.width,
                               show="•" if spec.kind == "password" else "")
            widget.insert(0, "" if spec.default is None else str(spec.default))
        widget.grid(row=row, column=1, sticky="we", pady=5)
        self.inputs[spec.key] = widget
        if spec.hint:
            row += 1
            ttk.Label(body, text=spec.hint, style="SurfaceMuted.TLabel").grid(
                row=row, column=1, sticky="w")
        return row + 1

    def values(self) -> dict:
        """Return the values keyed by field; combos give the option value."""
        result = {}
        for spec in self.fields:
            widget = self.inputs[spec.key]
            if spec.kind == "check":
                result[spec.key] = widget.get()
            elif spec.kind == "combo":
                label = widget.get()
                result[spec.key] = next((v for v, lbl in spec.options if lbl == label), None)
            elif spec.kind == "text":
                result[spec.key] = widget.get("1.0", "end").strip()
            else:
                result[spec.key] = widget.get()
        return result

    def _on_return(self, event) -> None:
        if not isinstance(event.widget, tk.Text):
            self._submit()

    def _submit(self) -> None:
        try:
            self.on_submit(self.values())
        except BusinessRuleError as exc:
            self.error.configure(text=str(exc))
            self.bell()
            return
        except Exception as exc:  # noqa: BLE001 - unexpected, but keep the dialog usable
            show_error(self, exc)
            return
        self.submitted = True
        self.destroy()


def ask_reason(parent, title: str, prompt: str, on_submit: Callable[[str], None],
               submit_text: str = "Confirm") -> FormDialog:
    """Ask for a mandatory reason (voids, returns, rejections)."""
    return FormDialog(parent, title, [Field("reason", "Reason", "text")],
                      lambda values: on_submit(values["reason"]), submit_text, prompt)


def center_on(window: tk.Toplevel, parent: tk.Misc) -> None:
    """Place ``window`` in the middle of ``parent``'s top-level window."""
    window.update_idletasks()
    top = parent.winfo_toplevel()
    width, height = window.winfo_reqwidth(), window.winfo_reqheight()
    x = top.winfo_rootx() + max(0, (top.winfo_width() - width) // 2)
    y = top.winfo_rooty() + max(0, (top.winfo_height() - height) // 3)
    window.geometry(f"+{x}+{y}")
