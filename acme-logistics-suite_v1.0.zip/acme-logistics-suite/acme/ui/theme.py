"""Colors, fonts and ttk styles shared by every window."""

import sys
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk

COLORS = {
    "background": "#f2f5f9", "surface": "#ffffff", "border": "#dbe2ea", "text": "#14212f",
    "muted": "#5b6a7c", "faint": "#8b98a8", "line": "#e8edf3",
    "primary": "#0b5cad", "primary_hover": "#094c90", "primary_soft": "#e6effa",
    "success": "#1b7a43", "success_soft": "#e5f4eb", "warning": "#9a6200",
    "warning_soft": "#fff4dc", "danger": "#b3261e", "danger_soft": "#fdeceb",
    "sidebar": "#0e1b2e", "sidebar_hover": "#16273f", "sidebar_active": "#1c3354",
    "sidebar_text": "#c9d5e3", "sidebar_muted": "#7f93ac",
    "table_header": "#eef2f7", "row_alt": "#f8fafc", "selection": "#d3e4f8",
}

FONTS: dict = {}

STATUS_COLORS = {
    "ISSUED": ("warning", "warning_soft"), "RETURNED": ("danger", "danger_soft"),
    "APPROVED": ("primary", "primary_soft"), "INVOICED": ("success", "success_soft"),
    "VOID": ("faint", "background"), "OPEN": ("primary", "primary_soft"),
    "PAID": ("success", "success_soft"), "PENDING": ("warning", "warning_soft"),
    "REJECTED": ("danger", "danger_soft"), "LOW": ("warning", "warning_soft"),
}


def enable_high_dpi() -> None:
    """Ask Windows for crisp text on scaled displays (no-op elsewhere)."""
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except (AttributeError, OSError):
            pass


def _load_fonts(root: tk.Misc) -> None:
    families = set(tkfont.families(root))
    family = next((f for f in ("Segoe UI", "Inter", "Noto Sans", "DejaVu Sans", "Helvetica")
                   if f in families), "TkDefaultFont")
    mono = next((f for f in ("Consolas", "DejaVu Sans Mono", "Courier New") if f in families),
                "TkFixedFont")
    sizes = {"small": 9, "body": 10, "medium": 11, "large": 13, "title": 17, "kpi": 20}
    for name, size in sizes.items():
        FONTS[name] = tkfont.Font(root, family=family, size=size)
        FONTS[name + "_bold"] = tkfont.Font(root, family=family, size=size, weight="bold")
    FONTS["mono"] = tkfont.Font(root, family=mono, size=10)
    for base in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
        tkfont.nametofont(base).configure(family=family, size=10)


def apply_theme(root: tk.Tk) -> None:
    """Configure fonts and ttk styles. Call once, right after creating the root."""
    _load_fonts(root)
    c = COLORS
    root.configure(bg=c["background"])
    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure(".", background=c["background"], foreground=c["text"],
                    font=FONTS["body"], bordercolor=c["border"], lightcolor=c["border"],
                    darkcolor=c["border"], troughcolor=c["background"],
                    focuscolor=c["primary"])
    style.configure("TFrame", background=c["background"])
    style.configure("Surface.TFrame", background=c["surface"])
    style.configure("TLabel", background=c["background"])
    style.configure("Surface.TLabel", background=c["surface"])
    style.configure("Muted.TLabel", foreground=c["muted"])
    style.configure("SurfaceMuted.TLabel", background=c["surface"], foreground=c["muted"])
    style.configure("Title.TLabel", font=FONTS["title_bold"])
    style.configure("Section.TLabel", background=c["surface"], font=FONTS["medium_bold"])
    style.configure("Error.TLabel", background=c["surface"], foreground=c["danger"])
    style.configure("TCheckbutton", background=c["background"])
    style.configure("Surface.TCheckbutton", background=c["surface"])

    style.configure("TButton", padding=(12, 5), background=c["surface"],
                    bordercolor="#c5cfdb", lightcolor=c["surface"], darkcolor=c["surface"],
                    relief="solid", borderwidth=1)
    style.map("TButton", background=[("active", c["primary_soft"]),
                                     ("disabled", c["background"])],
              bordercolor=[("active", c["primary"])],
              foreground=[("disabled", c["faint"])])
    style.configure("Primary.TButton", background=c["primary"], foreground="#ffffff",
                    bordercolor=c["primary"], lightcolor=c["primary"],
                    darkcolor=c["primary"], font=FONTS["body_bold"])
    style.map("Primary.TButton", background=[("active", c["primary_hover"]),
                                             ("disabled", c["border"])])
    style.configure("Danger.TButton", foreground=c["danger"])

    style.configure("TEntry", padding=5, fieldbackground=c["surface"])
    style.configure("TCombobox", padding=4, fieldbackground=c["surface"])
    style.map("TCombobox", fieldbackground=[("readonly", c["surface"])])

    style.configure("Treeview", background=c["surface"], fieldbackground=c["surface"],
                    rowheight=26, bordercolor=c["border"], font=FONTS["body"])
    style.configure("Treeview.Heading", background=c["table_header"], relief="flat",
                    font=FONTS["body_bold"], padding=(6, 5))
    style.map("Treeview", background=[("selected", c["selection"])],
              foreground=[("selected", c["text"])])
    style.map("Treeview.Heading", background=[("active", c["line"])])

    style.configure("TNotebook", background=c["background"], borderwidth=0)
    style.configure("TNotebook.Tab", padding=(14, 6), background=c["background"],
                    font=FONTS["body"])
    style.map("TNotebook.Tab", background=[("selected", c["surface"])],
              font=[("selected", FONTS["body_bold"])])
