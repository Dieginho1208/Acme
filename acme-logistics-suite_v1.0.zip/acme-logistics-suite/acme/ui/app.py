"""Application shell: sign-in screen, main window with sidebar, and page routing."""

import tkinter as tk
from tkinter import ttk

from acme import APP_NAME, __version__
from acme.core.context import AppContext
from acme.core.errors import BusinessRuleError
from acme.ui.pages.admin import AdminPage, AuditPage
from acme.ui.pages.billing import BillingPage
from acme.ui.pages.customers import CustomersPage
from acme.ui.pages.dashboard import DashboardPage
from acme.ui.pages.dispatch import DeliveryNotesPage
from acme.ui.pages.inventory import InventoryPage, MovementsPage
from acme.ui.pages.receivables import ReceivablesPage
from acme.ui.pages.reports import ReportsPage
from acme.ui.theme import COLORS, FONTS, apply_theme, enable_high_dpi
from acme.ui.widgets import show_error

# (key, sidebar label, required permission, page class, section)
NAVIGATION = (
    ("dashboard", "Dashboard", "dashboard.view", DashboardPage, "Overview"),
    ("inventory", "Inventory", "inventory.view", InventoryPage, "Warehouse"),
    ("movements", "Stock movements", "inventory.view", MovementsPage, "Warehouse"),
    ("dispatch", "Delivery notes", "dispatch.view", DeliveryNotesPage, "Sales"),
    ("customers", "Customers", "customers.view", CustomersPage, "Sales"),
    ("billing", "Billing", "billing.view", BillingPage, "Finance"),
    ("receivables", "Receivables", "receivables.view", ReceivablesPage, "Finance"),
    ("reports", "Reports & Legacy ERP", "reports.view", ReportsPage, "Finance"),
    ("admin", "Administration", "admin.users", AdminPage, "System"),
    ("audit", "Audit log", "audit.view", AuditPage, "System"),
)

DEMO_ACCOUNTS = "admin · manager · warehouse · sales · accountant   (password: demo)"


class Application:
    """Owns the Tk root and switches between the sign-in and main screens."""

    def __init__(self, ctx: AppContext, show_demo_hint: bool = True):
        enable_high_dpi()
        self.ctx = ctx
        self.root = tk.Tk()
        self.root.title(APP_NAME)
        self.root.minsize(1180, 720)
        self.root.geometry("1360x820")
        apply_theme(self.root)
        self.root.report_callback_exception = self._report_error
        self.show_demo_hint = show_demo_hint
        self.screen = None
        self.show_login()

    def run(self) -> None:
        """Start the Tk main loop."""
        try:
            self.root.mainloop()
        finally:
            self.ctx.close()

    def show_login(self) -> None:
        """Display the sign-in screen."""
        self._replace(LoginScreen(self.root, self.ctx, self.on_signed_in,
                                  self.show_demo_hint))

    def on_signed_in(self) -> None:
        """Build the main window for the signed-in user."""
        self._replace(MainWindow(self.root, self.ctx, self.sign_out))

    def sign_out(self) -> None:
        """Forget the user and go back to the sign-in screen."""
        self.ctx.user = None
        self.show_login()

    def _replace(self, screen) -> None:
        if self.screen is not None:
            self.screen.destroy()
        self.screen = screen
        screen.pack(fill="both", expand=True)

    def _report_error(self, exc_type, exc, _tb) -> None:
        show_error(self.root, exc if isinstance(exc, Exception) else exc_type())


class LoginScreen(tk.Frame):
    """Centered sign-in card."""

    def __init__(self, parent, ctx: AppContext, on_success, show_demo_hint: bool):
        super().__init__(parent, bg=COLORS["sidebar"])
        self.ctx = ctx
        self.on_success = on_success
        card = tk.Frame(self, bg=COLORS["surface"], padx=36, pady=32)
        card.place(relx=0.5, rely=0.45, anchor="center")
        tk.Label(card, text=ctx.settings.company_name, font=FONTS["title_bold"],
                 bg=COLORS["surface"], fg=COLORS["text"]).pack(anchor="w")
        tk.Label(card, text=f"{APP_NAME} · v{__version__}", font=FONTS["body"],
                 bg=COLORS["surface"], fg=COLORS["muted"]).pack(anchor="w", pady=(0, 18))
        form = ttk.Frame(card, style="Surface.TFrame")
        form.pack(fill="x")
        ttk.Label(form, text="Username", style="Surface.TLabel").grid(row=0, column=0,
                                                                      sticky="w")
        self.username = ttk.Entry(form, width=32)
        self.username.grid(row=1, column=0, sticky="we", pady=(2, 10))
        ttk.Label(form, text="Password", style="Surface.TLabel").grid(row=2, column=0,
                                                                      sticky="w")
        self.password = ttk.Entry(form, width=32, show="•")
        self.password.grid(row=3, column=0, sticky="we", pady=(2, 6))
        self.error = ttk.Label(form, text="", style="Error.TLabel")
        self.error.grid(row=4, column=0, sticky="w")
        ttk.Button(form, text="Sign in", style="Primary.TButton",
                   command=self.submit).grid(row=5, column=0, sticky="we", pady=(10, 0))
        if show_demo_hint:
            tk.Label(card, text="Demo accounts\n" + DEMO_ACCOUNTS, font=FONTS["small"],
                     bg=COLORS["surface"], fg=COLORS["muted"], justify="left").pack(
                anchor="w", pady=(18, 0))
        self.username.bind("<Return>", lambda _e: self.password.focus_set())
        self.password.bind("<Return>", lambda _e: self.submit())
        self.after(50, self.username.focus_set)

    def submit(self) -> None:
        """Validate the credentials."""
        try:
            self.ctx.sign_in(self.username.get(), self.password.get())
        except BusinessRuleError as exc:
            self.error.configure(text=str(exc))
            self.password.delete(0, "end")
            return
        self.on_success()


class MainWindow(tk.Frame):
    """Sidebar navigation, page header area and a status bar for notifications."""

    def __init__(self, parent, ctx: AppContext, on_sign_out):
        super().__init__(parent, bg=COLORS["background"])
        self.ctx = ctx
        self.pages: dict = {}
        self.current = None
        self.nav_buttons: dict = {}
        self._clear_job = None

        sidebar = tk.Frame(self, bg=COLORS["sidebar"], width=230)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        self.company = tk.Label(sidebar, text=ctx.settings.company_name,
                                font=FONTS["large_bold"], bg=COLORS["sidebar"], fg="#ffffff",
                                anchor="w", padx=20)
        self.company.pack(fill="x", pady=(20, 0))
        tk.Label(sidebar, text=APP_NAME, font=FONTS["small"], bg=COLORS["sidebar"],
                 fg=COLORS["sidebar_muted"], anchor="w", padx=20).pack(fill="x", pady=(0, 14))

        section = None
        self.allowed = [n for n in NAVIGATION if ctx.user.can(n[2])]
        for key, label, _perm, _cls, group in self.allowed:
            if group != section:
                section = group
                tk.Label(sidebar, text=group.upper(), font=FONTS["small_bold"],
                         bg=COLORS["sidebar"], fg=COLORS["sidebar_muted"], anchor="w",
                         padx=20).pack(fill="x", pady=(12, 2))
            button = tk.Label(sidebar, text=label, font=FONTS["body"], anchor="w", padx=24,
                              pady=7, bg=COLORS["sidebar"], fg=COLORS["sidebar_text"],
                              cursor="hand2")
            button.pack(fill="x")
            button.bind("<Button-1>", lambda _e, k=key: self.show(k))
            button.bind("<Enter>", lambda _e, b=button, k=key: self._hover(b, k, True))
            button.bind("<Leave>", lambda _e, b=button, k=key: self._hover(b, k, False))
            self.nav_buttons[key] = button

        user_box = tk.Frame(sidebar, bg=COLORS["sidebar_hover"], padx=20, pady=12)
        user_box.pack(side="bottom", fill="x")
        tk.Label(user_box, text=ctx.user.full_name, font=FONTS["body_bold"],
                 bg=COLORS["sidebar_hover"], fg="#ffffff", anchor="w").pack(fill="x")
        tk.Label(user_box, text=ctx.user.role_label, font=FONTS["small"],
                 bg=COLORS["sidebar_hover"], fg=COLORS["sidebar_muted"], anchor="w").pack(
            fill="x")
        sign_out = tk.Label(user_box, text="Sign out", font=FONTS["small_bold"],
                            bg=COLORS["sidebar_hover"], fg=COLORS["sidebar_text"],
                            cursor="hand2", anchor="w")
        sign_out.pack(fill="x", pady=(6, 0))
        sign_out.bind("<Button-1>", lambda _e: on_sign_out())

        main = tk.Frame(self, bg=COLORS["background"])
        main.pack(side="left", fill="both", expand=True)
        self.status = tk.Label(main, text="", font=FONTS["body"], anchor="w", padx=20, pady=6,
                               bg=COLORS["line"], fg=COLORS["muted"])
        self.status.pack(side="bottom", fill="x")
        self.content = tk.Frame(main, bg=COLORS["background"])
        self.content.pack(fill="both", expand=True)
        self.notify(f"Signed in as {ctx.user.full_name} ({ctx.user.role_label}).")
        self.show(self.allowed[0][0])

    def show(self, key: str) -> None:
        """Display page ``key`` (created on first use) and refresh it."""
        spec = next(n for n in self.allowed if n[0] == key)
        if self.current is not None:
            self.pages[self.current].pack_forget()
        if key not in self.pages:
            self.pages[key] = spec[3](self.content, self.ctx, self)
        self.current = key
        for nav_key, button in self.nav_buttons.items():
            active = nav_key == key
            button.configure(bg=COLORS["sidebar_active"] if active else COLORS["sidebar"],
                             fg="#ffffff" if active else COLORS["sidebar_text"],
                             font=FONTS["body_bold"] if active else FONTS["body"])
        page = self.pages[key]
        page.pack(fill="both", expand=True)
        try:
            page.refresh()
        except BusinessRuleError as exc:
            show_error(self, exc)

    def notify(self, message: str, error: bool = False) -> None:
        """Show a message in the status bar for a few seconds."""
        self.status.configure(text=message,
                              fg=COLORS["danger"] if error else COLORS["muted"],
                              bg=COLORS["danger_soft"] if error else COLORS["line"])
        if self._clear_job:
            self.after_cancel(self._clear_job)
        self._clear_job = self.after(8000, lambda: self.status.configure(
            text="", bg=COLORS["line"]))

    def update_company_name(self) -> None:
        """Refresh the sidebar after the company settings change."""
        self.company.configure(text=self.ctx.settings.company_name)

    def _hover(self, button, key, inside: bool) -> None:
        if key != self.current:
            button.configure(bg=COLORS["sidebar_hover"] if inside else COLORS["sidebar"])
