"""View layer: Tkinter/ttk windows, pages and dialogs.

Rules followed by every module in this package:

* Views talk to the model only through :class:`acme.core.AppContext` services;
  no SQL lives here.
* Tkinter is touched only from the main thread. Slow work runs in a background
  thread via :func:`acme.ui.widgets.run_in_background` and comes back with
  ``after()``, so the window never freezes.
"""
