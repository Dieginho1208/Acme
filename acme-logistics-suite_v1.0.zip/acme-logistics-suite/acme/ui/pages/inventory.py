"""Inventory: item list, stock per location and stock movements."""

import tkinter as tk
from tkinter import ttk

from acme.core.money import from_cents
from acme.core.services.inventory import MOVEMENT_LABELS
from acme.ui.pages.base import Page, date_time, money, quantity
from acme.ui.theme import COLORS
from acme.ui.widgets import Card, Column, DataTable, Field, FormDialog, center_on


class InventoryPage(Page):
    """Browse items, see where they are stored and move stock."""

    title = "Inventory"
    subtitle = "Items, stock by location and stock movements."

    def __init__(self, parent, ctx, window):
        super().__init__(parent, ctx, window)
        actions = []
        if self.user.can("items.manage"):
            actions.append(("+ New item", self.new_item, "Primary.TButton"))
        self.header(actions)

        filters = ttk.Frame(self)
        filters.pack(fill="x", pady=(0, 10))
        ttk.Label(filters, text="Search").pack(side="left")
        self.search = ttk.Entry(filters, width=22)
        self.search.pack(side="left", padx=(6, 14))
        self.search.bind("<KeyRelease>", lambda _e: self._schedule_refresh())
        ttk.Label(filters, text="Category").pack(side="left")
        self.category = ttk.Combobox(filters, state="readonly", width=20)
        self.category.pack(side="left", padx=(6, 14))
        ttk.Label(filters, text="Warehouse").pack(side="left")
        self.warehouse = ttk.Combobox(filters, state="readonly", width=26)
        self.warehouse.pack(side="left", padx=(6, 14))
        self.low_only = tk.BooleanVar()
        ttk.Checkbutton(filters, text="Low stock only", variable=self.low_only,
                        command=self.refresh).pack(side="left")
        for combo in (self.category, self.warehouse):
            combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        self._load_filters()
        self._pending = None

        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=0, minsize=400)
        body.rowconfigure(0, weight=1)

        self.table = DataTable(body, [
            Column("sku", "SKU", 80), Column("name", "Item", 230, stretch=True),
            Column("category", "Category", 135),
            Column("on_hand", "On hand", 70, "e", quantity),
            Column("reorder_point", "Reorder", 65, "e", quantity),
            Column("unit_price", "Price", 75, "e", money)],
            height=20, row_style=lambda r: "LOW" if r["on_hand"] <= r["reorder_point"] else None,
            on_select=lambda _r: self._show_detail(), on_activate=lambda _r: self.edit_item())
        self.table.grid(row=0, column=0, sticky="nsew", padx=(0, 12))

        detail = Card(body, "Selected item")
        detail.grid(row=0, column=1, sticky="nsew")
        self.detail_title = ttk.Label(detail.body, text="Select an item", style="Surface.TLabel",
                                      wraplength=380, justify="left")
        self.detail_title.pack(anchor="w")
        self.detail_info = ttk.Label(detail.body, text="", style="SurfaceMuted.TLabel",
                                     justify="left")
        self.detail_info.pack(anchor="w", pady=(4, 10))
        self.locations = DataTable(detail.body, [
            Column("label", "Location", 115), Column("description", "Description", 170,
                                                     stretch=True),
            Column("quantity", "Qty", 60, "e", quantity)], height=7, key="location_id")
        self.locations.pack(fill="both", expand=True)
        buttons = ttk.Frame(detail.body, style="Surface.TFrame")
        buttons.pack(fill="x", pady=(10, 0))
        self.action_buttons = []
        specs = [("History", self.history)]
        if self.user.can("inventory.move"):
            specs = [("Receive", self.receive), ("Transfer", self.transfer),
                     ("Count / adjust", self.adjust)] + specs
        if self.user.can("items.manage"):
            specs.append(("Edit", self.edit_item))
        for text, command in specs:
            button = ttk.Button(buttons, text=text, command=command)
            button.pack(side="left", padx=(0, 6))
            self.action_buttons.append(button)

    # ------------------------------------------------------------------ data
    def _load_filters(self) -> None:
        inv = self.ctx.inventory
        self.category_options = [(None, "All categories")] + [
            (r["id"], r["name"]) for r in inv.categories()]
        self.warehouse_options = [(None, "All warehouses")] + [
            (r["id"], f"{r['code']} - {r['name']}") for r in inv.warehouses()]
        self.category.configure(values=[label for _v, label in self.category_options])
        self.warehouse.configure(values=[label for _v, label in self.warehouse_options])
        self.category.current(0)
        self.warehouse.current(0)

    def _schedule_refresh(self) -> None:
        if self._pending:
            self.after_cancel(self._pending)
        self._pending = self.after(250, self.refresh)

    def refresh(self) -> None:
        """Reload the item list with the current filters."""
        self._pending = None
        rows = self.ctx.inventory.list_items(
            search=self.search.get(),
            category_id=self.category_options[self.category.current()][0],
            warehouse_id=self.warehouse_options[self.warehouse.current()][0],
            low_stock_only=self.low_only.get())
        self.table.set_rows(rows)
        if self.table.selected() is None:
            self.table.select_first()
        self._show_detail()

    def _current_item(self):
        row = self.table.selected()
        return self.ctx.inventory.get_item(row["id"]) if row else None

    def _show_detail(self) -> None:
        item = self._current_item()
        state = "normal" if item else "disabled"
        for button in self.action_buttons:
            button.configure(state=state)
        if item is None:
            self.detail_title.configure(text="Select an item")
            self.detail_info.configure(text="")
            self.locations.set_rows([])
            return
        margin = item["unit_price"] - item["unit_cost"]
        pct = f" ({margin / item['unit_price']:.0%})" if item["unit_price"] else ""
        self.detail_title.configure(text=f"{item['sku']}  ·  {item['name']}")
        lines = [f"{item['category']}  ·  {item['brand'] or 'No brand'}  ·  "
                 f"barcode {item['barcode'] or '-'}",
                 f"On hand: {item['on_hand']:,} {item['unit']}  ·  reorder at "
                 f"{item['reorder_point']:,}"]
        if self.user.can("reports.view"):
            lines.append(f"Cost {money(item['unit_cost'])}  ·  list price "
                         f"{money(item['unit_price'])}  ·  margin {money(margin)}{pct}")
        self.detail_info.configure(text="\n".join(lines))
        self.locations.set_rows(self.ctx.inventory.stock_by_location(item["id"]))

    # ------------------------------------------------------------------ actions
    def _location_options(self):
        return [(r["id"], r["label"]) for r in self.ctx.inventory.locations()]

    def _stocked_options(self, item_id):
        return [(r["location_id"], f"{r['label']}  ({r['quantity']:,} on hand)")
                for r in self.ctx.inventory.stock_by_location(item_id)]

    def receive(self) -> None:
        """Book goods received into a location."""
        item = self._current_item()
        if not item:
            return
        stocked = self._stocked_options(item["id"])
        dialog = FormDialog(self, f"Receive {item['sku']}", [
            Field("location", "Into location", "combo",
                  stocked[0][0] if stocked else None, self._location_options()),
            Field("quantity", "Quantity", default=""),
            Field("reference", "Reference", hint="Purchase order or packing slip number"),
            Field("note", "Note")],
            lambda v: self.ctx.inventory.receive(self.user, item["id"], v["location"],
                                                 v["quantity"], v["reference"], v["note"]),
            "Receive", item["name"])
        self.run_dialog(dialog, "Stock received.")

    def transfer(self) -> None:
        """Move stock between locations."""
        item = self._current_item()
        if not item:
            return
        stocked = self._stocked_options(item["id"])
        if not stocked:
            self.window.notify(f"{item['sku']} has no stock to transfer.", error=True)
            return
        dialog = FormDialog(self, f"Transfer {item['sku']}", [
            Field("source", "From", "combo", stocked[0][0], stocked),
            Field("target", "To", "combo", None, self._location_options()),
            Field("quantity", "Quantity"), Field("note", "Note")],
            lambda v: self.ctx.inventory.transfer(self.user, item["id"], v["source"],
                                                  v["target"], v["quantity"], v["note"]),
            "Transfer", item["name"])
        self.run_dialog(dialog, "Transfer recorded.")

    def adjust(self) -> None:
        """Set a location to the physically counted quantity."""
        item = self._current_item()
        if not item:
            return
        stocked = self._stocked_options(item["id"])
        dialog = FormDialog(self, f"Count {item['sku']}", [
            Field("location", "Location", "combo", stocked[0][0] if stocked else None,
                  self._location_options()),
            Field("counted", "Counted quantity"),
            Field("reason", "Reason", hint="For example: cycle count, damaged units")],
            lambda v: self.ctx.inventory.adjust(self.user, item["id"], v["location"],
                                                v["counted"], v["reason"]),
            "Post adjustment",
            "Enter what is physically on the shelf. The difference is posted as an adjustment.")
        self.run_dialog(dialog, "Adjustment posted.")

    def new_item(self) -> None:
        """Create an item."""
        self._item_form(None)

    def edit_item(self) -> None:
        """Edit the selected item."""
        if self.user.can("items.manage"):
            item = self._current_item()
            if item:
                self._item_form(item)

    def _item_form(self, item) -> None:
        categories = [(r["id"], r["name"]) for r in self.ctx.inventory.categories()]
        get = (lambda key, default="": item[key]) if item else (lambda key, default="": default)
        fields = [
            Field("sku", "SKU", default=get("sku")), Field("name", "Name", default=get("name")),
            Field("category_id", "Category", "combo", get("category_id", None), categories),
            Field("brand", "Brand", default=get("brand")),
            Field("barcode", "Barcode", default=get("barcode")),
            Field("unit", "Unit", default=get("unit", "ea")),
            Field("unit_cost", "Unit cost", default=from_cents(get("unit_cost", 0))),
            Field("unit_price", "List price", default=from_cents(get("unit_price", 0))),
            Field("reorder_point", "Reorder point", default=get("reorder_point", 0)),
            Field("active", "Active", "check", get("active", 1))]
        item_id = item["id"] if item else None
        dialog = FormDialog(self, "Edit item" if item else "New item", fields,
                            lambda v: self.ctx.inventory.save_item(self.user, v, item_id))
        self.run_dialog(dialog, "Item saved.")

    def history(self) -> None:
        """Show the movement ledger of the selected item."""
        item = self._current_item()
        if item:
            MovementHistory(self, self.ctx, item)


class MovementHistory(tk.Toplevel):
    """Pop-up with every movement of one item (its stock ledger)."""

    def __init__(self, parent, ctx, item):
        super().__init__(parent)
        self.title(f"Stock ledger · {item['sku']}")
        self.configure(bg=COLORS["background"])
        frame = ttk.Frame(self, padding=14)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text=f"{item['sku']} · {item['name']}",
                  style="Title.TLabel").pack(anchor="w")
        table = DataTable(frame, MOVEMENT_COLUMNS, height=18)
        table.pack(fill="both", expand=True, pady=(10, 0))
        table.set_rows(ctx.inventory.movements(item_id=item["id"]))
        self.geometry("980x520")
        center_on(self, parent)


MOVEMENT_COLUMNS = [
    Column("created_at", "When", 130, fmt=date_time),
    Column("kind", "Type", 120, fmt=lambda k: MOVEMENT_LABELS.get(k, k)),
    Column("sku", "SKU", 90), Column("location", "Location", 120),
    Column("quantity", "Qty", 60, "e", lambda q: f"{q:+,}"),
    Column("reference", "Reference", 110), Column("note", "Note", 220, stretch=True),
    Column("user_name", "By", 130)]


class MovementsPage(Page):
    """Every stock movement across all warehouses, newest first."""

    title = "Stock movements"
    subtitle = "Receipts, transfers, adjustments and dispatches. Movements are never deleted."

    def __init__(self, parent, ctx, window):
        super().__init__(parent, ctx, window)
        self.header()
        filters = ttk.Frame(self)
        filters.pack(fill="x", pady=(0, 10))
        ttk.Label(filters, text="Type").pack(side="left")
        self.kinds = [("", "All types")] + list(MOVEMENT_LABELS.items())
        self.kind = ttk.Combobox(filters, state="readonly", width=20,
                                 values=[label for _k, label in self.kinds])
        self.kind.current(0)
        self.kind.pack(side="left", padx=6)
        self.kind.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        self.table = DataTable(self, [Column("item_name", "Item", 220)] + MOVEMENT_COLUMNS,
                               height=24)
        self.table.pack(fill="both", expand=True)

    def refresh(self) -> None:
        """Reload the movement list."""
        kind = self.kinds[self.kind.current()][0]
        self.table.set_rows(self.ctx.inventory.movements(kind=kind, limit=1000))
