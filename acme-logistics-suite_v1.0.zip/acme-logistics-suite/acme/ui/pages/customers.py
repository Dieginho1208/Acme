"""Customers: master data, sales rep, price list and credit terms."""

from tkinter import ttk

from acme.ui.pages.base import Page
from acme.ui.widgets import Column, DataTable, Field, FormDialog


class CustomersPage(Page):
    """List and maintain customers."""

    title = "Customers"

    def __init__(self, parent, ctx, window):
        super().__init__(parent, ctx, window)
        self.subtitle = ("The customers assigned to you." if self.user.sees_only_own_customers
                         else "Billing details, assigned sales rep, price list and terms.")
        actions = []
        if self.user.can("customers.manage"):
            actions.append(("+ New customer", self.new_customer, "Primary.TButton"))
        self.header(actions)
        bar = ttk.Frame(self)
        bar.pack(fill="x", pady=(0, 10))
        ttk.Label(bar, text="Search").pack(side="left")
        self.search = ttk.Entry(bar, width=30)
        self.search.pack(side="left", padx=6)
        self.search.bind("<KeyRelease>", lambda _e: self.refresh())
        self.table = DataTable(self, [
            Column("code", "Code", 70), Column("name", "Customer", 240, stretch=True),
            Column("tax_id", "Tax ID", 125), Column("email", "Email", 175),
            Column("phone", "Phone", 80), Column("sales_rep", "Sales rep", 115),
            Column("price_list", "Price list", 140, fmt=lambda v: v or "Default"),
            Column("credit_days", "Terms", 65, "e", lambda d: f"{d} days")],
            height=24, on_activate=lambda _r: self.edit_customer())
        self.table.pack(fill="both", expand=True)

    def refresh(self) -> None:
        """Reload the customer list."""
        self.table.set_rows(self.ctx.customers.list_customers(self.user, self.search.get()))

    def new_customer(self) -> None:
        """Create a customer."""
        self._form(None)

    def edit_customer(self) -> None:
        """Edit the selected customer."""
        row = self.table.selected()
        if row and self.user.can("customers.manage"):
            self._form(row)

    def _form(self, row) -> None:
        reps = [(None, "Unassigned")] + [(u.id, u.full_name)
                                         for u in self.ctx.auth.users_with_role("sales")]
        lists = [(None, "Default list")] + [(r["id"], r["name"])
                                            for r in self.ctx.billing.price_lists()]
        get = (lambda k, d="": row[k]) if row else (lambda k, d="": d)
        fields = [
            Field("code", "Code", default=get("code")), Field("name", "Name", default=get("name")),
            Field("tax_id", "Tax ID", default=get("tax_id")),
            Field("email", "Email", default=get("email")),
            Field("phone", "Phone", default=get("phone")),
            Field("address", "Address", default=get("address")),
            Field("sales_rep_id", "Sales rep", "combo", get("sales_rep_id", None), reps),
            Field("price_list_id", "Price list", "combo", get("price_list_id", None), lists),
            Field("credit_days", "Credit days", default=get("credit_days", 30)),
            Field("active", "Active", "check", get("active", 1))]
        dialog = FormDialog(self, "Edit customer" if row else "New customer", fields,
                            lambda v: self.ctx.customers.save(self.user, v,
                                                              row["id"] if row else None))
        self.run_dialog(dialog, "Customer saved.")
