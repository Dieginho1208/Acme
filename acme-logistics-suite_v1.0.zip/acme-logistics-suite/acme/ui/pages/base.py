"""Base class and helpers shared by every page."""

import datetime as dt
from tkinter import ttk

from acme.core.context import AppContext
from acme.core.errors import BusinessRuleError
from acme.core.money import format_money
from acme.ui.widgets import show_error


def money(cents) -> str:
    """Format cents as ``$1,234.56`` (empty for ``None``)."""
    return "" if cents is None else format_money(int(cents))


def date_only(value) -> str:
    """``2026-03-01 14:05:00`` -> ``2026-03-01``."""
    return str(value)[:10] if value else ""


def date_time(value) -> str:
    """``2026-03-01 14:05:00`` -> ``2026-03-01 14:05``."""
    return str(value)[:16] if value else ""


def quantity(value) -> str:
    """Thousands separator for whole quantities."""
    return f"{int(value):,}" if value is not None else ""


def days_overdue(due_date: str, today: dt.date) -> int:
    """Days past ``due_date`` (0 when not yet due)."""
    return max(0, (today - dt.date.fromisoformat(due_date)).days)


class Page(ttk.Frame):
    """A screen shown in the main window's content area.

    Subclasses build their widgets in ``__init__`` and implement :meth:`refresh`,
    which the main window calls every time the page is shown.
    """

    title = ""
    subtitle = ""

    def __init__(self, parent, ctx: AppContext, window):
        super().__init__(parent, padding=(20, 16))
        self.ctx = ctx
        self.window = window

    @property
    def user(self):
        """The signed-in user."""
        return self.ctx.user

    def refresh(self) -> None:
        """Reload the page's data. Override in subclasses."""

    def attempt(self, action, success_message: str = "") -> bool:
        """Run ``action()``, show business errors, refresh on success."""
        try:
            action()
        except BusinessRuleError as exc:
            show_error(self, exc)
            return False
        self.refresh()
        if success_message:
            self.window.notify(success_message)
        return True

    def run_dialog(self, dialog, message: str) -> bool:
        """Wait for a modal dialog; refresh and notify if it was submitted."""
        self.wait_window(dialog)
        if getattr(dialog, "submitted", False):
            self.refresh()
            self.window.notify(message)
            return True
        return False

    def after_change(self, message: str):
        """Return a callback that refreshes the page and shows ``message``."""
        def done(*_args):
            self.refresh()
            self.window.notify(message)
        return done

    def header(self, actions=()) -> ttk.Frame:
        """Page title, subtitle and an optional row of action buttons on the right."""
        bar = ttk.Frame(self)
        bar.pack(fill="x", pady=(0, 12))
        text = ttk.Frame(bar)
        text.pack(side="left")
        ttk.Label(text, text=self.title, style="Title.TLabel").pack(anchor="w")
        if self.subtitle:
            ttk.Label(text, text=self.subtitle, style="Muted.TLabel").pack(anchor="w")
        bar.actions = {}
        for spec in reversed(actions):
            label, command = spec[0], spec[1]
            style = spec[2] if len(spec) > 2 else "TButton"
            button = ttk.Button(bar, text=label, command=command, style=style)
            button.pack(side="right", padx=(6, 0))
            bar.actions[label] = button
        return bar
