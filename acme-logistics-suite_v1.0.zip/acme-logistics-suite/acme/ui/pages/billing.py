"""Billing: turn approved delivery notes into invoices and maintain price lists."""

import tkinter as tk
from tkinter import ttk

from acme.core.errors import BusinessRuleError
from acme.core.money import from_cents, to_cents
from acme.ui.pages.base import Page, date_only, money, quantity
from acme.ui.theme import COLORS, FONTS
from acme.ui.widgets import (Card, Column, DataTable, Field, FormDialog, ask_reason,
                             center_on, parse_date, show_error)

INVOICE_STATUS = {"OPEN": "Open", "PAID": "Paid", "VOID": "Void"}


class BillingPage(Page):
    """Approved notes waiting for an invoice, and the invoice register."""

    title = "Billing"
    subtitle = "Invoice approved delivery notes. Prices come from each customer's price list."

    def __init__(self, parent, ctx, window):
        super().__init__(parent, ctx, window)
        actions = []
        if self.user.can("billing.prices"):
            actions.append(("Price lists…", self.price_lists))
        self.header(actions)
        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True)

        ready = ttk.Frame(notebook, padding=12, style="Surface.TFrame")
        notebook.add(ready, text="Ready to invoice")
        ttk.Label(ready, text="Select one or more notes of the same customer (Ctrl+click), "
                              "then create the invoice.", style="SurfaceMuted.TLabel").pack(
            anchor="w", pady=(0, 8))
        self.ready = DataTable(ready, [
            Column("customer", "Customer", 260, stretch=True), Column("number", "Note", 100),
            Column("created_at", "Issued", 100, fmt=date_only),
            Column("units", "Units", 70, "e", quantity)], height=16, selectmode="extended")
        self.ready.pack(fill="both", expand=True)
        if self.user.can("billing.invoice"):
            ttk.Button(ready, text="Create invoice…", style="Primary.TButton",
                       command=self.create_invoice).pack(anchor="e", pady=(10, 0))

        register = ttk.Frame(notebook, padding=12, style="Surface.TFrame")
        notebook.add(register, text="Invoices")
        bar = ttk.Frame(register, style="Surface.TFrame")
        bar.pack(fill="x", pady=(0, 8))
        ttk.Label(bar, text="Search", style="Surface.TLabel").pack(side="left")
        self.search = ttk.Entry(bar, width=26)
        self.search.pack(side="left", padx=6)
        self.search.bind("<Return>", lambda _e: self.refresh())
        self.invoices = DataTable(register, INVOICE_COLUMNS, height=12,
                                  row_style=lambda r: r["status"],
                                  on_select=lambda _r: self._show_invoice())
        self.invoices.pack(fill="both", expand=True)
        self.invoice_lines = DataTable(register, [
            Column("note_number", "Note", 90), Column("sku", "SKU", 90),
            Column("description", "Item", 280, stretch=True),
            Column("quantity", "Qty", 60, "e", quantity),
            Column("unit_price", "Price", 90, "e", money),
            Column("price_overridden", "Edited", 60, "center", lambda v: "yes" if v else ""),
            Column("line_total", "Amount", 100, "e", money)], height=5)
        self.invoice_lines.pack(fill="both", expand=False, pady=(10, 0))
        if self.user.can("billing.invoice"):
            self.void_button = ttk.Button(register, text="Void invoice…",
                                          style="Danger.TButton", command=self.void_invoice)
            self.void_button.pack(anchor="e", pady=(10, 0))

    def refresh(self) -> None:
        """Reload both tabs."""
        self.ready.set_rows(self.ctx.billing.notes_ready_to_invoice())
        self.invoices.set_rows(with_balance(
            self.ctx.billing.list_invoices(self.user, search=self.search.get())))
        self._show_invoice()

    def _show_invoice(self) -> None:
        invoice = self.invoices.selected()
        self.invoice_lines.set_rows(self.ctx.billing.invoice_lines(invoice["id"])
                                    if invoice else [])

    def create_invoice(self) -> None:
        """Build a draft from the selected notes and open the invoice editor."""
        notes = self.ready.selected_rows()
        if not notes:
            self.window.notify("Select the delivery notes to invoice.", error=True)
            return
        customers = {n["customer_id"] for n in notes}
        if len(customers) > 1:
            self.window.notify("All selected notes must belong to the same customer.",
                               error=True)
            return
        try:
            draft = self.ctx.billing.build_draft(self.user, customers.pop(),
                                                 [n["id"] for n in notes])
        except BusinessRuleError as exc:
            show_error(self, exc)
            return
        editor = InvoiceEditor(self, self.ctx, draft)
        self.wait_window(editor)
        if editor.invoice_number:
            self.refresh()
            self.window.notify(f"Invoice {editor.invoice_number} created.")

    def void_invoice(self) -> None:
        """Void the selected invoice (only if it has no payments)."""
        invoice = self.invoices.selected()
        if invoice:
            dialog = ask_reason(self, f"Void {invoice['number']}",
                                "Its delivery notes will be ready to invoice again.",
                                lambda reason: self.ctx.billing.void_invoice(
                                    self.user, invoice["id"], reason), "Void invoice")
            self.run_dialog(dialog, f"{invoice['number']} voided.")

    def price_lists(self) -> None:
        """Open the price list editor."""
        PriceListWindow(self, self.ctx)


INVOICE_COLUMNS = [
    Column("number", "Invoice", 100), Column("customer", "Customer", 230, stretch=True),
    Column("issue_date", "Issued", 95), Column("due_date", "Due", 95),
    Column("total", "Total", 100, "e", money), Column("paid", "Paid", 100, "e", money),
    Column("balance", "Balance", 100, "e", money),
    Column("status", "Status", 80, fmt=lambda s: INVOICE_STATUS.get(s, s))]


def with_balance(rows) -> list:
    """Add a computed ``balance`` field to invoice rows."""
    result = []
    for row in rows:
        data = dict(row)
        data["balance"] = 0 if row["status"] == "VOID" else row["total"] - row["paid"]
        result.append(data)
    return result


class InvoiceEditor(tk.Toplevel):
    """Review a draft invoice, edit prices and save it."""

    def __init__(self, parent, ctx, draft):
        super().__init__(parent)
        self.withdraw()
        self.ctx = ctx
        self.draft = draft
        self.invoice_number = None
        self.title(f"New invoice · {draft.customer_name}")
        self.configure(bg=COLORS["background"])
        self.transient(parent.winfo_toplevel())
        frame = ttk.Frame(self, padding=16)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text=draft.customer_name, style="Title.TLabel").pack(anchor="w")
        ttk.Label(frame, text="Double-click a line (or press Enter) to change its price. "
                              "Edited prices are flagged on the invoice.",
                  style="Muted.TLabel").pack(anchor="w", pady=(2, 10))
        dates = ttk.Frame(frame)
        dates.pack(fill="x", pady=(0, 10))
        ttk.Label(dates, text="Issue date").pack(side="left")
        self.issue = ttk.Entry(dates, width=12)
        self.issue.insert(0, draft.issue_date.isoformat())
        self.issue.pack(side="left", padx=(6, 16))
        ttk.Label(dates, text="Due date").pack(side="left")
        self.due = ttk.Entry(dates, width=12)
        self.due.insert(0, draft.due_date.isoformat())
        self.due.pack(side="left", padx=6)
        self.table = DataTable(frame, [
            Column("note_number", "Note", 90), Column("sku", "SKU", 90),
            Column("description", "Item", 280, stretch=True),
            Column("quantity", "Qty", 60, "e", quantity),
            Column("list_price", "List price", 95, "e", money),
            Column("unit_price", "Price", 95, "e", money),
            Column("total", "Amount", 105, "e", money)],
            height=10, key=None, on_activate=self._edit_price,
            row_style=lambda line: "PENDING" if line.overridden else None)
        self.table.pack(fill="both", expand=True)
        self.totals = ttk.Label(frame, text="", font=FONTS["medium_bold"])
        self.totals.pack(anchor="e", pady=(10, 0))
        buttons = ttk.Frame(frame)
        buttons.pack(fill="x", pady=(12, 0))
        ttk.Button(buttons, text="Cancel", command=self.destroy).pack(side="right")
        ttk.Button(buttons, text="Create invoice", style="Primary.TButton",
                   command=self._save).pack(side="right", padx=6)
        self._render()
        self.geometry("900x520")
        center_on(self, parent)
        self.deiconify()
        self.grab_set()

    def _render(self) -> None:
        self.table.set_rows(self.draft.lines)
        rate = self.draft.tax_rate_bp / 100
        self.totals.configure(text=f"Subtotal {money(self.draft.subtotal)}     "
                                   f"Tax {rate:.2f}% {money(self.draft.tax_amount)}     "
                                   f"Total {money(self.draft.total)}")

    def _edit_price(self, line) -> None:
        def apply(values):
            cents = to_cents(values["price"])
            if cents < 0:
                raise BusinessRuleError("Prices cannot be negative.")
            line.unit_price = cents

        dialog = FormDialog(self, f"Price for {line.sku}",
                            [Field("price", "Unit price", default=from_cents(line.unit_price))],
                            apply, "Apply", f"List price: {money(line.list_price)}")
        self.wait_window(dialog)
        self._render()

    def _save(self) -> None:
        try:
            self.draft.issue_date = parse_date(self.issue.get(), "the issue date")
            self.draft.due_date = parse_date(self.due.get(), "the due date")
            invoice_id = self.ctx.billing.create_invoice(self.ctx.user, self.draft)
        except Exception as exc:  # noqa: BLE001
            show_error(self, exc)
            return
        self.invoice_number = self.ctx.billing.get_invoice(invoice_id)["number"]
        self.destroy()


class PriceListWindow(tk.Toplevel):
    """Price lists: current prices on a date, new dated prices and price history."""

    def __init__(self, parent, ctx):
        super().__init__(parent)
        self.ctx = ctx
        self.title("Price lists")
        self.configure(bg=COLORS["background"])
        frame = ttk.Frame(self, padding=16)
        frame.pack(fill="both", expand=True)
        bar = ttk.Frame(frame)
        bar.pack(fill="x", pady=(0, 10))
        ttk.Label(bar, text="Price list").pack(side="left")
        self.lists = []
        self.list_combo = ttk.Combobox(bar, state="readonly", width=30)
        self.list_combo.pack(side="left", padx=6)
        self.list_combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        ttk.Button(bar, text="+ New list…", command=self._new_list).pack(side="left", padx=6)
        ttk.Label(bar, text="Double-click an item to set a new price.",
                  style="Muted.TLabel").pack(side="right")
        body = ttk.Frame(frame)
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.rowconfigure(0, weight=1)
        self.sheet = DataTable(body, [
            Column("sku", "SKU", 90), Column("name", "Item", 260, stretch=True),
            Column("base", "Base price", 90, "e", money),
            Column("price", "List price today", 110, "e", money)], height=18,
            on_select=lambda _r: self._show_history(), on_activate=self._set_price)
        self.sheet.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        history = Card(body, "Price history")
        history.grid(row=0, column=1, sticky="nsew")
        self.history = DataTable(history.body, [
            Column("valid_from", "Valid from", 95), Column("price", "Price", 85, "e", money),
            Column("created_by_name", "Set by", 130, stretch=True)], height=12)
        self.history.pack(fill="both", expand=True)
        self._load_lists()
        self.geometry("1000x560")
        center_on(self, parent)

    def _load_lists(self, select_id=None) -> None:
        self.lists = list(self.ctx.billing.price_lists())
        labels = [f"{r['name']}{'  (default)' if r['is_default'] else ''}" for r in self.lists]
        self.list_combo.configure(values=labels)
        index = next((i for i, r in enumerate(self.lists) if r["id"] == select_id), 0)
        if self.lists:
            self.list_combo.current(index)
        self.refresh()

    def _list_id(self):
        index = self.list_combo.current()
        return self.lists[index]["id"] if index >= 0 else None

    def refresh(self) -> None:
        """Reload the price sheet of the selected list."""
        list_id = self._list_id()
        if list_id is None:
            return
        self.sheet.set_rows([{"id": item["id"], "sku": item["sku"], "name": item["name"],
                              "base": item["unit_price"], "price": price}
                             for item, price in self.ctx.billing.price_sheet(list_id)])
        if self.sheet.selected() is None:
            self.sheet.select_first()
        self._show_history()

    def _show_history(self) -> None:
        row = self.sheet.selected()
        self.history.set_rows(self.ctx.billing.price_history(self._list_id(), row["id"])
                              if row else [])

    def _set_price(self, row) -> None:
        list_id = self._list_id()

        def apply(values):
            self.ctx.billing.set_price(self.ctx.user, list_id, row["id"], values["price"],
                                       parse_date(values["valid_from"], "the start date"))

        dialog = FormDialog(self, f"New price for {row['sku']}", [
            Field("price", "Price", default=from_cents(row["price"])),
            Field("valid_from", "Valid from", default=self.ctx.db.today().isoformat(),
                  hint="YYYY-MM-DD. The previous price stays in the history.")],
            apply, "Save price", row["name"])
        self.wait_window(dialog)
        if dialog.submitted:
            self.refresh()

    def _new_list(self) -> None:
        created = {}

        def apply(values):
            created["id"] = self.ctx.billing.create_price_list(self.ctx.user, values["name"],
                                                               values["default"])

        dialog = FormDialog(self, "New price list", [
            Field("name", "Name"), Field("default", "Use as the default list", "check")],
            apply, "Create",
            "Items without a price in this list use their base price.")
        self.wait_window(dialog)
        if created:
            self._load_lists(created["id"])
