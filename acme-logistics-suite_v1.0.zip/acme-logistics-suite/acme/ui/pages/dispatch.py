"""Delivery notes: issue shipments, review them and send them to billing."""

import tkinter as tk
from tkinter import ttk

from acme.core.errors import BusinessRuleError
from acme.core.services.dispatch import STATUS_LABELS
from acme.ui.pages.base import Page, date_time, quantity
from acme.ui.theme import COLORS
from acme.ui.widgets import (Card, Column, DataTable, ask_reason, center_on, show_error)


class DeliveryNotesPage(Page):
    """List of delivery notes with their life-cycle actions."""

    title = "Delivery notes"
    subtitle = "Issued notes take goods out of stock. A manager approves them for invoicing."

    def __init__(self, parent, ctx, window):
        super().__init__(parent, ctx, window)
        actions = []
        if self.user.can("dispatch.create"):
            actions.append(("+ New delivery note", self.new_note, "Primary.TButton"))
        self.header(actions)

        filters = ttk.Frame(self)
        filters.pack(fill="x", pady=(0, 10))
        ttk.Label(filters, text="Status").pack(side="left")
        self.statuses = [("", "All")] + list(STATUS_LABELS.items())
        self.status = ttk.Combobox(filters, state="readonly", width=20,
                                   values=[label for _s, label in self.statuses])
        self.status.current(1 if self.user.can("dispatch.review") else 0)
        self.status.pack(side="left", padx=(6, 14))
        self.status.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        ttk.Label(filters, text="Search").pack(side="left")
        self.search = ttk.Entry(filters, width=20)
        self.search.pack(side="left", padx=6)
        self.search.bind("<Return>", lambda _e: self.refresh())
        self.buttons = {}
        specs = []
        if self.user.can("dispatch.review"):
            specs += [("Approve", self.approve, "Primary.TButton"),
                      ("Return…", self.return_note, "TButton")]
        if self.user.can("dispatch.create"):
            specs.append(("Resubmit", self.resubmit, "TButton"))
        if self.user.can("dispatch.void"):
            specs.append(("Void…", self.void, "Danger.TButton"))
        for text, command, style in reversed(specs):
            button = ttk.Button(filters, text=text, command=command, style=style)
            button.pack(side="right", padx=(6, 0))
            self.buttons[text] = button

        self.table = DataTable(self, [
            Column("number", "Note", 95), Column("created_at", "Issued", 130, fmt=date_time),
            Column("customer", "Customer", 240, stretch=True),
            Column("units", "Units", 60, "e", quantity),
            Column("status", "Status", 140, fmt=lambda s: STATUS_LABELS.get(s, s)),
            Column("created_by_name", "Issued by", 130),
            Column("reviewed_by_name", "Reviewed by", 130),
            Column("invoice_number", "Invoice", 95)],
            height=12, row_style=lambda r: r["status"],
            on_select=lambda _r: self._show_lines())
        self.table.pack(fill="both", expand=True)

        detail = Card(self, "Lines")
        detail.pack(fill="both", expand=True, pady=(12, 0))
        self.note_info = ttk.Label(detail.body, text="", style="SurfaceMuted.TLabel",
                                   wraplength=900, justify="left")
        self.note_info.pack(anchor="w", pady=(0, 6))
        self.lines = DataTable(detail.body, [
            Column("sku", "SKU", 90), Column("item_name", "Item", 320, stretch=True),
            Column("location", "From location", 140),
            Column("quantity", "Qty", 70, "e", quantity)], height=5)
        self.lines.pack(fill="both", expand=True)

    def refresh(self) -> None:
        """Reload notes for the chosen status."""
        status = self.statuses[self.status.current()][0]
        self.table.set_rows(self.ctx.dispatch.list_notes(self.user, status=status,
                                                         search=self.search.get()))
        if self.table.selected() is None:
            self.table.select_first()
        self._show_lines()

    def _show_lines(self) -> None:
        note = self.table.selected()
        allowed = {"Approve": ("ISSUED",), "Return…": ("ISSUED", "APPROVED"),
                   "Resubmit": ("RETURNED",), "Void…": ("ISSUED", "RETURNED", "APPROVED")}
        for text, button in self.buttons.items():
            ok = note is not None and note["status"] in allowed[text]
            button.configure(state="normal" if ok else "disabled")
        if note is None:
            self.lines.set_rows([])
            self.note_info.configure(text="")
            return
        info = [f"{note['number']} · {note['customer']} · {STATUS_LABELS[note['status']]}"]
        if note["remarks"]:
            info.append(f"Remarks: {note['remarks']}")
        if note["review_note"]:
            info.append(f"Returned because: {note['review_note']}")
        if note["void_reason"]:
            info.append(f"Void because: {note['void_reason']}")
        self.note_info.configure(text="\n".join(info))
        self.lines.set_rows(self.ctx.dispatch.note_lines(note["id"]))

    # ------------------------------------------------------------------ actions
    def approve(self) -> None:
        """Approve the selected note."""
        note = self.table.selected()
        if note:
            self.attempt(lambda: self.ctx.dispatch.approve(self.user, note["id"]),
                         f"{note['number']} approved for invoicing.")

    def return_note(self) -> None:
        """Return the selected note to sales with a reason."""
        note = self.table.selected()
        if note:
            dialog = ask_reason(self, f"Return {note['number']} to sales",
                                "Tell sales what needs to be fixed.",
                                lambda reason: self.ctx.dispatch.return_to_sales(
                                    self.user, note["id"], reason), "Return")
            self.run_dialog(dialog, f"{note['number']} returned to sales.")

    def resubmit(self) -> None:
        """Send a corrected note back for approval."""
        note = self.table.selected()
        if note:
            self.attempt(lambda: self.ctx.dispatch.resubmit(self.user, note["id"]),
                         f"{note['number']} sent for approval again.")

    def void(self) -> None:
        """Void the selected note; its goods go back to stock."""
        note = self.table.selected()
        if note:
            dialog = ask_reason(self, f"Void {note['number']}",
                                "The goods on this note will be returned to their locations.",
                                lambda reason: self.ctx.dispatch.void(self.user, note["id"],
                                                                      reason), "Void note")
            self.run_dialog(dialog, f"{note['number']} voided; stock restored.")

    def new_note(self) -> None:
        """Open the delivery note editor."""
        editor = NewDeliveryNoteDialog(self, self.ctx)
        self.wait_window(editor)
        if editor.created_number:
            self.status.current(0)
            self.refresh()
            self.window.notify(f"{editor.created_number} issued.")


class NewDeliveryNoteDialog(tk.Toplevel):
    """Editor for a new delivery note: pick a customer, then add item lines."""

    def __init__(self, parent, ctx):
        super().__init__(parent)
        self.withdraw()
        self.ctx = ctx
        self.created_number = None
        self.lines: list = []
        self.title("New delivery note")
        self.configure(bg=COLORS["background"])
        self.transient(parent.winfo_toplevel())
        frame = ttk.Frame(self, padding=16)
        frame.pack(fill="both", expand=True)

        top = ttk.Frame(frame)
        top.pack(fill="x")
        ttk.Label(top, text="Customer").grid(row=0, column=0, sticky="w")
        self.customers = [(r["id"], f"{r['name']} ({r['code']})")
                          for r in ctx.customers.list_customers(ctx.user)]
        self.customer = ttk.Combobox(top, state="readonly", width=48,
                                     values=[label for _i, label in self.customers])
        self.customer.grid(row=0, column=1, sticky="w", padx=8)
        ttk.Label(top, text="Remarks").grid(row=1, column=0, sticky="w", pady=(8, 0))
        self.remarks = ttk.Entry(top, width=50)
        self.remarks.grid(row=1, column=1, sticky="w", padx=8, pady=(8, 0))

        add = Card(frame, "Add a line")
        add.pack(fill="x", pady=12)
        self.items = [(r["id"], f"{r['sku']} · {r['name']}  [{r['on_hand']:,}]")
                      for r in ctx.inventory.list_items() if r["on_hand"] > 0]
        ttk.Label(add.body, text="Item", style="Surface.TLabel").grid(row=0, column=0,
                                                                      sticky="w")
        self.item = ttk.Combobox(add.body, width=56, values=[lbl for _i, lbl in self.items])
        self.item.grid(row=0, column=1, sticky="w", padx=8)
        self.item.bind("<<ComboboxSelected>>", lambda _e: self._load_locations())
        self.item.bind("<KeyRelease>", self._filter_items)
        ttk.Label(add.body, text="From", style="Surface.TLabel").grid(row=1, column=0,
                                                                      sticky="w", pady=6)
        self.location = ttk.Combobox(add.body, state="readonly", width=40)
        self.location.grid(row=1, column=1, sticky="w", padx=8, pady=6)
        ttk.Label(add.body, text="Quantity", style="Surface.TLabel").grid(row=2, column=0,
                                                                          sticky="w")
        self.qty = ttk.Entry(add.body, width=10)
        self.qty.grid(row=2, column=1, sticky="w", padx=8)
        self.qty.bind("<Return>", lambda _e: self._add_line())
        ttk.Button(add.body, text="Add line", command=self._add_line).grid(
            row=2, column=1, sticky="e", padx=8)
        self.location_options: list = []

        self.table = DataTable(frame, [
            Column("sku", "SKU", 90), Column("name", "Item", 300, stretch=True),
            Column("location", "From", 140), Column("quantity", "Qty", 60, "e")],
            height=7, key=None)
        self.table.pack(fill="both", expand=True)
        self.error = ttk.Label(frame, text="", foreground=COLORS["danger"])
        self.error.pack(anchor="w", pady=(6, 0))
        buttons = ttk.Frame(frame)
        buttons.pack(fill="x", pady=(8, 0))
        ttk.Button(buttons, text="Remove line", command=self._remove_line).pack(side="left")
        ttk.Button(buttons, text="Cancel", command=self.destroy).pack(side="right")
        ttk.Button(buttons, text="Issue delivery note", style="Primary.TButton",
                   command=self._issue).pack(side="right", padx=6)
        self.bind("<Escape>", lambda _e: self.destroy())
        center_on(self, parent)
        self.deiconify()
        self.grab_set()
        self.customer.focus_set()

    def _filter_items(self, event) -> None:
        if event.keysym in ("Up", "Down", "Return", "Escape"):
            return
        text = self.item.get().lower()
        self.item.configure(values=[lbl for _i, lbl in self.items if text in lbl.lower()])

    def _selected_item(self):
        label = self.item.get()
        return next((item_id for item_id, lbl in self.items if lbl == label), None)

    def _load_locations(self) -> None:
        item_id = self._selected_item()
        self.location_options = []
        if item_id:
            self.location_options = [
                (r["location_id"], f"{r['label']}  ({r['quantity']:,} on hand)", r["label"])
                for r in self.ctx.inventory.stock_by_location(item_id)]
        self.location.configure(values=[opt[1] for opt in self.location_options])
        if self.location_options:
            self.location.current(0)
        self.qty.focus_set()

    def _add_line(self) -> None:
        item_id = self._selected_item()
        if not item_id or self.location.current() < 0:
            self.error.configure(text="Choose an item and a location first.")
            return
        try:
            qty = int(self.qty.get())
            if qty <= 0:
                raise ValueError
        except ValueError:
            self.error.configure(text="The quantity must be a whole number above zero.")
            return
        location_id, _label, short = self.location_options[self.location.current()]
        item = self.ctx.inventory.get_item(item_id)
        self.lines.append({"item_id": item_id, "location_id": location_id, "quantity": qty,
                           "sku": item["sku"], "name": item["name"], "location": short})
        self.table.set_rows(self.lines)
        self.error.configure(text="")
        self.qty.delete(0, "end")
        self.item.set("")
        self.item.configure(values=[lbl for _i, lbl in self.items])
        self.item.focus_set()

    def _remove_line(self) -> None:
        selection = self.table.tree.selection()
        if selection:
            del self.lines[int(selection[0])]
            self.table.set_rows(self.lines)

    def _issue(self) -> None:
        if self.customer.current() < 0:
            self.error.configure(text="Choose the customer.")
            return
        customer_id = self.customers[self.customer.current()][0]
        try:
            note_id = self.ctx.dispatch.create_note(
                self.ctx.user, customer_id,
                [(ln["item_id"], ln["location_id"], ln["quantity"]) for ln in self.lines],
                self.remarks.get())
        except BusinessRuleError as exc:
            self.error.configure(text=str(exc))
            return
        except Exception as exc:  # noqa: BLE001
            show_error(self, exc)
            return
        self.created_number = self.ctx.dispatch.get_note(note_id)["number"]
        self.destroy()
