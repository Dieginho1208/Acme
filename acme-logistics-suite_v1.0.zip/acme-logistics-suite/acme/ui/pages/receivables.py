"""Accounts receivable: balances, aging, payments and statements of account."""

import tkinter as tk
from tkinter import filedialog, ttk

from acme.core.services.receivables import AGING_BUCKETS, PAYMENT_METHODS
from acme.ui.pages.base import Page, date_time, days_overdue, money
from acme.ui.pages.billing import INVOICE_COLUMNS, with_balance
from acme.ui.theme import COLORS
from acme.ui.widgets import (Column, DataTable, Field, FormDialog, KpiTile, ask_reason,
                             center_on, parse_date, run_in_background)

PAYMENT_STATUS = {"PENDING": "Awaiting review", "APPROVED": "Approved",
                  "REJECTED": "Rejected"}


class ReceivablesPage(Page):
    """What customers owe, and the payments that settle it."""

    title = "Accounts receivable"

    def __init__(self, parent, ctx, window):
        super().__init__(parent, ctx, window)
        self.subtitle = ("Your customers' balances. Payments you record are reviewed by "
                         "accounting." if self.user.sees_only_own_customers else
                         "Balances by customer, aging and payment review.")
        self.header()
        tiles = ttk.Frame(self)
        tiles.pack(fill="x", pady=(0, 12))
        accents = ("success", "primary", "warning", "danger", "danger")
        self.aging_tiles = {}
        for index, (bucket, accent) in enumerate(zip(AGING_BUCKETS, accents)):
            key, label = bucket[0], bucket[1]
            tile = KpiTile(tiles, label, accent)
            tile.grid(row=0, column=index, sticky="nsew", padx=(0, 10))
            tiles.columnconfigure(index, weight=1, uniform="aging")
            self.aging_tiles[key] = tile

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True)
        self.notebook = notebook

        balances = ttk.Frame(notebook, padding=12, style="Surface.TFrame")
        notebook.add(balances, text="Balances by customer")
        self.balances = DataTable(balances, [
            Column("code", "Code", 70), Column("name", "Customer", 260, stretch=True),
            Column("sales_rep", "Sales rep", 140), Column("invoices", "Invoices", 75, "e"),
            Column("balance", "Balance", 110, "e", money),
            Column("overdue", "Overdue", 110, "e", money),
            Column("oldest_due", "Oldest due", 100)], height=14,
            row_style=lambda r: "REJECTED" if (r["overdue"] or 0) > 0 else None,
            on_activate=lambda r: self.statement())
        self.balances.pack(fill="both", expand=True)
        bar = ttk.Frame(balances, style="Surface.TFrame")
        bar.pack(fill="x", pady=(10, 0))
        ttk.Button(bar, text="Statement of account…", command=self.statement).pack(side="left")

        invoices = ttk.Frame(notebook, padding=12, style="Surface.TFrame")
        notebook.add(invoices, text="Open invoices")
        self.invoices = DataTable(invoices, INVOICE_COLUMNS + [
            Column("days_late", "Days late", 80, "e")], height=14,
            row_style=lambda r: "REJECTED" if r["days_late"] > 0 else None,
            on_activate=lambda r: self.record_payment())
        self.invoices.pack(fill="both", expand=True)
        if self.user.can("receivables.record"):
            ttk.Button(invoices, text="Record payment…", style="Primary.TButton",
                       command=self.record_payment).pack(anchor="e", pady=(10, 0))

        payments = ttk.Frame(notebook, padding=12, style="Surface.TFrame")
        notebook.add(payments, text="Payments")
        bar = ttk.Frame(payments, style="Surface.TFrame")
        bar.pack(fill="x", pady=(0, 8))
        ttk.Label(bar, text="Show", style="Surface.TLabel").pack(side="left")
        self.payment_filters = [("PENDING", "Awaiting review"), ("", "All payments")]
        self.payment_filter = ttk.Combobox(bar, state="readonly", width=18, values=[
            label for _v, label in self.payment_filters])
        self.payment_filter.current(0)
        self.payment_filter.pack(side="left", padx=6)
        self.payment_filter.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        self.payments = DataTable(payments, [
            Column("created_at", "Entered", 125, fmt=date_time),
            Column("invoice_number", "Invoice", 95),
            Column("customer", "Customer", 220, stretch=True),
            Column("amount", "Amount", 100, "e", money), Column("method", "Method", 110),
            Column("reference", "Reference", 110), Column("paid_on", "Paid on", 90),
            Column("entered_by_name", "Entered by", 130),
            Column("status", "Status", 120, fmt=lambda s: PAYMENT_STATUS.get(s, s))],
            height=14, row_style=lambda r: r["status"])
        self.payments.pack(fill="both", expand=True)
        if self.user.can("receivables.review"):
            bar = ttk.Frame(payments, style="Surface.TFrame")
            bar.pack(fill="x", pady=(10, 0))
            ttk.Button(bar, text="Approve", style="Primary.TButton",
                       command=self.approve_payment).pack(side="left")
            ttk.Button(bar, text="Reject…", style="Danger.TButton",
                       command=self.reject_payment).pack(side="left", padx=6)

    def refresh(self) -> None:
        """Reload balances, invoices, payments and aging (in the background)."""
        user = self.user
        status = self.payment_filters[self.payment_filter.current()][0]
        today = self.ctx.db.today()

        def load():
            rec = self.ctx.receivables
            invoices = with_balance(self.ctx.billing.list_invoices(user, status="OPEN"))
            for row in invoices:
                row["days_late"] = days_overdue(row["due_date"], today)
            return (rec.aging(user), rec.customer_balances(user), invoices,
                    rec.list_payments(user, status))

        def show(data):
            aging, balances, invoices, payments = data
            for key, tile in self.aging_tiles.items():
                tile.set(money(aging[key]))
            self.balances.set_rows(balances)
            self.invoices.set_rows(invoices)
            self.payments.set_rows(payments)

        run_in_background(self, load, show)

    # ------------------------------------------------------------------ actions
    def record_payment(self) -> None:
        """Register a payment against the selected open invoice."""
        if not self.user.can("receivables.record"):
            return
        invoice = self.invoices.selected()
        if invoice is None:
            self.window.notify("Select an open invoice first.", error=True)
            return
        open_amount = invoice["total"] - invoice["paid"]
        intro = (f"{invoice['customer']} · open balance {money(open_amount)}")
        if not self.user.can("receivables.review"):
            intro += "\nThe payment will be reviewed by accounting before it counts."

        def apply(values):
            self.ctx.receivables.record_payment(
                self.user, invoice["id"], values["amount"], values["method"],
                values["reference"], parse_date(values["paid_on"], "the payment date"))

        dialog = FormDialog(self, f"Payment for {invoice['number']}", [
            Field("amount", "Amount", default=f"{open_amount / 100:.2f}"),
            Field("method", "Method", "combo", PAYMENT_METHODS[0],
                  [(m, m) for m in PAYMENT_METHODS]),
            Field("reference", "Reference", hint="Bank reference, check number..."),
            Field("paid_on", "Paid on", default=self.ctx.db.today().isoformat())],
            apply, "Record payment", intro)
        self.run_dialog(dialog, "Payment recorded.")

    def approve_payment(self) -> None:
        """Approve the selected pending payment."""
        payment = self.payments.selected()
        if payment:
            self.attempt(lambda: self.ctx.receivables.approve_payment(self.user, payment["id"]),
                         f"Payment of {money(payment['amount'])} approved.")

    def reject_payment(self) -> None:
        """Reject the selected pending payment with a reason."""
        payment = self.payments.selected()
        if payment:
            dialog = ask_reason(self, "Reject payment",
                                f"{payment['customer']} · {money(payment['amount'])}",
                                lambda reason: self.ctx.receivables.reject_payment(
                                    self.user, payment["id"], reason), "Reject")
            self.run_dialog(dialog, "Payment rejected.")

    def statement(self) -> None:
        """Show the statement of account of the selected customer."""
        row = self.balances.selected()
        if row is None:
            self.window.notify("Select a customer first.", error=True)
            return
        StatementWindow(self, self.ctx, row["id"], row["name"])


class StatementWindow(tk.Toplevel):
    """Chronological statement with running balance, exportable to CSV."""

    def __init__(self, parent, ctx, customer_id, customer_name):
        super().__init__(parent)
        self.ctx = ctx
        self.customer_id = customer_id
        self.title(f"Statement · {customer_name}")
        self.configure(bg=COLORS["background"])
        frame = ttk.Frame(self, padding=16)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text=customer_name, style="Title.TLabel").pack(anchor="w")
        table = DataTable(frame, [
            Column("date", "Date", 95), Column("document", "Document", 110),
            Column("description", "Description", 300, stretch=True),
            Column("charge", "Charge", 100, "e", lambda v: money(v) if v else ""),
            Column("credit", "Credit", 100, "e", lambda v: money(v) if v else ""),
            Column("balance", "Balance", 110, "e", money)], height=18, key=None)
        table.pack(fill="both", expand=True, pady=(10, 0))
        lines = ctx.receivables.statement(ctx.user, customer_id)
        table.set_rows(lines)
        bar = ttk.Frame(frame)
        bar.pack(fill="x", pady=(10, 0))
        closing = lines[-1]["balance"] if lines else 0
        ttk.Label(bar, text=f"Balance due: {money(closing)}",
                  style="Title.TLabel").pack(side="left")
        ttk.Button(bar, text="Export CSV…", command=self._export).pack(side="right")
        self.geometry("900x560")
        center_on(self, parent)

    def _export(self) -> None:
        path = filedialog.asksaveasfilename(parent=self, defaultextension=".csv",
                                            filetypes=[("CSV files", "*.csv")],
                                            initialfile="statement.csv")
        if path:
            self.ctx.reports.export_statement(self.ctx.user, self.customer_id, path)
