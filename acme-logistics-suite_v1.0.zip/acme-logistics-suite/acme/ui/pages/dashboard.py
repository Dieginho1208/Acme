"""Dashboard: key figures, shipments chart, best sellers and recent activity."""

import tkinter as tk
from tkinter import ttk

from acme.ui.pages.base import Page, date_time, money, quantity
from acme.ui.theme import COLORS, FONTS
from acme.ui.widgets import Card, Column, DataTable, KpiTile, run_in_background

ACTION_TEXT = {"CREATE": "created", "UPDATE": "updated", "ISSUE": "issued",
               "APPROVE": "approved", "RETURN": "returned", "RESUBMIT": "resubmitted",
               "VOID": "voided", "RECEIVE": "received", "TRANSFER": "transferred",
               "ADJUST": "adjusted", "RECORD": "recorded", "REJECT": "rejected",
               "SET_PRICE": "repriced", "IMPORT": "imported", "EXPORT": "exported",
               "RESET_PASSWORD": "reset password for"}


class DashboardPage(Page):
    """Overview of the business, limited to what the signed-in role may see."""

    title = "Dashboard"
    subtitle = "Today's picture of stock, shipments and collections."

    def __init__(self, parent, ctx, window):
        super().__init__(parent, ctx, window)
        self.header([("Refresh", self.refresh)])
        self.tiles = {}
        tiles = ttk.Frame(self)
        tiles.pack(fill="x")
        specs = [("active_items", "Active items", "primary", quantity),
                 ("low_stock", "Items at or below reorder point", "warning", quantity),
                 ("notes_awaiting", "Delivery notes awaiting approval", "warning", quantity),
                 ("notes_to_invoice", "Delivery notes ready to invoice", "primary", quantity)]
        if self.user.can("reports.view"):
            specs.insert(1, ("stock_value", "Inventory value at cost", "success", money))
        if self.user.can("receivables.view"):
            specs += [("outstanding", "Accounts receivable", "primary", money),
                      ("overdue", "Overdue", "danger", money),
                      ("payments_pending", "Payments awaiting review", "warning", quantity)]
        self.formatters = {}
        per_row = 4
        for index, (key, caption, accent, fmt) in enumerate(specs):
            tile = KpiTile(tiles, caption, accent)
            tile.grid(row=index // per_row, column=index % per_row, sticky="nsew",
                      padx=(0, 10), pady=(0, 10))
            self.tiles[key] = tile
            self.formatters[key] = fmt
        for col in range(per_row):
            tiles.columnconfigure(col, weight=1, uniform="tiles")

        lower = ttk.Frame(self)
        lower.pack(fill="both", expand=True)
        lower.columnconfigure(0, weight=3, uniform="lower")
        lower.columnconfigure(1, weight=2, uniform="lower")
        lower.rowconfigure(1, weight=1)

        chart_card = Card(lower, "Units shipped, last 14 days")
        chart_card.grid(row=0, column=0, sticky="nsew", padx=(0, 10), pady=(0, 10))
        self.chart = tk.Canvas(chart_card.body, height=170, bg=COLORS["surface"],
                               highlightthickness=0)
        self.chart.pack(fill="both", expand=True)
        self.chart.bind("<Configure>", lambda _e: self._draw_chart())
        self.series = []

        top_card = Card(lower, "Best sellers, last 30 days")
        top_card.grid(row=0, column=1, sticky="nsew", pady=(0, 10))
        self.top = DataTable(top_card.body, [
            Column("sku", "SKU", 90), Column("name", "Item", 200, stretch=True),
            Column("units", "Units", 60, "e", quantity)], height=6, key="sku")
        self.top.pack(fill="both", expand=True)

        activity_card = Card(lower, "Recent activity")
        activity_card.grid(row=1, column=0, columnspan=2, sticky="nsew")
        self.activity = DataTable(activity_card.body, [
            Column("created_at", "When", 130, fmt=date_time),
            Column("user_name", "Who", 150), Column("summary", "What", 520, stretch=True)],
            height=7, key="id")
        self.activity.pack(fill="both", expand=True)

    def refresh(self) -> None:
        """Load all figures in a background thread, then paint them."""
        user = self.user

        def load():
            reports = self.ctx.reports
            return (reports.dashboard(user), reports.units_shipped_by_day(14),
                    reports.top_items(30), reports.recent_activity(user, 30))
        run_in_background(self, load, self._show)

    def _show(self, data) -> None:
        figures, self.series, top, activity = data
        for key, tile in self.tiles.items():
            tile.set(self.formatters[key](figures.get(key, 0) or 0))
        self.top.set_rows(top)
        self.activity.set_rows([
            {"id": row["id"], "created_at": row["created_at"],
             "user_name": row["user_name"] or "System",
             "summary": f"{ACTION_TEXT.get(row['action'], row['action'].lower()).capitalize()}"
                        f" {row['entity'].replace('_', ' ')}: {row['detail']}"}
            for row in activity])
        self._draw_chart()

    def _draw_chart(self) -> None:
        canvas = self.chart
        canvas.delete("all")
        if not self.series:
            return
        width, height = canvas.winfo_width(), canvas.winfo_height()
        left, bottom, top = 34, height - 22, 12
        peak = max(units for _day, units in self.series) or 1
        slot = (width - left - 6) / len(self.series)
        for fraction in (0.5, 1.0):
            y = bottom - (bottom - top) * fraction
            canvas.create_line(left, y, width - 6, y, fill=COLORS["line"])
            canvas.create_text(left - 6, y, text=f"{int(peak * fraction)}", anchor="e",
                               font=FONTS["small"], fill=COLORS["faint"])
        canvas.create_line(left, bottom, width - 6, bottom, fill=COLORS["border"])
        for index, (day, units) in enumerate(self.series):
            x0 = left + index * slot + slot * 0.18
            x1 = left + (index + 1) * slot - slot * 0.18
            y = bottom - (bottom - top) * units / peak
            color = COLORS["primary"] if day.weekday() < 5 else COLORS["faint"]
            canvas.create_rectangle(x0, y, x1, bottom, fill=color, width=0)
            canvas.create_text((x0 + x1) / 2, bottom + 10, text=day.strftime("%d"),
                               font=FONTS["small"], fill=COLORS["muted"])
