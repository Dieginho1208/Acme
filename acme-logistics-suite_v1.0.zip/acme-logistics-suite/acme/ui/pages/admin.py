"""Administration (users and settings) and the audit log."""

from tkinter import ttk

from acme.core.money import from_cents
from acme.core.security import ROLES
from acme.ui.pages.base import Page, date_time
from acme.ui.widgets import Card, Column, DataTable, Field, FormDialog

ROLE_OPTIONS = list(ROLES.items())


class AdminPage(Page):
    """User accounts and company settings."""

    title = "Administration"
    subtitle = "User accounts, roles and company settings."

    def __init__(self, parent, ctx, window):
        super().__init__(parent, ctx, window)
        self.header([("+ New user", self.new_user, "Primary.TButton")])
        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.rowconfigure(0, weight=1)

        users = Card(body, "Users")
        users.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        self.users = DataTable(users.body, [
            Column("username", "Username", 110), Column("full_name", "Name", 180, stretch=True),
            Column("role", "Role", 160, fmt=lambda r: ROLES.get(r, r)),
            Column("active", "Active", 60, "center", lambda a: "yes" if a else "no"),
            Column("created_at", "Created", 130, fmt=date_time)], height=14,
            row_style=lambda r: None if r["active"] else "VOID",
            on_activate=lambda _r: self.edit_user())
        self.users.pack(fill="both", expand=True)
        bar = ttk.Frame(users.body, style="Surface.TFrame")
        bar.pack(fill="x", pady=(10, 0))
        ttk.Button(bar, text="Edit…", command=self.edit_user).pack(side="left")
        ttk.Button(bar, text="Reset password…", command=self.reset_password).pack(
            side="left", padx=6)

        settings = Card(body, "Company settings")
        settings.grid(row=0, column=1, sticky="nsew")
        self.settings_text = ttk.Label(settings.body, text="", style="Surface.TLabel",
                                       justify="left")
        self.settings_text.pack(anchor="w")
        ttk.Button(settings.body, text="Edit settings…", command=self.edit_settings).pack(
            anchor="w", pady=(12, 0))

    def refresh(self) -> None:
        """Reload users and settings."""
        self.users.set_rows(self.ctx.auth.list_users())
        s = self.ctx.settings
        self.settings_text.configure(text=(
            f"Company: {s.company_name}\nAddress: {s.get('company_address')}\n"
            f"Sales tax: {s.tax_rate_bp / 100:.2f} %\nDatabase: {self.ctx.db.path.name}"))

    def new_user(self) -> None:
        """Create a user account."""
        dialog = FormDialog(self, "New user", [
            Field("username", "Username"), Field("full_name", "Full name"),
            Field("role", "Role", "combo", "sales", ROLE_OPTIONS),
            Field("password", "Password", "password")],
            lambda v: self.ctx.auth.create_user(self.user, v["username"], v["full_name"],
                                                v["role"], v["password"]), "Create user")
        self.run_dialog(dialog, "User created.")

    def edit_user(self) -> None:
        """Change name, role or active flag of the selected user."""
        row = self.users.selected()
        if row is None:
            return
        dialog = FormDialog(self, f"Edit {row['username']}", [
            Field("full_name", "Full name", default=row["full_name"]),
            Field("role", "Role", "combo", row["role"], ROLE_OPTIONS),
            Field("active", "Active", "check", row["active"])],
            lambda v: self.ctx.auth.update_user(self.user, row["id"], v["full_name"],
                                                v["role"], v["active"]))
        self.run_dialog(dialog, "User updated.")

    def reset_password(self) -> None:
        """Set a new password for the selected user."""
        row = self.users.selected()
        if row is None:
            return
        dialog = FormDialog(self, f"New password for {row['username']}", [
            Field("password", "New password", "password")],
            lambda v: self.ctx.auth.reset_password(self.user, row["id"], v["password"]),
            "Set password")
        self.run_dialog(dialog, "Password changed.")

    def edit_settings(self) -> None:
        """Edit company name, address and tax rate."""
        s = self.ctx.settings
        dialog = FormDialog(self, "Company settings", [
            Field("name", "Company name", default=s.company_name),
            Field("address", "Address", default=s.get("company_address")),
            Field("tax", "Sales tax (%)", default=from_cents(s.tax_rate_bp))],
            lambda v: s.update(self.user, v["name"], v["address"], v["tax"]))
        if self.run_dialog(dialog, "Settings saved."):
            self.window.update_company_name()


class AuditPage(Page):
    """Read-only audit trail: who did what, and when."""

    title = "Audit log"
    subtitle = "Every change is recorded. Nothing in this system is ever deleted."

    def __init__(self, parent, ctx, window):
        super().__init__(parent, ctx, window)
        self.header()
        bar = ttk.Frame(self)
        bar.pack(fill="x", pady=(0, 10))
        ttk.Label(bar, text="Search").pack(side="left")
        self.search = ttk.Entry(bar, width=30)
        self.search.pack(side="left", padx=6)
        self.search.bind("<Return>", lambda _e: self.refresh())
        self.table = DataTable(self, [
            Column("created_at", "When", 130, fmt=date_time),
            Column("user_name", "User", 140, fmt=lambda v: v or "System"),
            Column("action", "Action", 110), Column("entity", "Record", 120),
            Column("entity_id", "Id", 60, "e"), Column("detail", "Detail", 460, stretch=True)],
            height=26)
        self.table.pack(fill="both", expand=True)

    def refresh(self) -> None:
        """Reload the audit entries."""
        self.table.set_rows(self.ctx.reports.audit_log(self.user, self.search.get()))
