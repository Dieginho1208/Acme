"""Reports and the Legacy ERP bridge (CSV exports and imports)."""

import csv
import datetime as dt
from tkinter import filedialog, messagebox, ttk

from acme.core.services.legacy_erp import ITEM_COLUMNS
from acme.ui.pages.base import Page
from acme.ui.widgets import Card, parse_date, run_in_background


class ReportsPage(Page):
    """Spreadsheet exports and data exchange with the Legacy ERP."""

    title = "Reports & Legacy ERP"
    subtitle = ("Exports open in any spreadsheet. The Legacy ERP bridge keeps the old system "
                "in sync while it is phased out.")

    def __init__(self, parent, ctx, window):
        super().__init__(parent, ctx, window)
        self.header()
        grid = ttk.Frame(self)
        grid.pack(fill="both", expand=True)
        grid.columnconfigure(0, weight=1, uniform="cards")
        grid.columnconfigure(1, weight=1, uniform="cards")

        exports = Card(grid, "Exports")
        exports.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        if self.user.can("reports.view"):
            self._action(exports.body, "Inventory valuation",
                         "Stock on hand per item, at cost.", self.export_valuation)
        if self.user.can("receivables.view"):
            self._action(exports.body, "Receivables aging",
                         "Open balances per customer by days past due.", self.export_aging)

        legacy = Card(grid, "Legacy ERP bridge")
        legacy.grid(row=0, column=1, sticky="nsew")
        if self.user.can("legacy.exchange"):
            dates = ttk.Frame(legacy.body, style="Surface.TFrame")
            dates.pack(fill="x", pady=(0, 6))
            today = self.ctx.db.today()
            ttk.Label(dates, text="From", style="Surface.TLabel").pack(side="left")
            self.date_from = ttk.Entry(dates, width=12)
            self.date_from.insert(0, today.replace(day=1).isoformat())
            self.date_from.pack(side="left", padx=6)
            ttk.Label(dates, text="To", style="Surface.TLabel").pack(side="left")
            self.date_to = ttk.Entry(dates, width=12)
            self.date_to.insert(0, today.isoformat())
            self.date_to.pack(side="left", padx=6)
            self._action(legacy.body, "Export sales ledger",
                         "Invoices in the layout the Legacy ERP accounting module imports.",
                         self.export_ledger)
            if self.user.can("items.manage"):
                self._action(legacy.body, "Import item catalog…",
                             "Create or update items from a Legacy ERP product file "
                             "(matched by SKU). The file is checked before anything is saved.",
                             self.import_items)
                self._action(legacy.body, "Save an import template",
                             "An empty CSV with the expected columns.", self.save_template)
        else:
            ttk.Label(legacy.body, text="Available to accounting and administrators.",
                      style="SurfaceMuted.TLabel").pack(anchor="w")

    @staticmethod
    def _action(parent, title, text, command) -> None:
        row = ttk.Frame(parent, style="Surface.TFrame")
        row.pack(fill="x", pady=(6, 8))
        ttk.Button(row, text=title, command=command).pack(anchor="w")
        ttk.Label(row, text=text, style="SurfaceMuted.TLabel", wraplength=460,
                  justify="left").pack(anchor="w", pady=(4, 0))

    def _ask_path(self, name: str):
        return filedialog.asksaveasfilename(parent=self, defaultextension=".csv",
                                            initialfile=name,
                                            filetypes=[("CSV files", "*.csv")])

    def _export(self, name: str, job) -> None:
        path = self._ask_path(name)
        if path:
            run_in_background(self, lambda: job(path),
                              lambda count: self.window.notify(f"Exported {count} row(s) to "
                                                               f"{path}."))

    def export_valuation(self) -> None:
        """Export the inventory valuation."""
        self._export("inventory_valuation.csv",
                     lambda path: self.ctx.reports.export_inventory_valuation(self.user, path))

    def export_aging(self) -> None:
        """Export the receivables aging."""
        self._export("receivables_aging.csv",
                     lambda path: self.ctx.reports.export_aging(self.user, path))

    def export_ledger(self) -> None:
        """Export the sales ledger for the Legacy ERP."""
        try:
            start = parse_date(self.date_from.get(), "the start date")
            end = parse_date(self.date_to.get(), "the end date")
        except Exception as exc:  # noqa: BLE001
            messagebox.showwarning("Not possible", str(exc), parent=self)
            return
        self._export(f"sales_ledger_{start:%Y%m%d}_{end:%Y%m%d}.csv",
                     lambda path: self.ctx.legacy_erp.export_sales_ledger(self.user, path,
                                                                          start, end))

    def import_items(self) -> None:
        """Dry-run an item import, show the result and apply it on confirmation."""
        path = filedialog.askopenfilename(parent=self, filetypes=[("CSV files", "*.csv")])
        if not path:
            return
        bridge = self.ctx.legacy_erp

        def checked(report):
            if not report.ok:
                details = "\n".join(report.errors[:12])
                more = "\n..." if len(report.errors) > 12 else ""
                messagebox.showwarning("File has errors",
                                       f"Nothing was imported.\n\n{details}{more}", parent=self)
                return
            if messagebox.askyesno("Import items", f"The file is valid: {report.summary()}."
                                   "\n\nImport it now?", parent=self):
                run_in_background(self, lambda: bridge.import_items(self.user, path, False),
                                  lambda done: self.window.notify(
                                      f"Import finished: {done.summary()}."))

        run_in_background(self, lambda: bridge.import_items(self.user, path, True), checked)

    def save_template(self) -> None:
        """Write an empty import template."""
        path = self._ask_path("item_import_template.csv")
        if path:
            with open(path, "w", newline="", encoding="utf-8") as handle:
                writer = csv.writer(handle)
                writer.writerow(ITEM_COLUMNS)
                writer.writerow(["PER-9001", "Example Item", "Computer Peripherals",
                                 "Example Brand", "10.00", "19.99", "5"])
            self.window.notify(f"Template saved to {path} ({dt.date.today():%Y-%m-%d}).")
