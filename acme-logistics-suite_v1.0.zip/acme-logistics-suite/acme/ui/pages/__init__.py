"""Application pages. Each page is a view plus the small controller that drives it."""
