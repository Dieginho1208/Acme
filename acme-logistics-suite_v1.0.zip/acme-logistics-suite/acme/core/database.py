"""SQLite storage: connection handling, schema and transactions.

Design notes
------------
* One connection per thread (``sqlite3`` objects must not cross threads). The UI
  runs slow work in background threads, so each thread gets its own connection.
* Connections run in autocommit mode; :meth:`Database.transaction` opens an
  explicit ``BEGIN IMMEDIATE`` so every business operation is all-or-nothing.
* Nothing is ever deleted. Records are voided or deactivated and every change is
  written to ``audit_log``.
* The clock is injectable, which lets tests and the mock-data generator create
  history "in the past" through the very same business services.
"""

import contextlib
import datetime as dt
import sqlite3
import threading
from pathlib import Path
from typing import Any, Callable, Iterable, Iterator, Optional

SCHEMA_VERSION = 1

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY,
    username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
    full_name     TEXT NOT NULL,
    role          TEXT NOT NULL CHECK (role IN
                      ('admin', 'manager', 'warehouse', 'sales', 'accountant')),
    password_hash TEXT NOT NULL,
    active        INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS warehouses (
    id     INTEGER PRIMARY KEY,
    code   TEXT NOT NULL UNIQUE,
    name   TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS locations (
    id           INTEGER PRIMARY KEY,
    warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
    code         TEXT NOT NULL,
    description  TEXT NOT NULL DEFAULT '',
    active       INTEGER NOT NULL DEFAULT 1,
    UNIQUE (warehouse_id, code)
);

CREATE TABLE IF NOT EXISTS categories (
    id   INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS items (
    id            INTEGER PRIMARY KEY,
    sku           TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name          TEXT NOT NULL,
    category_id   INTEGER NOT NULL REFERENCES categories(id),
    brand         TEXT NOT NULL DEFAULT '',
    barcode       TEXT NOT NULL DEFAULT '',
    unit          TEXT NOT NULL DEFAULT 'ea',
    unit_cost     INTEGER NOT NULL DEFAULT 0 CHECK (unit_cost >= 0),
    unit_price    INTEGER NOT NULL DEFAULT 0 CHECK (unit_price >= 0),
    reorder_point INTEGER NOT NULL DEFAULT 0 CHECK (reorder_point >= 0),
    active        INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stock (
    item_id     INTEGER NOT NULL REFERENCES items(id),
    location_id INTEGER NOT NULL REFERENCES locations(id),
    quantity    INTEGER NOT NULL CHECK (quantity >= 0),
    PRIMARY KEY (item_id, location_id)
);

CREATE TABLE IF NOT EXISTS stock_movements (
    id          INTEGER PRIMARY KEY,
    item_id     INTEGER NOT NULL REFERENCES items(id),
    location_id INTEGER NOT NULL REFERENCES locations(id),
    quantity    INTEGER NOT NULL,
    kind        TEXT NOT NULL CHECK (kind IN ('RECEIPT', 'TRANSFER_OUT', 'TRANSFER_IN',
                    'ADJUSTMENT', 'DISPATCH', 'DISPATCH_VOID')),
    reference   TEXT NOT NULL DEFAULT '',
    note        TEXT NOT NULL DEFAULT '',
    user_id     INTEGER NOT NULL REFERENCES users(id),
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_movements_item ON stock_movements(item_id, created_at);

CREATE TABLE IF NOT EXISTS price_lists (
    id         INTEGER PRIMARY KEY,
    name       TEXT NOT NULL UNIQUE,
    is_default INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS price_list_prices (
    id            INTEGER PRIMARY KEY,
    price_list_id INTEGER NOT NULL REFERENCES price_lists(id),
    item_id       INTEGER NOT NULL REFERENCES items(id),
    price         INTEGER NOT NULL CHECK (price >= 0),
    valid_from    TEXT NOT NULL,
    created_by    INTEGER NOT NULL REFERENCES users(id),
    created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_prices_lookup
    ON price_list_prices(price_list_id, item_id, valid_from);

CREATE TABLE IF NOT EXISTS customers (
    id            INTEGER PRIMARY KEY,
    code          TEXT NOT NULL UNIQUE,
    name          TEXT NOT NULL,
    tax_id        TEXT NOT NULL DEFAULT '',
    email         TEXT NOT NULL DEFAULT '',
    phone         TEXT NOT NULL DEFAULT '',
    address       TEXT NOT NULL DEFAULT '',
    sales_rep_id  INTEGER REFERENCES users(id),
    price_list_id INTEGER REFERENCES price_lists(id),
    credit_days   INTEGER NOT NULL DEFAULT 30 CHECK (credit_days >= 0),
    active        INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS delivery_notes (
    id           INTEGER PRIMARY KEY,
    number       TEXT NOT NULL UNIQUE,
    customer_id  INTEGER NOT NULL REFERENCES customers(id),
    status       TEXT NOT NULL CHECK (status IN
                     ('ISSUED', 'APPROVED', 'RETURNED', 'INVOICED', 'VOID')),
    remarks      TEXT NOT NULL DEFAULT '',
    created_by   INTEGER NOT NULL REFERENCES users(id),
    created_at   TEXT NOT NULL,
    reviewed_by  INTEGER REFERENCES users(id),
    reviewed_at  TEXT,
    review_note  TEXT NOT NULL DEFAULT '',
    void_reason  TEXT NOT NULL DEFAULT '',
    invoice_id   INTEGER REFERENCES invoices(id)
);
CREATE INDEX IF NOT EXISTS ix_notes_status ON delivery_notes(status, customer_id);

CREATE TABLE IF NOT EXISTS delivery_note_lines (
    id          INTEGER PRIMARY KEY,
    note_id     INTEGER NOT NULL REFERENCES delivery_notes(id),
    item_id     INTEGER NOT NULL REFERENCES items(id),
    location_id INTEGER NOT NULL REFERENCES locations(id),
    quantity    INTEGER NOT NULL CHECK (quantity > 0)
);

CREATE TABLE IF NOT EXISTS invoices (
    id          INTEGER PRIMARY KEY,
    number      TEXT NOT NULL UNIQUE,
    customer_id INTEGER NOT NULL REFERENCES customers(id),
    issue_date  TEXT NOT NULL,
    due_date    TEXT NOT NULL,
    subtotal    INTEGER NOT NULL,
    tax_rate_bp INTEGER NOT NULL,
    tax_amount  INTEGER NOT NULL,
    total       INTEGER NOT NULL,
    status      TEXT NOT NULL CHECK (status IN ('OPEN', 'PAID', 'VOID')),
    void_reason TEXT NOT NULL DEFAULT '',
    created_by  INTEGER NOT NULL REFERENCES users(id),
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_invoices_customer ON invoices(customer_id, status);

CREATE TABLE IF NOT EXISTS invoice_lines (
    id               INTEGER PRIMARY KEY,
    invoice_id       INTEGER NOT NULL REFERENCES invoices(id),
    note_id          INTEGER REFERENCES delivery_notes(id),
    item_id          INTEGER NOT NULL REFERENCES items(id),
    description      TEXT NOT NULL,
    quantity         INTEGER NOT NULL CHECK (quantity > 0),
    unit_price       INTEGER NOT NULL CHECK (unit_price >= 0),
    price_overridden INTEGER NOT NULL DEFAULT 0,
    line_total       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS payments (
    id          INTEGER PRIMARY KEY,
    invoice_id  INTEGER NOT NULL REFERENCES invoices(id),
    amount      INTEGER NOT NULL CHECK (amount > 0),
    method      TEXT NOT NULL,
    reference   TEXT NOT NULL DEFAULT '',
    paid_on     TEXT NOT NULL,
    status      TEXT NOT NULL CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
    entered_by  INTEGER NOT NULL REFERENCES users(id),
    created_at  TEXT NOT NULL,
    reviewed_by INTEGER REFERENCES users(id),
    reviewed_at TEXT,
    review_note TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_payments_invoice ON payments(invoice_id, status);

CREATE TABLE IF NOT EXISTS audit_log (
    id         INTEGER PRIMARY KEY,
    user_id    INTEGER REFERENCES users(id),
    action     TEXT NOT NULL,
    entity     TEXT NOT NULL,
    entity_id  INTEGER,
    detail     TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);
"""

Clock = Callable[[], dt.datetime]


def system_clock() -> dt.datetime:
    """Return the current local time without microseconds."""
    return dt.datetime.now().replace(microsecond=0)


class Database:
    """Thin wrapper around ``sqlite3`` used by every service.

    Args:
        path: location of the SQLite file.
        clock: callable returning "now"; replace it to simulate time.
    """

    def __init__(self, path, clock: Optional[Clock] = None):
        self.path = Path(path)
        self.clock: Clock = clock or system_clock
        self._local = threading.local()
        self._lock = threading.Lock()
        self._connections: list[sqlite3.Connection] = []

    # ------------------------------------------------------------------ connections
    @property
    def conn(self) -> sqlite3.Connection:
        """The connection that belongs to the calling thread (created on demand)."""
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self.path, isolation_level=None, timeout=10,
                                   check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute("PRAGMA journal_mode = WAL")
            self._local.conn = conn
            self._local.depth = 0
            with self._lock:
                self._connections.append(conn)
        return conn

    def close(self) -> None:
        """Close every connection opened by this object (call on shutdown)."""
        with self._lock:
            for conn in self._connections:
                conn.close()
            self._connections.clear()
        self._local = threading.local()

    # ------------------------------------------------------------------ time
    def now(self) -> str:
        """Return the current timestamp as ISO text, e.g. ``2026-03-01 14:05:00``."""
        return self.clock().isoformat(sep=" ")

    def today(self) -> dt.date:
        """Return the current date according to the injected clock."""
        return self.clock().date()

    # ------------------------------------------------------------------ queries
    @contextlib.contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        """Run a block atomically. Nested calls join the outer transaction."""
        conn = self.conn
        if self._local.depth == 0:
            conn.execute("BEGIN IMMEDIATE")
        self._local.depth += 1
        try:
            yield conn
        except BaseException:
            self._local.depth -= 1
            if self._local.depth == 0:
                conn.execute("ROLLBACK")
            raise
        else:
            self._local.depth -= 1
            if self._local.depth == 0:
                conn.execute("COMMIT")

    def execute(self, sql: str, params: Iterable[Any] = ()) -> int:
        """Execute a statement and return ``lastrowid``."""
        return self.conn.execute(sql, tuple(params)).lastrowid

    def query(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        """Return every row of a ``SELECT``."""
        return self.conn.execute(sql, tuple(params)).fetchall()

    def query_one(self, sql: str, params: Iterable[Any] = ()) -> Optional[sqlite3.Row]:
        """Return the first row of a ``SELECT`` or ``None``."""
        return self.conn.execute(sql, tuple(params)).fetchone()

    def scalar(self, sql: str, params: Iterable[Any] = (), default: Any = None) -> Any:
        """Return the first column of the first row, or ``default``."""
        row = self.query_one(sql, params)
        return default if row is None or row[0] is None else row[0]

    # ------------------------------------------------------------------ schema
    def initialize(self) -> None:
        """Create the schema if needed. Safe to call on every start-up."""
        self.conn.executescript(SCHEMA)
        self.conn.execute(
            "INSERT OR IGNORE INTO settings (key, value) VALUES ('schema_version', ?)",
            (str(SCHEMA_VERSION),))

    def is_initialized(self) -> bool:
        """Return True when the file exists and contains the application schema."""
        if not self.path.exists():
            return False
        return self.scalar("SELECT COUNT(*) FROM sqlite_master WHERE name = 'items'", (), 0) == 1
