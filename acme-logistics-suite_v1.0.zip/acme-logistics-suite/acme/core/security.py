"""Users, roles, permissions and password hashing.

Passwords are stored as salted PBKDF2-HMAC-SHA256 hashes (never in clear text).
Permissions are granted to roles in one table, :data:`ROLE_PERMISSIONS`, so the
whole access policy can be reviewed in a single place.
"""

import base64
import hashlib
import hmac
import secrets
from dataclasses import dataclass

from acme.core.errors import PermissionDeniedError

PBKDF2_ITERATIONS = 200_000

ROLES = {
    "admin": "Administrator",
    "manager": "Operations manager",
    "warehouse": "Warehouse clerk",
    "sales": "Sales representative",
    "accountant": "Accountant",
}

ALL_ROLES = frozenset(ROLES)

ROLE_PERMISSIONS = {
    "dashboard.view": ALL_ROLES,
    "inventory.view": ALL_ROLES,
    "inventory.move": {"admin", "manager", "warehouse"},
    "items.manage": {"admin", "manager"},
    "dispatch.view": ALL_ROLES,
    "dispatch.create": {"admin", "manager", "sales"},
    "dispatch.void": {"admin", "manager"},
    "dispatch.review": {"admin", "manager"},
    "customers.view": {"admin", "manager", "sales", "accountant"},
    "customers.manage": {"admin", "manager", "accountant"},
    "billing.view": {"admin", "accountant", "manager"},
    "billing.invoice": {"admin", "accountant"},
    "billing.prices": {"admin", "accountant"},
    "receivables.view": {"admin", "accountant", "manager", "sales"},
    "receivables.record": {"admin", "accountant", "sales"},
    "receivables.review": {"admin", "accountant"},
    "reports.view": {"admin", "manager", "accountant"},
    "legacy.exchange": {"admin", "accountant"},
    "admin.users": {"admin"},
    "admin.settings": {"admin"},
    "audit.view": {"admin", "manager"},
}


@dataclass(frozen=True)
class User:
    """The signed-in user, passed explicitly to every service call."""

    id: int
    username: str
    full_name: str
    role: str

    @property
    def role_label(self) -> str:
        """Human readable role name."""
        return ROLES.get(self.role, self.role)

    def can(self, permission: str) -> bool:
        """Return True when this user's role grants ``permission``."""
        return self.role in ROLE_PERMISSIONS.get(permission, ())

    def require(self, permission: str) -> None:
        """Raise :class:`PermissionDeniedError` unless the user has ``permission``."""
        if not self.can(permission):
            raise PermissionDeniedError(
                f"Your role ({self.role_label}) is not allowed to do this.")

    @property
    def sees_only_own_customers(self) -> bool:
        """Sales reps only see the customers assigned to them."""
        return self.role == "sales"


def hash_password(password: str, salt: bytes = None) -> str:
    """Return ``"pbkdf2$<iterations>$<salt>$<hash>"`` for ``password``."""
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, PBKDF2_ITERATIONS)
    encode = base64.b64encode
    return f"pbkdf2${PBKDF2_ITERATIONS}${encode(salt).decode()}${encode(digest).decode()}"


def verify_password(password: str, stored: str) -> bool:
    """Check ``password`` against a value produced by :func:`hash_password`."""
    try:
        _, iterations, salt_b64, hash_b64 = stored.split("$")
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(hash_b64)
    except ValueError:
        return False
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, int(iterations))
    return hmac.compare_digest(digest, expected)
