"""Money helpers.

All amounts are stored as integer cents to avoid floating point rounding errors.
Conversion to and from text happens only at the edges (forms, reports, CSV).
"""

from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

from acme.core.errors import BusinessRuleError


def to_cents(value) -> int:
    """Convert user input such as ``"1,299.90"``, ``12.5`` or ``Decimal`` to cents.

    Raises:
        BusinessRuleError: if the value is not a valid amount.
    """
    if isinstance(value, int):
        return value * 100
    text = str(value).strip().replace(",", "").replace("$", "")
    if not text:
        raise BusinessRuleError("Please enter an amount.")
    try:
        amount = Decimal(text)
    except InvalidOperation as exc:
        raise BusinessRuleError(f"'{value}' is not a valid amount.") from exc
    return int((amount * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def from_cents(cents: int) -> Decimal:
    """Return the amount as a ``Decimal`` with two decimal places."""
    return (Decimal(cents) / 100).quantize(Decimal("0.01"))


def format_money(cents: int, symbol: str = "$") -> str:
    """Format cents for display, e.g. ``-123456`` -> ``"-$1,234.56"``."""
    sign = "-" if cents < 0 else ""
    return f"{sign}{symbol}{abs(cents) / 100:,.2f}"


def percent_of(cents: int, rate_basis_points: int) -> int:
    """Return ``rate_basis_points`` (1 bp = 0.01 %) of ``cents``, rounded half up."""
    value = Decimal(cents) * Decimal(rate_basis_points) / Decimal(10_000)
    return int(value.quantize(Decimal("1"), rounding=ROUND_HALF_UP))
