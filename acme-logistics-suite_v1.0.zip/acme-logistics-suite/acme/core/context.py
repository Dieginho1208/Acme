"""Composition root: builds every service on top of one database."""

from pathlib import Path
from typing import Optional

from acme.core.database import Clock, Database
from acme.core.security import User
from acme.core.services.auth import AuthService
from acme.core.services.billing import BillingService
from acme.core.services.customers import CustomerService
from acme.core.services.dispatch import DispatchService
from acme.core.services.inventory import InventoryService
from acme.core.services.legacy_erp import LegacyErpBridge
from acme.core.services.receivables import ReceivablesService
from acme.core.services.reports import ReportService
from acme.core.services.settings import SettingsService


class AppContext:
    """Everything the UI needs: the services and the signed-in user.

    Views receive an ``AppContext`` and never touch SQL directly, which keeps
    the user interface and the data layer cleanly separated.
    """

    def __init__(self, db_path, clock: Optional[Clock] = None):
        self.db = Database(Path(db_path), clock)
        self.db.initialize()
        self.settings = SettingsService(self.db)
        self.settings.ensure_defaults()
        self.auth = AuthService(self.db)
        self.inventory = InventoryService(self.db)
        self.customers = CustomerService(self.db)
        self.dispatch = DispatchService(self.db, self.inventory, self.customers)
        self.billing = BillingService(self.db, self.settings)
        self.receivables = ReceivablesService(self.db, self.billing, self.customers)
        self.reports = ReportService(self.db, self.inventory, self.dispatch, self.receivables)
        self.legacy_erp = LegacyErpBridge(self.db, self.inventory)
        self.user: Optional[User] = None

    def sign_in(self, username: str, password: str) -> User:
        """Authenticate and remember the user for the rest of the session."""
        self.user = self.auth.login(username, password)
        return self.user

    def close(self) -> None:
        """Release database connections."""
        self.db.close()
