"""Customer master data."""

from typing import Optional

from acme.core.errors import BusinessRuleError, NotFoundError, PermissionDeniedError
from acme.core.security import User
from acme.core.services.base import Service


class CustomerService(Service):
    """Customers, their sales representative, price list and credit terms."""

    def list_customers(self, user: User, search: str = "",
                       include_inactive: bool = False) -> list:
        """Return the customers visible to ``user`` (sales reps only see their own)."""
        user.require("customers.view")
        sql = ("SELECT c.*, u.full_name AS sales_rep, p.name AS price_list "
               "FROM customers c LEFT JOIN users u ON u.id = c.sales_rep_id "
               "LEFT JOIN price_lists p ON p.id = c.price_list_id WHERE 1 = 1")
        params: list = []
        if not include_inactive:
            sql += " AND c.active = 1"
        if user.sees_only_own_customers:
            sql += " AND c.sales_rep_id = ?"
            params.append(user.id)
        if search.strip():
            like = f"%{search.strip()}%"
            sql += " AND (c.name LIKE ? OR c.code LIKE ? OR c.tax_id LIKE ?)"
            params += [like, like, like]
        return self.db.query(sql + " ORDER BY c.name", params)

    def get(self, user: User, customer_id: int):
        """One customer, enforcing the sales-rep visibility rule."""
        row = self.db.query_one(
            "SELECT c.*, u.full_name AS sales_rep, p.name AS price_list FROM customers c "
            "LEFT JOIN users u ON u.id = c.sales_rep_id "
            "LEFT JOIN price_lists p ON p.id = c.price_list_id WHERE c.id = ?", (customer_id,))
        if row is None:
            raise NotFoundError("That customer no longer exists.")
        self.check_visible(user, row)
        return row

    @staticmethod
    def check_visible(user: User, customer_row) -> None:
        """Raise if a sales rep tries to act on someone else's customer."""
        if user.sees_only_own_customers and customer_row["sales_rep_id"] != user.id:
            raise PermissionDeniedError("This customer is assigned to another sales rep.")

    def save(self, user: User, data: dict, customer_id: Optional[int] = None) -> int:
        """Create or update a customer from form data."""
        user.require("customers.manage")
        code = self.require_text(data.get("code"), "the customer code").upper()
        name = self.require_text(data.get("name"), "the customer name")
        try:
            credit_days = int(str(data.get("credit_days", 30)).strip() or 0)
        except ValueError as exc:
            raise BusinessRuleError("Credit days must be a whole number.") from exc
        if not 0 <= credit_days <= 365:
            raise BusinessRuleError("Credit days must be between 0 and 365.")
        if self.db.scalar("SELECT id FROM customers WHERE code = ? AND id IS NOT ?",
                          (code, customer_id)):
            raise BusinessRuleError(f"Another customer already uses the code {code}.")
        values = (code, name, (data.get("tax_id") or "").strip(),
                  (data.get("email") or "").strip(), (data.get("phone") or "").strip(),
                  (data.get("address") or "").strip(), data.get("sales_rep_id") or None,
                  data.get("price_list_id") or None, credit_days,
                  int(data.get("active", True)))
        with self.db.transaction():
            if customer_id is None:
                customer_id = self.db.execute(
                    "INSERT INTO customers (code, name, tax_id, email, phone, address, "
                    "sales_rep_id, price_list_id, credit_days, active) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", values)
                self.audit(user, "CREATE", "customer", customer_id, code)
            else:
                self.get(user, customer_id)
                self.db.execute(
                    "UPDATE customers SET code = ?, name = ?, tax_id = ?, email = ?, phone = ?,"
                    " address = ?, sales_rep_id = ?, price_list_id = ?, credit_days = ?,"
                    " active = ? WHERE id = ?", values + (customer_id,))
                self.audit(user, "UPDATE", "customer", customer_id, code)
        return customer_id
