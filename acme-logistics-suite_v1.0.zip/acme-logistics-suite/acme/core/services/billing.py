"""Price lists and invoicing of approved delivery notes.

Prices are dated: a new price applies from its ``valid_from`` date and older
prices stay in the history. An invoice is built in two steps:

1. :meth:`BillingService.build_draft` proposes a draft (nothing is saved), with
   each line priced from the customer's price list on the invoice date;
2. :meth:`BillingService.create_invoice` saves it, possibly with prices edited
   by the accountant, and marks the delivery notes as invoiced.
"""

import datetime as dt
from dataclasses import dataclass, field
from typing import Iterable, Optional

from acme.core.errors import BusinessRuleError, NotFoundError
from acme.core.money import percent_of, to_cents
from acme.core.security import User
from acme.core.services.base import Service
from acme.core.services.settings import SettingsService


@dataclass
class DraftLine:
    """One proposed invoice line (one item of one delivery note)."""

    note_id: int
    note_number: str
    item_id: int
    sku: str
    description: str
    quantity: int
    unit_price: int
    list_price: int

    @property
    def overridden(self) -> bool:
        """True when the accountant changed the list price."""
        return self.unit_price != self.list_price

    @property
    def total(self) -> int:
        """Line amount in cents."""
        return self.quantity * self.unit_price


@dataclass
class InvoiceDraft:
    """An invoice that has not been saved yet."""

    customer_id: int
    customer_name: str
    issue_date: dt.date
    due_date: dt.date
    tax_rate_bp: int
    lines: list = field(default_factory=list)

    @property
    def note_ids(self) -> list:
        """Delivery notes covered by this draft, without repetition."""
        return sorted({line.note_id for line in self.lines})

    @property
    def subtotal(self) -> int:
        """Sum of the lines, before tax."""
        return sum(line.total for line in self.lines)

    @property
    def tax_amount(self) -> int:
        """Sales tax on the subtotal."""
        return percent_of(self.subtotal, self.tax_rate_bp)

    @property
    def total(self) -> int:
        """Amount the customer owes."""
        return self.subtotal + self.tax_amount


class BillingService(Service):
    """Price lists, invoice drafts, invoices and invoice voiding."""

    def __init__(self, db, settings: SettingsService):
        super().__init__(db)
        self.settings = settings

    # ------------------------------------------------------------------ price lists
    def price_lists(self) -> list:
        """All price lists, the default one first."""
        return self.db.query("SELECT * FROM price_lists ORDER BY is_default DESC, name")

    def default_price_list_id(self) -> Optional[int]:
        """Id of the default price list, if one exists."""
        return self.db.scalar("SELECT id FROM price_lists WHERE is_default = 1")

    def create_price_list(self, user: User, name: str, is_default: bool = False) -> int:
        """Add a price list (optionally making it the default one)."""
        user.require("billing.prices")
        name = self.require_text(name, "the price list name")
        if self.db.scalar("SELECT 1 FROM price_lists WHERE name = ?", (name,)):
            raise BusinessRuleError(f"A price list called '{name}' already exists.")
        with self.db.transaction():
            if is_default:
                self.db.execute("UPDATE price_lists SET is_default = 0")
            list_id = self.db.execute("INSERT INTO price_lists (name, is_default) VALUES (?, ?)",
                                      (name, int(is_default)))
            self.audit(user, "CREATE", "price_list", list_id, name)
        return list_id

    def set_price(self, user: User, price_list_id: int, item_id: int, price,
                  valid_from: Optional[dt.date] = None) -> None:
        """Record a new price; earlier prices are kept as history."""
        user.require("billing.prices")
        cents = to_cents(price)
        if cents < 0:
            raise BusinessRuleError("Prices cannot be negative.")
        valid_from = valid_from or self.db.today()
        with self.db.transaction():
            self.db.execute(
                "INSERT INTO price_list_prices (price_list_id, item_id, price, valid_from, "
                "created_by, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (price_list_id, item_id, cents, valid_from.isoformat(), user.id,
                 self.db.now()))
            self.audit(user, "SET_PRICE", "item", item_id,
                       f"list={price_list_id}; {cents / 100:.2f} from {valid_from}")

    def effective_price(self, price_list_id: Optional[int], item_id: int,
                        on_date: dt.date) -> int:
        """Price of an item on a date: the list's latest price, else the item's base price."""
        if price_list_id:
            price = self.db.scalar(
                "SELECT price FROM price_list_prices WHERE price_list_id = ? AND item_id = ? "
                "AND valid_from <= ? ORDER BY valid_from DESC, id DESC LIMIT 1",
                (price_list_id, item_id, on_date.isoformat()))
            if price is not None:
                return int(price)
        return int(self.db.scalar("SELECT unit_price FROM items WHERE id = ?", (item_id,), 0))

    def price_history(self, price_list_id: int, item_id: int) -> list:
        """Every price recorded for an item in a list, newest first."""
        return self.db.query(
            "SELECT p.*, u.full_name AS created_by_name FROM price_list_prices p "
            "JOIN users u ON u.id = p.created_by WHERE p.price_list_id = ? AND p.item_id = ? "
            "ORDER BY p.valid_from DESC, p.id DESC", (price_list_id, item_id))

    def price_sheet(self, price_list_id: int, on_date: Optional[dt.date] = None) -> list:
        """``(item row, effective price)`` for every active item on a date."""
        on_date = on_date or self.db.today()
        items = self.db.query("SELECT id, sku, name, unit_price FROM items WHERE active = 1 "
                              "ORDER BY sku")
        return [(item, self.effective_price(price_list_id, item["id"], on_date))
                for item in items]

    # ------------------------------------------------------------------ drafts
    def notes_ready_to_invoice(self, customer_id: Optional[int] = None) -> list:
        """Approved delivery notes, grouped by customer."""
        sql = ("SELECT n.id, n.number, n.created_at, n.customer_id, c.name AS customer, "
               "(SELECT SUM(quantity) FROM delivery_note_lines WHERE note_id = n.id) AS units "
               "FROM delivery_notes n JOIN customers c ON c.id = n.customer_id "
               "WHERE n.status = 'APPROVED'")
        params: list = []
        if customer_id:
            sql += " AND n.customer_id = ?"
            params.append(customer_id)
        return self.db.query(sql + " ORDER BY c.name, n.number", params)

    def build_draft(self, user: User, customer_id: int, note_ids: Iterable[int],
                    issue_date: Optional[dt.date] = None) -> InvoiceDraft:
        """Propose an invoice for some approved notes of one customer (not saved)."""
        user.require("billing.invoice")
        note_ids = list(dict.fromkeys(note_ids))
        if not note_ids:
            raise BusinessRuleError("Select at least one delivery note to invoice.")
        customer = self.db.query_one("SELECT * FROM customers WHERE id = ?", (customer_id,))
        if customer is None:
            raise NotFoundError("That customer no longer exists.")
        issue_date = issue_date or self.db.today()
        price_list_id = customer["price_list_id"] or self.default_price_list_id()
        draft = InvoiceDraft(customer_id=customer_id, customer_name=customer["name"],
                             issue_date=issue_date,
                             due_date=issue_date + dt.timedelta(days=customer["credit_days"]),
                             tax_rate_bp=self.settings.tax_rate_bp)
        for note_id in note_ids:
            note = self._approved_note(note_id, customer_id)
            rows = self.db.query(
                "SELECT d.item_id, SUM(d.quantity) AS quantity, i.sku, i.name "
                "FROM delivery_note_lines d JOIN items i ON i.id = d.item_id "
                "WHERE d.note_id = ? GROUP BY d.item_id ORDER BY i.sku", (note_id,))
            for row in rows:
                price = self.effective_price(price_list_id, row["item_id"], issue_date)
                draft.lines.append(DraftLine(
                    note_id=note_id, note_number=note["number"], item_id=row["item_id"],
                    sku=row["sku"], description=row["name"], quantity=row["quantity"],
                    unit_price=price, list_price=price))
        return draft

    # ------------------------------------------------------------------ invoices
    def create_invoice(self, user: User, draft: InvoiceDraft) -> int:
        """Save a draft as an invoice; its notes become ``INVOICED``."""
        user.require("billing.invoice")
        if not draft.lines:
            raise BusinessRuleError("The invoice has no lines.")
        if any(line.unit_price < 0 for line in draft.lines):
            raise BusinessRuleError("Prices cannot be negative.")
        if draft.due_date < draft.issue_date:
            raise BusinessRuleError("The due date cannot be before the issue date.")
        with self.db.transaction():
            for note_id in draft.note_ids:         # re-check inside the transaction
                self._approved_note(note_id, draft.customer_id)
            number = self.next_number("next_invoice", "INV-")
            invoice_id = self.db.execute(
                "INSERT INTO invoices (number, customer_id, issue_date, due_date, subtotal, "
                "tax_rate_bp, tax_amount, total, status, created_by, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'OPEN', ?, ?)",
                (number, draft.customer_id, draft.issue_date.isoformat(),
                 draft.due_date.isoformat(), draft.subtotal, draft.tax_rate_bp,
                 draft.tax_amount, draft.total, user.id, self.db.now()))
            for line in draft.lines:
                self.db.execute(
                    "INSERT INTO invoice_lines (invoice_id, note_id, item_id, description, "
                    "quantity, unit_price, price_overridden, line_total) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (invoice_id, line.note_id, line.item_id, line.description, line.quantity,
                     line.unit_price, int(line.overridden), line.total))
            marks = ",".join("?" * len(draft.note_ids))
            self.db.execute(f"UPDATE delivery_notes SET status = 'INVOICED', invoice_id = ? "
                            f"WHERE id IN ({marks})", [invoice_id] + draft.note_ids)
            self.audit(user, "CREATE", "invoice", invoice_id,
                       f"{number} total={draft.total / 100:.2f}")
        return invoice_id

    def void_invoice(self, user: User, invoice_id: int, reason: str) -> None:
        """Void an invoice without approved payments; its notes can be invoiced again."""
        user.require("billing.invoice")
        reason = self.require_text(reason, "the reason", 5)
        invoice = self.get_invoice(invoice_id)
        if invoice["status"] == "VOID":
            raise BusinessRuleError(f"{invoice['number']} is already void.")
        if self.db.scalar("SELECT COUNT(*) FROM payments WHERE invoice_id = ? AND status IN "
                          "('APPROVED', 'PENDING')", (invoice_id,), 0):
            raise BusinessRuleError(f"{invoice['number']} has payments. Reject or reverse "
                                    "them before voiding the invoice.")
        with self.db.transaction():
            self.db.execute("UPDATE invoices SET status = 'VOID', void_reason = ? WHERE id = ?",
                            (reason, invoice_id))
            self.db.execute("UPDATE delivery_notes SET status = 'APPROVED', invoice_id = NULL "
                            "WHERE invoice_id = ?", (invoice_id,))
            self.audit(user, "VOID", "invoice", invoice_id, f"{invoice['number']}: {reason}")

    def get_invoice(self, invoice_id: int):
        """Invoice header with customer name and the approved amount paid."""
        row = self.db.query_one(
            "SELECT v.*, c.name AS customer, c.code AS customer_code, c.tax_id, c.address, "
            "c.sales_rep_id, COALESCE((SELECT SUM(amount) FROM payments WHERE invoice_id = v.id"
            " AND status = 'APPROVED'), 0) AS paid FROM invoices v "
            "JOIN customers c ON c.id = v.customer_id WHERE v.id = ?", (invoice_id,))
        if row is None:
            raise NotFoundError("That invoice no longer exists.")
        return row

    def invoice_lines(self, invoice_id: int) -> list:
        """Lines of an invoice with SKU and delivery note number."""
        return self.db.query(
            "SELECT l.*, i.sku, n.number AS note_number FROM invoice_lines l "
            "JOIN items i ON i.id = l.item_id LEFT JOIN delivery_notes n ON n.id = l.note_id "
            "WHERE l.invoice_id = ? ORDER BY l.id", (invoice_id,))

    def list_invoices(self, user: User, status: str = "", search: str = "",
                      customer_id: Optional[int] = None) -> list:
        """Invoices with paid amount and balance, newest first."""
        user.require("receivables.view")
        sql = ("SELECT v.*, c.name AS customer, c.code AS customer_code, "
               "COALESCE((SELECT SUM(amount) FROM payments WHERE invoice_id = v.id AND "
               "status = 'APPROVED'), 0) AS paid FROM invoices v "
               "JOIN customers c ON c.id = v.customer_id WHERE 1 = 1")
        params: list = []
        if status:
            sql += " AND v.status = ?"
            params.append(status)
        if customer_id:
            sql += " AND v.customer_id = ?"
            params.append(customer_id)
        if user.sees_only_own_customers:
            sql += " AND c.sales_rep_id = ?"
            params.append(user.id)
        if search.strip():
            like = f"%{search.strip()}%"
            sql += " AND (v.number LIKE ? OR c.name LIKE ?)"
            params += [like, like]
        return self.db.query(sql + " ORDER BY v.issue_date DESC, v.id DESC", params)

    # ------------------------------------------------------------------ helpers
    def _approved_note(self, note_id: int, customer_id: int):
        note = self.db.query_one("SELECT * FROM delivery_notes WHERE id = ?", (note_id,))
        if note is None:
            raise NotFoundError("A selected delivery note no longer exists.")
        if note["customer_id"] != customer_id:
            raise BusinessRuleError(f"{note['number']} belongs to another customer.")
        if note["status"] != "APPROVED":
            raise BusinessRuleError(f"{note['number']} is no longer ready to invoice.")
        return note
