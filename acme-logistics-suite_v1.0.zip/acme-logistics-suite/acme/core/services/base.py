"""Shared helpers for the business services."""

from typing import Optional

from acme.core.database import Database
from acme.core.errors import BusinessRuleError
from acme.core.security import User


class Service:
    """Base class: gives every service the database and an audit helper."""

    def __init__(self, db: Database):
        self.db = db

    def audit(self, user: Optional[User], action: str, entity: str,
              entity_id: Optional[int] = None, detail: str = "") -> None:
        """Append an entry to the audit log (inside the caller's transaction)."""
        self.db.execute(
            "INSERT INTO audit_log (user_id, action, entity, entity_id, detail, created_at)"
            " VALUES (?, ?, ?, ?, ?, ?)",
            (user.id if user else None, action, entity, entity_id, detail, self.db.now()))

    def next_number(self, key: str, prefix: str, width: int = 6) -> str:
        """Reserve the next document number for ``key`` (call inside a transaction)."""
        current = int(self.db.scalar("SELECT value FROM settings WHERE key = ?", (key,), 0))
        self.db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
                        (key, str(current + 1)))
        return f"{prefix}{current + 1:0{width}d}"

    @staticmethod
    def require_text(value: str, what: str, minimum: int = 1) -> str:
        """Return ``value`` stripped, or raise if it is shorter than ``minimum``."""
        text = (value or "").strip()
        if len(text) < minimum:
            if minimum <= 1:
                raise BusinessRuleError(f"Please enter {what}.")
            raise BusinessRuleError(f"{what.capitalize()} must have at least "
                                    f"{minimum} characters.")
        return text

    @staticmethod
    def require_positive_int(value, what: str) -> int:
        """Parse ``value`` as an integer greater than zero."""
        try:
            number = int(str(value).strip())
        except (TypeError, ValueError) as exc:
            raise BusinessRuleError(f"{what.capitalize()} must be a whole number.") from exc
        if number <= 0:
            raise BusinessRuleError(f"{what.capitalize()} must be greater than zero.")
        return number
