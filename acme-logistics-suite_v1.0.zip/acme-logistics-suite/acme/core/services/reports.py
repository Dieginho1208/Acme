"""Dashboard figures and CSV exports."""

import csv
import datetime as dt
from pathlib import Path

from acme.core.money import from_cents
from acme.core.security import User
from acme.core.services.base import Service
from acme.core.services.dispatch import DispatchService
from acme.core.services.inventory import InventoryService
from acme.core.services.receivables import AGING_BUCKETS, ReceivablesService

# Audit entities that each permission is allowed to see in "Recent activity".
ACTIVITY_SCOPE = {
    "inventory.view": ("item",),
    "dispatch.view": ("delivery_note",),
    "billing.view": ("invoice", "price_list"),
    "receivables.view": ("payment",),
    "customers.view": ("customer",),
    "admin.users": ("user", "settings", "legacy_erp"),
}


class ReportService(Service):
    """Key figures for the dashboard and spreadsheet-friendly exports."""

    def __init__(self, db, inventory: InventoryService, dispatch: DispatchService,
                 receivables: ReceivablesService):
        super().__init__(db)
        self.inventory = inventory
        self.dispatch = dispatch
        self.receivables = receivables

    def dashboard(self, user: User) -> dict:
        """Figures shown on the dashboard, limited to what ``user`` may see."""
        notes = self.dispatch.count_by_status(user)
        figures = {
            "active_items": self.db.scalar("SELECT COUNT(*) FROM items WHERE active = 1", (), 0),
            "units_on_hand": self.db.scalar("SELECT SUM(quantity) FROM stock", (), 0),
            "low_stock": len(self.inventory.low_stock_items()),
            "notes_awaiting": notes.get("ISSUED", 0),
            "notes_returned": notes.get("RETURNED", 0),
            "notes_to_invoice": notes.get("APPROVED", 0),
        }
        if user.can("reports.view"):
            figures["stock_value"] = self.inventory.stock_value()
        if user.can("receivables.view"):
            figures["outstanding"] = self.receivables.total_outstanding(user)
            figures["overdue"] = sum(r["overdue"] or 0
                                     for r in self.receivables.customer_balances(user))
            figures["payments_pending"] = len(self.receivables.list_payments(user, "PENDING"))
        return figures

    def units_shipped_by_day(self, days: int = 14) -> list:
        """``(date, units)`` shipped per day for the last ``days`` days (zeros included)."""
        start = self.db.today() - dt.timedelta(days=days - 1)
        rows = dict(self.db.query(
            "SELECT substr(created_at, 1, 10) AS day, -SUM(quantity) FROM stock_movements "
            "WHERE kind = 'DISPATCH' AND created_at >= ? GROUP BY day", (start.isoformat(),)))
        return [((start + dt.timedelta(days=i)),
                 int(rows.get((start + dt.timedelta(days=i)).isoformat(), 0)))
                for i in range(days)]

    def top_items(self, days: int = 30, limit: int = 8) -> list:
        """Best-selling items by units shipped in the last ``days`` days."""
        since = (self.db.today() - dt.timedelta(days=days)).isoformat()
        return self.db.query(
            "SELECT i.sku, i.name, -SUM(m.quantity) AS units FROM stock_movements m "
            "JOIN items i ON i.id = m.item_id WHERE m.kind = 'DISPATCH' AND m.created_at >= ? "
            "GROUP BY m.item_id ORDER BY units DESC LIMIT ?", (since, limit))

    def recent_activity(self, user: User, limit: int = 15) -> list:
        """Latest audit entries restricted to the areas ``user`` can see."""
        entities = sorted({e for perm, ents in ACTIVITY_SCOPE.items() if user.can(perm)
                           for e in ents})
        if not entities:
            return []
        marks = ",".join("?" * len(entities))
        own_only = " AND a.user_id = ?" if user.sees_only_own_customers else ""
        params = entities + ([user.id] if own_only else []) + [limit]
        return self.db.query(
            f"SELECT a.*, u.full_name AS user_name FROM audit_log a "
            f"LEFT JOIN users u ON u.id = a.user_id WHERE a.action <> 'LOGIN' "
            f"AND a.entity IN ({marks}){own_only} ORDER BY a.created_at DESC, a.id DESC "
            f"LIMIT ?", params)

    def audit_log(self, user: User, search: str = "", limit: int = 1000) -> list:
        """Full audit trail (managers and administrators)."""
        user.require("audit.view")
        sql = ("SELECT a.*, u.full_name AS user_name FROM audit_log a "
               "LEFT JOIN users u ON u.id = a.user_id")
        params: list = []
        if search.strip():
            like = f"%{search.strip()}%"
            sql += " WHERE a.action LIKE ? OR a.entity LIKE ? OR a.detail LIKE ? " \
                   "OR u.full_name LIKE ?"
            params = [like] * 4
        return self.db.query(sql + " ORDER BY a.created_at DESC, a.id DESC LIMIT ?",
                             params + [limit])

    # ------------------------------------------------------------------ exports
    def export_inventory_valuation(self, user: User, path) -> int:
        """Write stock per item with cost and value to CSV; returns rows written."""
        user.require("reports.view")
        rows = self.inventory.list_items()
        with Path(path).open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(["SKU", "Item", "Category", "On hand", "Unit cost", "Value",
                             "Reorder point"])
            for row in rows:
                writer.writerow([row["sku"], row["name"], row["category"], row["on_hand"],
                                 from_cents(row["unit_cost"]),
                                 from_cents(row["on_hand"] * row["unit_cost"]),
                                 row["reorder_point"]])
        return len(rows)

    def export_aging(self, user: User, path) -> int:
        """Write open balances per customer and aging bucket to CSV."""
        user.require("receivables.view")
        today = self.db.today()
        per_customer: dict = {}
        for invoice in self.receivables.billing.list_invoices(user, status="OPEN"):
            entry = per_customer.setdefault(
                invoice["customer_code"],
                {"name": invoice["customer"], **{k: 0 for k, *_ in AGING_BUCKETS}})
            days = (today - dt.date.fromisoformat(invoice["due_date"])).days
            entry[self.receivables.bucket_for(days)] += invoice["total"] - invoice["paid"]
        with Path(path).open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(["Customer code", "Customer"] + [b[1] for b in AGING_BUCKETS]
                            + ["Total"])
            for code, entry in sorted(per_customer.items()):
                amounts = [entry[b[0]] for b in AGING_BUCKETS]
                writer.writerow([code, entry["name"]] + [from_cents(a) for a in amounts]
                                + [from_cents(sum(amounts))])
        return len(per_customer)

    def export_statement(self, user: User, customer_id: int, path) -> int:
        """Write a customer's statement of account to CSV."""
        lines = self.receivables.statement(user, customer_id)
        with Path(path).open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(["Date", "Document", "Description", "Charge", "Credit", "Balance"])
            for line in lines:
                writer.writerow([line["date"], line["document"], line["description"],
                                 from_cents(line["charge"]), from_cents(line["credit"]),
                                 from_cents(line["balance"])])
        return len(lines)
