"""Delivery notes: the paperwork that travels with every shipment.

Life cycle::

    ISSUED ──approve──▶ APPROVED ──invoice──▶ INVOICED
       │  ▲                │ ▲                   │
       │  └──resubmit──┐   │ └──invoice voided───┘
       │               │   ▼
       ├──return──▶ RETURNED
       ▼               │
     VOID ◀────────────┘   (stock goes back to its bins)

Issuing a note takes the goods out of stock immediately; a manager then
approves it for billing or returns it to sales with a reason.
"""

from typing import Iterable, Optional

from acme.core.errors import BusinessRuleError, NotFoundError
from acme.core.security import User
from acme.core.services.base import Service
from acme.core.services.customers import CustomerService
from acme.core.services.inventory import InventoryService

STATUS_LABELS = {
    "ISSUED": "Awaiting approval",
    "APPROVED": "Ready to invoice",
    "RETURNED": "Returned to sales",
    "INVOICED": "Invoiced",
    "VOID": "Void",
}


class DispatchService(Service):
    """Create, review and void delivery notes."""

    def __init__(self, db, inventory: InventoryService, customers: CustomerService):
        super().__init__(db)
        self.inventory = inventory
        self.customers = customers

    # ------------------------------------------------------------------ queries
    def list_notes(self, user: User, status: str = "", customer_id: Optional[int] = None,
                   search: str = "", limit: int = 500) -> list:
        """Delivery notes visible to ``user``, newest first."""
        user.require("dispatch.view")
        sql = ("SELECT n.*, c.name AS customer, c.code AS customer_code, "
               "u.full_name AS created_by_name, r.full_name AS reviewed_by_name, "
               "i.number AS invoice_number, "
               "(SELECT SUM(quantity) FROM delivery_note_lines WHERE note_id = n.id) AS units "
               "FROM delivery_notes n JOIN customers c ON c.id = n.customer_id "
               "JOIN users u ON u.id = n.created_by LEFT JOIN users r ON r.id = n.reviewed_by "
               "LEFT JOIN invoices i ON i.id = n.invoice_id WHERE 1 = 1")
        params: list = []
        if status:
            sql += " AND n.status = ?"
            params.append(status)
        if customer_id:
            sql += " AND n.customer_id = ?"
            params.append(customer_id)
        if user.sees_only_own_customers:
            sql += " AND c.sales_rep_id = ?"
            params.append(user.id)
        if search.strip():
            like = f"%{search.strip()}%"
            sql += " AND (n.number LIKE ? OR c.name LIKE ?)"
            params += [like, like]
        return self.db.query(sql + " ORDER BY n.created_at DESC, n.id DESC LIMIT ?",
                             params + [limit])

    def get_note(self, note_id: int):
        """Header of one delivery note."""
        row = self.db.query_one(
            "SELECT n.*, c.name AS customer, c.sales_rep_id FROM delivery_notes n "
            "JOIN customers c ON c.id = n.customer_id WHERE n.id = ?", (note_id,))
        if row is None:
            raise NotFoundError("That delivery note no longer exists.")
        return row

    def note_lines(self, note_id: int) -> list:
        """Lines of a delivery note with item and location details."""
        return self.db.query(
            "SELECT d.*, i.sku, i.name AS item_name, i.unit, "
            "w.code || ' / ' || l.code AS location FROM delivery_note_lines d "
            "JOIN items i ON i.id = d.item_id JOIN locations l ON l.id = d.location_id "
            "JOIN warehouses w ON w.id = l.warehouse_id WHERE d.note_id = ? ORDER BY d.id",
            (note_id,))

    def count_by_status(self, user: User) -> dict:
        """``{status: count}`` for the notes ``user`` can see."""
        sql = ("SELECT n.status, COUNT(*) FROM delivery_notes n "
               "JOIN customers c ON c.id = n.customer_id")
        params: list = []
        if user.sees_only_own_customers:
            sql += " WHERE c.sales_rep_id = ?"
            params.append(user.id)
        return dict(self.db.query(sql + " GROUP BY n.status", params))

    # ------------------------------------------------------------------ commands
    def create_note(self, user: User, customer_id: int,
                    lines: Iterable[tuple], remarks: str = "") -> int:
        """Issue a delivery note and take its goods out of stock.

        Args:
            lines: ``(item_id, location_id, quantity)`` tuples.
        """
        user.require("dispatch.create")
        customer = self.customers.get(user, customer_id)
        if not customer["active"]:
            raise BusinessRuleError("This customer is inactive.")
        clean = []
        for item_id, location_id, quantity in lines:
            clean.append((item_id, location_id,
                          self.require_positive_int(quantity, "each line's quantity")))
        if not clean:
            raise BusinessRuleError("Add at least one line to the delivery note.")
        with self.db.transaction():
            number = self.next_number("next_delivery_note", "DN-")
            note_id = self.db.execute(
                "INSERT INTO delivery_notes (number, customer_id, status, remarks, created_by,"
                " created_at) VALUES (?, ?, 'ISSUED', ?, ?, ?)",
                (number, customer_id, remarks.strip(), user.id, self.db.now()))
            for item_id, location_id, quantity in clean:
                self.db.execute(
                    "INSERT INTO delivery_note_lines (note_id, item_id, location_id, quantity)"
                    " VALUES (?, ?, ?, ?)", (note_id, item_id, location_id, quantity))
                self.inventory.apply_movement(user, item_id, location_id, -quantity,
                                              "DISPATCH", number, customer["name"])
            self.audit(user, "ISSUE", "delivery_note", note_id,
                       f"{number} for {customer['code']}")
        return note_id

    def approve(self, user: User, note_id: int) -> None:
        """Approve an issued note so accounting can invoice it."""
        user.require("dispatch.review")
        note = self._require_status(note_id, ("ISSUED",), "approved")
        with self.db.transaction():
            self.db.execute(
                "UPDATE delivery_notes SET status = 'APPROVED', reviewed_by = ?, "
                "reviewed_at = ?, review_note = '' WHERE id = ?",
                (user.id, self.db.now(), note_id))
            self.audit(user, "APPROVE", "delivery_note", note_id, note["number"])

    def return_to_sales(self, user: User, note_id: int, reason: str) -> None:
        """Send a note back to sales with a reason (it will not be invoiced)."""
        user.require("dispatch.review")
        reason = self.require_text(reason, "the reason", 5)
        note = self._require_status(note_id, ("ISSUED", "APPROVED"), "returned")
        with self.db.transaction():
            self.db.execute(
                "UPDATE delivery_notes SET status = 'RETURNED', reviewed_by = ?, "
                "reviewed_at = ?, review_note = ? WHERE id = ?",
                (user.id, self.db.now(), reason, note_id))
            self.audit(user, "RETURN", "delivery_note", note_id, f"{note['number']}: {reason}")

    def resubmit(self, user: User, note_id: int, remarks: str = "") -> None:
        """Sales fixed the problem: put a returned note back in the approval queue."""
        user.require("dispatch.create")
        note = self._require_status(note_id, ("RETURNED",), "resubmitted")
        self.customers.check_visible(user, note)
        with self.db.transaction():
            self.db.execute(
                "UPDATE delivery_notes SET status = 'ISSUED', remarks = "
                "CASE WHEN ? = '' THEN remarks ELSE ? END WHERE id = ?",
                (remarks.strip(), remarks.strip(), note_id))
            self.audit(user, "RESUBMIT", "delivery_note", note_id, note["number"])

    def void(self, user: User, note_id: int, reason: str) -> None:
        """Cancel a note that was not invoiced and return its goods to stock."""
        user.require("dispatch.void")
        reason = self.require_text(reason, "the reason", 5)
        note = self._require_status(note_id, ("ISSUED", "RETURNED", "APPROVED"), "voided")
        with self.db.transaction():
            for line in self.note_lines(note_id):
                self.inventory.apply_movement(user, line["item_id"], line["location_id"],
                                              line["quantity"], "DISPATCH_VOID",
                                              note["number"], reason)
            self.db.execute("UPDATE delivery_notes SET status = 'VOID', void_reason = ? "
                            "WHERE id = ?", (reason, note_id))
            self.audit(user, "VOID", "delivery_note", note_id, f"{note['number']}: {reason}")

    # ------------------------------------------------------------------ helpers
    def _require_status(self, note_id: int, allowed: tuple, verb: str):
        note = self.get_note(note_id)
        if note["status"] not in allowed:
            raise BusinessRuleError(
                f"{note['number']} is '{STATUS_LABELS[note['status']]}' and cannot be {verb}.")
        return note
