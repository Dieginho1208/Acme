"""Items, stock levels and stock movements (the inventory ledger).

Every change in stock goes through :meth:`InventoryService.apply_movement`,
which writes one ``stock_movements`` row and updates the ``stock`` snapshot in
the same transaction. Stock can never go negative.
"""

from typing import Optional

from acme.core.errors import BusinessRuleError, NotFoundError
from acme.core.money import to_cents
from acme.core.security import User
from acme.core.services.base import Service

MOVEMENT_LABELS = {
    "RECEIPT": "Receipt",
    "TRANSFER_OUT": "Transfer out",
    "TRANSFER_IN": "Transfer in",
    "ADJUSTMENT": "Adjustment",
    "DISPATCH": "Dispatch",
    "DISPATCH_VOID": "Dispatch voided",
}


class InventoryService(Service):
    """Catalog maintenance, stock queries and stock movements."""

    # ------------------------------------------------------------------ lookups
    def categories(self) -> list:
        """All item categories."""
        return self.db.query("SELECT id, name FROM categories ORDER BY name")

    def warehouses(self) -> list:
        """Active warehouses."""
        return self.db.query("SELECT * FROM warehouses WHERE active = 1 ORDER BY code")

    def locations(self, warehouse_id: Optional[int] = None) -> list:
        """Active bin locations, labelled ``WAREHOUSE / BIN``."""
        sql = ("SELECT l.id, l.code, l.description, w.code AS warehouse_code, w.name "
               "AS warehouse_name, w.code || ' / ' || l.code AS label "
               "FROM locations l JOIN warehouses w ON w.id = l.warehouse_id "
               "WHERE l.active = 1 AND w.active = 1")
        params = []
        if warehouse_id:
            sql += " AND w.id = ?"
            params.append(warehouse_id)
        return self.db.query(sql + " ORDER BY w.code, l.code", params)

    def list_items(self, search: str = "", category_id: Optional[int] = None,
                   warehouse_id: Optional[int] = None, low_stock_only: bool = False,
                   include_inactive: bool = False) -> list:
        """Items with their on-hand quantity (optionally within one warehouse)."""
        params: list = []
        stock_filter = ""
        if warehouse_id:
            stock_filter = ("AND s.location_id IN "
                            "(SELECT id FROM locations WHERE warehouse_id = ?)")
            params.append(warehouse_id)
        sql = f"""
            SELECT i.*, c.name AS category,
                   COALESCE((SELECT SUM(s.quantity) FROM stock s
                             WHERE s.item_id = i.id {stock_filter}), 0) AS on_hand
            FROM items i JOIN categories c ON c.id = i.category_id
            WHERE 1 = 1"""
        if not include_inactive:
            sql += " AND i.active = 1"
        if search.strip():
            sql += " AND (i.sku LIKE ? OR i.name LIKE ? OR i.brand LIKE ? OR i.barcode = ?)"
            like = f"%{search.strip()}%"
            params += [like, like, like, search.strip()]
        if category_id:
            sql += " AND i.category_id = ?"
            params.append(category_id)
        sql = f"SELECT * FROM ({sql}) AS x"
        if low_stock_only:
            sql += " WHERE on_hand <= reorder_point"
        return self.db.query(sql + " ORDER BY sku", params)

    def get_item(self, item_id: int):
        """One item with its category name and total on-hand quantity."""
        row = self.db.query_one(
            "SELECT i.*, c.name AS category, COALESCE((SELECT SUM(quantity) FROM stock "
            "WHERE item_id = i.id), 0) AS on_hand FROM items i "
            "JOIN categories c ON c.id = i.category_id WHERE i.id = ?", (item_id,))
        if row is None:
            raise NotFoundError("That item no longer exists.")
        return row

    def stock_by_location(self, item_id: int) -> list:
        """On-hand quantity of one item per bin location (only bins with stock)."""
        return self.db.query(
            "SELECT s.location_id, s.quantity, w.code || ' / ' || l.code AS label, "
            "l.description FROM stock s JOIN locations l ON l.id = s.location_id "
            "JOIN warehouses w ON w.id = l.warehouse_id "
            "WHERE s.item_id = ? AND s.quantity > 0 ORDER BY w.code, l.code", (item_id,))

    def on_hand(self, item_id: int, location_id: int) -> int:
        """Quantity of ``item_id`` in ``location_id``."""
        return int(self.db.scalar("SELECT quantity FROM stock WHERE item_id = ? AND "
                                  "location_id = ?", (item_id, location_id), 0))

    def movements(self, item_id: Optional[int] = None, kind: str = "",
                  limit: int = 500) -> list:
        """Most recent stock movements, newest first."""
        sql = ("SELECT m.*, i.sku, i.name AS item_name, w.code || ' / ' || l.code AS location, "
               "u.full_name AS user_name FROM stock_movements m "
               "JOIN items i ON i.id = m.item_id JOIN locations l ON l.id = m.location_id "
               "JOIN warehouses w ON w.id = l.warehouse_id JOIN users u ON u.id = m.user_id "
               "WHERE 1 = 1")
        params: list = []
        if item_id:
            sql += " AND m.item_id = ?"
            params.append(item_id)
        if kind:
            sql += " AND m.kind = ?"
            params.append(kind)
        return self.db.query(sql + " ORDER BY m.created_at DESC, m.id DESC LIMIT ?",
                             params + [limit])

    def low_stock_items(self) -> list:
        """Active items at or below their reorder point."""
        return self.list_items(low_stock_only=True)

    def stock_value(self) -> int:
        """Inventory value at cost, in cents."""
        return int(self.db.scalar(
            "SELECT SUM(s.quantity * i.unit_cost) FROM stock s JOIN items i "
            "ON i.id = s.item_id WHERE i.active = 1", (), 0))

    # ------------------------------------------------------------------ catalog
    def save_item(self, user: User, data: dict, item_id: Optional[int] = None) -> int:
        """Create (``item_id=None``) or update an item from form data.

        ``data`` keys: sku, name, category_id, brand, barcode, unit, unit_cost,
        unit_price (text or numbers in currency units) and reorder_point.
        """
        user.require("items.manage")
        sku = self.require_text(data.get("sku"), "the SKU").upper()
        name = self.require_text(data.get("name"), "the item name")
        if not data.get("category_id"):
            raise BusinessRuleError("Please choose a category.")
        cost = to_cents(data.get("unit_cost", 0))
        price = to_cents(data.get("unit_price", 0))
        if cost < 0 or price < 0:
            raise BusinessRuleError("Prices cannot be negative.")
        try:
            reorder = int(str(data.get("reorder_point", 0) or 0).strip())
        except ValueError as exc:
            raise BusinessRuleError("The reorder point must be a whole number.") from exc
        if reorder < 0:
            raise BusinessRuleError("The reorder point cannot be negative.")
        clash = self.db.scalar("SELECT id FROM items WHERE sku = ? AND id IS NOT ?",
                               (sku, item_id))
        if clash:
            raise BusinessRuleError(f"Another item already uses the SKU {sku}.")
        values = (sku, name, int(data["category_id"]), (data.get("brand") or "").strip(),
                  (data.get("barcode") or "").strip(), (data.get("unit") or "ea").strip(),
                  cost, price, reorder, int(data.get("active", True)), self.db.now())
        with self.db.transaction():
            if item_id is None:
                item_id = self.db.execute(
                    "INSERT INTO items (sku, name, category_id, brand, barcode, unit, unit_cost,"
                    " unit_price, reorder_point, active, updated_at, created_at)"
                    " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", values + (self.db.now(),))
                self.audit(user, "CREATE", "item", item_id, sku)
            else:
                self.get_item(item_id)
                self.db.execute(
                    "UPDATE items SET sku = ?, name = ?, category_id = ?, brand = ?, barcode = ?,"
                    " unit = ?, unit_cost = ?, unit_price = ?, reorder_point = ?, active = ?,"
                    " updated_at = ? WHERE id = ?", values + (item_id,))
                self.audit(user, "UPDATE", "item", item_id, sku)
        return item_id

    def create_warehouse(self, user: User, code: str, name: str) -> int:
        """Add a warehouse (administrators only)."""
        user.require("admin.settings")
        code = self.require_text(code, "the warehouse code").upper()
        if self.db.scalar("SELECT 1 FROM warehouses WHERE code = ?", (code,)):
            raise BusinessRuleError(f"The warehouse {code} already exists.")
        with self.db.transaction():
            warehouse_id = self.db.execute("INSERT INTO warehouses (code, name) VALUES (?, ?)",
                                           (code, self.require_text(name, "the name")))
            self.audit(user, "CREATE", "warehouse", warehouse_id, code)
        return warehouse_id

    def create_location(self, user: User, warehouse_id: int, code: str,
                        description: str = "") -> int:
        """Add a bin location (aisle-rack-shelf) to a warehouse."""
        user.require("admin.settings")
        code = self.require_text(code, "the location code").upper()
        if self.db.scalar("SELECT 1 FROM locations WHERE warehouse_id = ? AND code = ?",
                          (warehouse_id, code)):
            raise BusinessRuleError(f"The location {code} already exists in that warehouse.")
        with self.db.transaction():
            return self.db.execute(
                "INSERT INTO locations (warehouse_id, code, description) VALUES (?, ?, ?)",
                (warehouse_id, code, description.strip()))

    def category_id(self, name: str) -> int:
        """Return the id of category ``name``, creating it if needed."""
        name = self.require_text(name, "the category name")
        existing = self.db.scalar("SELECT id FROM categories WHERE name = ?", (name,))
        if existing:
            return existing
        with self.db.transaction():
            return self.db.execute("INSERT INTO categories (name) VALUES (?)", (name,))

    # ------------------------------------------------------------------ movements
    def apply_movement(self, user: User, item_id: int, location_id: int, quantity: int,
                       kind: str, reference: str = "", note: str = "") -> int:
        """Add ``quantity`` (negative to remove) to a bin and log the movement.

        This is the only method that writes to ``stock``. It must run inside a
        transaction opened by the caller or by one of the public methods below.
        """
        if kind not in MOVEMENT_LABELS:
            raise BusinessRuleError(f"Unknown movement type '{kind}'.")
        current = self.on_hand(item_id, location_id)
        if current + quantity < 0:
            item = self.get_item(item_id)
            raise BusinessRuleError(
                f"Not enough stock of {item['sku']} in that location: {current} on hand, "
                f"{-quantity} requested.")
        updated = self.db.conn.execute(
            "UPDATE stock SET quantity = quantity + ? WHERE item_id = ? AND location_id = ?",
            (quantity, item_id, location_id)).rowcount
        if not updated:
            self.db.execute("INSERT INTO stock (item_id, location_id, quantity) VALUES (?, ?, ?)",
                            (item_id, location_id, quantity))
        return self.db.execute(
            "INSERT INTO stock_movements (item_id, location_id, quantity, kind, reference, "
            "note, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (item_id, location_id, quantity, kind, reference, note, user.id, self.db.now()))

    def receive(self, user: User, item_id: int, location_id: int, quantity,
                reference: str = "", note: str = "") -> None:
        """Book goods received from a supplier into a bin location."""
        user.require("inventory.move")
        qty = self.require_positive_int(quantity, "the quantity")
        item = self.get_item(item_id)
        with self.db.transaction():
            self.apply_movement(user, item_id, location_id, qty, "RECEIPT",
                                reference.strip(), note.strip())
            self.audit(user, "RECEIVE", "item", item_id, f"{item['sku']} +{qty}")

    def transfer(self, user: User, item_id: int, from_location: int, to_location: int,
                 quantity, note: str = "") -> None:
        """Move stock between two bins (possibly in different warehouses)."""
        user.require("inventory.move")
        qty = self.require_positive_int(quantity, "the quantity")
        if from_location == to_location:
            raise BusinessRuleError("Choose two different locations.")
        item = self.get_item(item_id)
        with self.db.transaction():
            reference = self.next_number("next_transfer", "TR-")
            self.apply_movement(user, item_id, from_location, -qty, "TRANSFER_OUT",
                                reference, note.strip())
            self.apply_movement(user, item_id, to_location, qty, "TRANSFER_IN",
                                reference, note.strip())
            self.audit(user, "TRANSFER", "item", item_id, f"{item['sku']} x{qty} {reference}")

    def adjust(self, user: User, item_id: int, location_id: int, counted, reason: str) -> int:
        """Set a bin to the physically counted quantity; returns the difference."""
        user.require("inventory.move")
        reason = self.require_text(reason, "the reason for the adjustment", 5)
        try:
            counted_qty = int(str(counted).strip())
        except ValueError as exc:
            raise BusinessRuleError("The counted quantity must be a whole number.") from exc
        if counted_qty < 0:
            raise BusinessRuleError("The counted quantity cannot be negative.")
        item = self.get_item(item_id)
        with self.db.transaction():
            difference = counted_qty - self.on_hand(item_id, location_id)
            if difference == 0:
                raise BusinessRuleError("The count matches the system; nothing to adjust.")
            self.apply_movement(user, item_id, location_id, difference, "ADJUSTMENT",
                                "COUNT", reason)
            self.audit(user, "ADJUST", "item", item_id,
                       f"{item['sku']} {difference:+d}: {reason}")
        return difference
