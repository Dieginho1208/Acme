"""Sign-in and user administration."""

from typing import Optional

from acme.core.errors import BusinessRuleError, NotFoundError
from acme.core.security import ROLES, User, hash_password, verify_password
from acme.core.services.base import Service

MIN_PASSWORD_LENGTH = 4


class AuthService(Service):
    """Authenticate users and manage accounts (administrators only)."""

    def login(self, username: str, password: str) -> User:
        """Return the :class:`User` for valid, active credentials.

        Raises:
            BusinessRuleError: with a deliberately generic message.
        """
        row = self.db.query_one("SELECT * FROM users WHERE username = ? AND active = 1",
                                ((username or "").strip(),))
        if row is None or not verify_password(password or "", row["password_hash"]):
            raise BusinessRuleError("Unknown user or wrong password.")
        user = self._to_user(row)
        with self.db.transaction():
            self.audit(user, "LOGIN", "user", user.id)
        return user

    def list_users(self, include_inactive: bool = True) -> list:
        """All user accounts, ordered by name."""
        sql = "SELECT id, username, full_name, role, active, created_at FROM users"
        if not include_inactive:
            sql += " WHERE active = 1"
        return self.db.query(sql + " ORDER BY full_name")

    def users_with_role(self, role: str) -> list[User]:
        """Active users with ``role`` (e.g. to pick a customer's sales rep)."""
        rows = self.db.query("SELECT * FROM users WHERE role = ? AND active = 1 "
                             "ORDER BY full_name", (role,))
        return [self._to_user(r) for r in rows]

    def create_user(self, actor: Optional[User], username: str, full_name: str, role: str,
                    password: str) -> int:
        """Create an account. ``actor`` may be ``None`` only during initial setup."""
        if actor is not None:
            actor.require("admin.users")
        username = self.require_text(username, "a username", 3).lower()
        full_name = self.require_text(full_name, "the full name")
        if role not in ROLES:
            raise BusinessRuleError(f"Unknown role '{role}'.")
        self._check_password(password)
        if self.db.scalar("SELECT 1 FROM users WHERE username = ?", (username,)):
            raise BusinessRuleError(f"The username '{username}' is already taken.")
        with self.db.transaction():
            user_id = self.db.execute(
                "INSERT INTO users (username, full_name, role, password_hash, created_at)"
                " VALUES (?, ?, ?, ?, ?)",
                (username, full_name, role, hash_password(password), self.db.now()))
            self.audit(actor, "CREATE", "user", user_id, f"{username} as {role}")
        return user_id

    def update_user(self, actor: User, user_id: int, full_name: str, role: str,
                    active: bool) -> None:
        """Change a user's name, role or active flag."""
        actor.require("admin.users")
        if role not in ROLES:
            raise BusinessRuleError(f"Unknown role '{role}'.")
        if user_id == actor.id and (not active or role != "admin"):
            raise BusinessRuleError("You cannot deactivate yourself or remove your own "
                                    "administrator role.")
        self._get_row(user_id)
        with self.db.transaction():
            self.db.execute("UPDATE users SET full_name = ?, role = ?, active = ? WHERE id = ?",
                            (self.require_text(full_name, "the full name"), role,
                             int(bool(active)), user_id))
            self.audit(actor, "UPDATE", "user", user_id, f"role={role}; active={active}")

    def reset_password(self, actor: User, user_id: int, new_password: str) -> None:
        """Set a new password for any user (administrators only)."""
        actor.require("admin.users")
        self._check_password(new_password)
        self._get_row(user_id)
        with self.db.transaction():
            self.db.execute("UPDATE users SET password_hash = ? WHERE id = ?",
                            (hash_password(new_password), user_id))
            self.audit(actor, "RESET_PASSWORD", "user", user_id)

    # ------------------------------------------------------------------ helpers
    def _get_row(self, user_id: int):
        row = self.db.query_one("SELECT * FROM users WHERE id = ?", (user_id,))
        if row is None:
            raise NotFoundError("That user no longer exists.")
        return row

    @staticmethod
    def _check_password(password: str) -> None:
        if len(password or "") < MIN_PASSWORD_LENGTH:
            raise BusinessRuleError(
                f"Passwords must have at least {MIN_PASSWORD_LENGTH} characters.")

    @staticmethod
    def _to_user(row) -> User:
        return User(id=row["id"], username=row["username"], full_name=row["full_name"],
                    role=row["role"])
