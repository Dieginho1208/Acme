"""Business services. Each service owns one area and enforces its rules.

Every public method that changes data:

1. checks the caller's permission,
2. validates the input and raises :class:`~acme.core.errors.BusinessRuleError`
   with a user-facing message when something is wrong,
3. runs inside one database transaction, and
4. writes an entry to the audit log.
"""
