"""Accounts receivable: payments, approvals, balances, aging and statements.

Sales reps can record payments for their own customers, but those payments stay
``PENDING`` until an accountant matches them against the bank and approves
them. Payments entered by an accountant are approved immediately. Only
approved payments reduce a balance.
"""

import datetime as dt
from typing import Optional

from acme.core.errors import BusinessRuleError, NotFoundError
from acme.core.money import format_money, to_cents
from acme.core.security import User
from acme.core.services.base import Service
from acme.core.services.billing import BillingService
from acme.core.services.customers import CustomerService

PAYMENT_METHODS = ("Bank transfer", "Card", "Check", "Cash", "Wire")

AGING_BUCKETS = (("current", "Current", None, 0), ("d1_30", "1-30 days", 1, 30),
                 ("d31_60", "31-60 days", 31, 60), ("d61_90", "61-90 days", 61, 90),
                 ("d90_plus", "Over 90 days", 91, None))


class ReceivablesService(Service):
    """Record and review payments; compute balances, aging and statements."""

    def __init__(self, db, billing: BillingService, customers: CustomerService):
        super().__init__(db)
        self.billing = billing
        self.customers = customers

    # ------------------------------------------------------------------ payments
    def record_payment(self, user: User, invoice_id: int, amount, method: str,
                       reference: str = "", paid_on: Optional[dt.date] = None) -> int:
        """Register a customer payment against an invoice.

        Returns the payment id. The payment is ``PENDING`` unless ``user`` can
        review payments, in which case it is approved right away.
        """
        user.require("receivables.record")
        invoice = self.billing.get_invoice(invoice_id)
        self.customers.check_visible(user, invoice)
        if invoice["status"] != "OPEN":
            raise BusinessRuleError(f"{invoice['number']} is not open for payments.")
        cents = to_cents(amount)
        if cents <= 0:
            raise BusinessRuleError("The amount must be greater than zero.")
        if method not in PAYMENT_METHODS:
            raise BusinessRuleError("Please choose a payment method.")
        pending = int(self.db.scalar("SELECT SUM(amount) FROM payments WHERE invoice_id = ? "
                                     "AND status = 'PENDING'", (invoice_id,), 0))
        open_amount = invoice["total"] - invoice["paid"] - pending
        if cents > open_amount:
            raise BusinessRuleError(
                f"The amount exceeds what is still open on {invoice['number']} "
                f"({format_money(max(open_amount, 0))}, counting payments awaiting approval).")
        paid_on = paid_on or self.db.today()
        if paid_on > self.db.today():
            raise BusinessRuleError("The payment date cannot be in the future.")
        auto_approve = user.can("receivables.review")
        with self.db.transaction():
            payment_id = self.db.execute(
                "INSERT INTO payments (invoice_id, amount, method, reference, paid_on, status,"
                " entered_by, created_at, reviewed_by, reviewed_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (invoice_id, cents, method, reference.strip(), paid_on.isoformat(),
                 "APPROVED" if auto_approve else "PENDING", user.id, self.db.now(),
                 user.id if auto_approve else None, self.db.now() if auto_approve else None))
            self.audit(user, "RECORD", "payment", payment_id,
                       f"{invoice['number']} {format_money(cents)}")
            if auto_approve:
                self._refresh_invoice_status(invoice_id)
        return payment_id

    def approve_payment(self, user: User, payment_id: int) -> None:
        """Confirm a pending payment (it now reduces the balance)."""
        user.require("receivables.review")
        payment = self._pending_payment(payment_id)
        with self.db.transaction():
            self.db.execute("UPDATE payments SET status = 'APPROVED', reviewed_by = ?, "
                            "reviewed_at = ? WHERE id = ?", (user.id, self.db.now(), payment_id))
            self._refresh_invoice_status(payment["invoice_id"])
            self.audit(user, "APPROVE", "payment", payment_id, format_money(payment["amount"]))

    def reject_payment(self, user: User, payment_id: int, reason: str) -> None:
        """Reject a pending payment with a reason (e.g. not found in the bank)."""
        user.require("receivables.review")
        reason = self.require_text(reason, "the reason", 5)
        payment = self._pending_payment(payment_id)
        with self.db.transaction():
            self.db.execute("UPDATE payments SET status = 'REJECTED', reviewed_by = ?, "
                            "reviewed_at = ?, review_note = ? WHERE id = ?",
                            (user.id, self.db.now(), reason, payment_id))
            self.audit(user, "REJECT", "payment", payment_id,
                       f"{format_money(payment['amount'])}: {reason}")

    def list_payments(self, user: User, status: str = "",
                      invoice_id: Optional[int] = None) -> list:
        """Payments visible to ``user``, newest first."""
        user.require("receivables.view")
        sql = ("SELECT p.*, v.number AS invoice_number, c.name AS customer, "
               "e.full_name AS entered_by_name, r.full_name AS reviewed_by_name "
               "FROM payments p JOIN invoices v ON v.id = p.invoice_id "
               "JOIN customers c ON c.id = v.customer_id JOIN users e ON e.id = p.entered_by "
               "LEFT JOIN users r ON r.id = p.reviewed_by WHERE 1 = 1")
        params: list = []
        if status:
            sql += " AND p.status = ?"
            params.append(status)
        if invoice_id:
            sql += " AND p.invoice_id = ?"
            params.append(invoice_id)
        if user.sees_only_own_customers:
            sql += " AND c.sales_rep_id = ?"
            params.append(user.id)
        return self.db.query(sql + " ORDER BY p.created_at DESC, p.id DESC", params)

    # ------------------------------------------------------------------ balances
    def customer_balances(self, user: User) -> list:
        """Open balance per customer (only customers that owe something)."""
        user.require("receivables.view")
        today = self.db.today().isoformat()
        sql = ("SELECT c.id, c.code, c.name, u.full_name AS sales_rep, COUNT(v.id) AS invoices,"
               " SUM(v.total - COALESCE(p.paid, 0)) AS balance,"
               " SUM(CASE WHEN v.due_date < ? THEN v.total - COALESCE(p.paid, 0) ELSE 0 END)"
               " AS overdue, MIN(v.due_date) AS oldest_due "
               "FROM invoices v JOIN customers c ON c.id = v.customer_id "
               "LEFT JOIN users u ON u.id = c.sales_rep_id "
               "LEFT JOIN (SELECT invoice_id, SUM(amount) AS paid FROM payments "
               "           WHERE status = 'APPROVED' GROUP BY invoice_id) p "
               "       ON p.invoice_id = v.id "
               "WHERE v.status = 'OPEN'")
        params: list = [today]
        if user.sees_only_own_customers:
            sql += " AND c.sales_rep_id = ?"
            params.append(user.id)
        return self.db.query(sql + " GROUP BY c.id ORDER BY balance DESC", params)

    def aging(self, user: User, as_of: Optional[dt.date] = None) -> dict:
        """Open balances by days past due: ``{bucket_key: cents}`` plus ``total``."""
        as_of = as_of or self.db.today()
        result = {key: 0 for key, *_ in AGING_BUCKETS}
        for invoice in self.billing.list_invoices(user, status="OPEN"):
            balance = invoice["total"] - invoice["paid"]
            days = (as_of - dt.date.fromisoformat(invoice["due_date"])).days
            result[self.bucket_for(days)] += balance
        result["total"] = sum(result.values())
        return result

    @staticmethod
    def bucket_for(days_past_due: int) -> str:
        """Aging bucket key for a number of days past the due date."""
        for key, _label, low, high in AGING_BUCKETS:
            if (low is None or days_past_due >= low) and (high is None
                                                          or days_past_due <= high):
                return key
        return "current"

    def statement(self, user: User, customer_id: int) -> list:
        """Chronological statement of account with a running balance.

        Returns dicts with ``date``, ``document``, ``description``, ``charge``,
        ``credit`` and ``balance`` (all amounts in cents).
        """
        customer = self.customers.get(user, customer_id)
        events = []
        for inv in self.db.query("SELECT * FROM invoices WHERE customer_id = ? AND status <> "
                                 "'VOID'", (customer["id"],)):
            events.append((inv["issue_date"], 0, inv["number"],
                           f"Invoice, due {inv['due_date']}", inv["total"], 0))
        for pay in self.db.query(
                "SELECT p.*, v.number FROM payments p JOIN invoices v ON v.id = p.invoice_id "
                "WHERE v.customer_id = ? AND p.status = 'APPROVED'", (customer["id"],)):
            events.append((pay["paid_on"], 1, pay["reference"] or f"PAY-{pay['id']}",
                           f"{pay['method']} for {pay['number']}", 0, pay["amount"]))
        balance = 0
        lines = []
        for date, _order, document, description, charge, credit in sorted(events):
            balance += charge - credit
            lines.append({"date": date, "document": document, "description": description,
                          "charge": charge, "credit": credit, "balance": balance})
        return lines

    def total_outstanding(self, user: User) -> int:
        """Sum of all open balances visible to ``user``."""
        return sum(row["balance"] or 0 for row in self.customer_balances(user))

    # ------------------------------------------------------------------ helpers
    def _pending_payment(self, payment_id: int):
        payment = self.db.query_one("SELECT * FROM payments WHERE id = ?", (payment_id,))
        if payment is None:
            raise NotFoundError("That payment no longer exists.")
        if payment["status"] != "PENDING":
            raise BusinessRuleError("This payment was already reviewed.")
        return payment

    def _refresh_invoice_status(self, invoice_id: int) -> None:
        invoice = self.billing.get_invoice(invoice_id)
        if invoice["status"] == "OPEN" and invoice["paid"] >= invoice["total"]:
            self.db.execute("UPDATE invoices SET status = 'PAID' WHERE id = ?", (invoice_id,))
