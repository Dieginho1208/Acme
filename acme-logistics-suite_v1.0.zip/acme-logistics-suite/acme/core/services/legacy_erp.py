"""Bridge to the *Legacy ERP* through CSV files.

Many companies replace an old ERP one module at a time. While both systems run
side by side, this bridge lets them exchange data without a direct database
connection:

* **Item catalog import** -- create or update items from the Legacy ERP's
  product export (matched by SKU). A dry run validates the file first.
* **Sales ledger export** -- invoices in the column layout the Legacy ERP's
  accounting module imports.
"""

import csv
import datetime as dt
from dataclasses import dataclass, field
from pathlib import Path

from acme.core.errors import BusinessRuleError
from acme.core.money import from_cents
from acme.core.security import User
from acme.core.services.base import Service
from acme.core.services.inventory import InventoryService

ITEM_COLUMNS = ("sku", "name", "category", "brand", "unit_cost", "unit_price",
                "reorder_point")
LEDGER_COLUMNS = ("DOC_TYPE", "DOC_NUMBER", "DOC_DATE", "DUE_DATE", "CUSTOMER_CODE",
                  "CUSTOMER_NAME", "CUSTOMER_TAX_ID", "NET_AMOUNT", "TAX_AMOUNT",
                  "TOTAL_AMOUNT", "STATUS")


@dataclass
class ImportReport:
    """Outcome of an item import (or of its dry run)."""

    created: int = 0
    updated: int = 0
    errors: list = field(default_factory=list)

    @property
    def ok(self) -> bool:
        """True when every row is valid."""
        return not self.errors

    def summary(self) -> str:
        """One-line, user-facing description of the result."""
        text = f"{self.created} new item(s), {self.updated} updated"
        if self.errors:
            text += f", {len(self.errors)} row(s) with errors"
        return text


class LegacyErpBridge(Service):
    """CSV exchange with the Legacy ERP."""

    def __init__(self, db, inventory: InventoryService):
        super().__init__(db)
        self.inventory = inventory

    def import_items(self, user: User, path, dry_run: bool = True) -> ImportReport:
        """Validate (``dry_run``) or apply an item catalog CSV.

        The import is all-or-nothing: if any row has an error, nothing is saved.
        """
        user.require("legacy.exchange")
        user.require("items.manage")
        report = ImportReport()
        with Path(path).open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            missing = [c for c in ITEM_COLUMNS if c not in (reader.fieldnames or ())]
            if missing:
                raise BusinessRuleError("The file is missing these columns: "
                                        + ", ".join(missing))
            rows = list(reader)
        try:
            with self.db.transaction():
                seen = set()
                for number, row in enumerate(rows, start=2):        # row 1 is the header
                    self._import_row(user, row, number, seen, report)
                if dry_run or report.errors:
                    raise _Rollback()
        except _Rollback:
            pass
        if not dry_run and report.ok:
            with self.db.transaction():
                self.audit(user, "IMPORT", "legacy_erp", None, report.summary())
        return report

    def _import_row(self, user, row, number, seen, report) -> None:
        sku = (row.get("sku") or "").strip().upper()
        if sku in seen:
            report.errors.append(f"Row {number}: SKU {sku} appears twice.")
            return
        seen.add(sku)
        existing = self.db.scalar("SELECT id FROM items WHERE sku = ?", (sku,))
        try:
            data = {key: (row.get(key) or "").strip() for key in ITEM_COLUMNS}
            data["category_id"] = (self.inventory.category_id(data["category"])
                                   if data["category"] else None)
            self.inventory.save_item(user, data, existing)
        except BusinessRuleError as exc:
            report.errors.append(f"Row {number}: {exc}")
            return
        if existing:
            report.updated += 1
        else:
            report.created += 1

    def export_sales_ledger(self, user: User, path, date_from: dt.date,
                            date_to: dt.date) -> int:
        """Write invoices issued between two dates in the Legacy ERP layout."""
        user.require("legacy.exchange")
        if date_to < date_from:
            raise BusinessRuleError("The end date is before the start date.")
        rows = self.db.query(
            "SELECT v.*, c.code, c.name, c.tax_id FROM invoices v "
            "JOIN customers c ON c.id = v.customer_id WHERE v.issue_date BETWEEN ? AND ? "
            "ORDER BY v.number", (date_from.isoformat(), date_to.isoformat()))
        with Path(path).open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(LEDGER_COLUMNS)
            for r in rows:
                void = r["status"] == "VOID"
                writer.writerow([
                    "INV", r["number"], r["issue_date"], r["due_date"], r["code"], r["name"],
                    r["tax_id"], from_cents(0 if void else r["subtotal"]),
                    from_cents(0 if void else r["tax_amount"]),
                    from_cents(0 if void else r["total"]), r["status"]])
        with self.db.transaction():
            self.audit(user, "EXPORT", "legacy_erp", None,
                       f"sales ledger {date_from}..{date_to}: {len(rows)} invoice(s)")
        return len(rows)


class _Rollback(Exception):
    """Internal signal used to undo a dry-run import."""
