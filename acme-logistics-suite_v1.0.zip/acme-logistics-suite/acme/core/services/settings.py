"""Company-wide settings stored in the ``settings`` table."""

from acme.core.errors import BusinessRuleError
from acme.core.money import to_cents
from acme.core.security import User
from acme.core.services.base import Service

DEFAULTS = {
    "company_name": "Acme Logistics",
    "company_address": "100 Example Street, Springfield",
    "currency_symbol": "$",
    "tax_rate_bp": "825",            # 8.25 %, in basis points
    "low_stock_warning": "1",
}


class SettingsService(Service):
    """Read and update company settings (name, tax rate, numbering...)."""

    def get(self, key: str) -> str:
        """Return a setting, falling back to :data:`DEFAULTS`."""
        return str(self.db.scalar("SELECT value FROM settings WHERE key = ?", (key,),
                                  DEFAULTS.get(key, "")))

    def ensure_defaults(self) -> None:
        """Insert any missing default setting (keeps existing values)."""
        with self.db.transaction():
            for key, value in DEFAULTS.items():
                self.db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
                                (key, value))

    @property
    def company_name(self) -> str:
        """Name printed on screens, exports and invoices."""
        return self.get("company_name")

    @property
    def tax_rate_bp(self) -> int:
        """Sales tax in basis points (825 = 8.25 %)."""
        return int(self.get("tax_rate_bp") or 0)

    def update(self, user: User, company_name: str, company_address: str,
               tax_rate_percent: str) -> None:
        """Save the editable settings shown in Administration > Settings."""
        user.require("admin.settings")
        name = self.require_text(company_name, "the company name")
        rate_bp = to_cents(tax_rate_percent)          # "8.25" -> 825
        if not 0 <= rate_bp <= 5000:
            raise BusinessRuleError("The tax rate must be between 0 % and 50 %.")
        with self.db.transaction():
            for key, value in (("company_name", name),
                               ("company_address", (company_address or "").strip()),
                               ("tax_rate_bp", str(rate_bp))):
                self.db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
                                (key, value))
            self.audit(user, "UPDATE", "settings", None,
                       f"company={name}; tax={rate_bp / 100:.2f}%")
