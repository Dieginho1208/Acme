"""Exceptions raised by the model layer.

Views catch :class:`BusinessRuleError` (and its subclasses) and show the message
to the user as-is, so messages are written in plain, user-facing English.
"""


class BusinessRuleError(Exception):
    """An operation was rejected because it would break a business rule."""


class PermissionDeniedError(BusinessRuleError):
    """The signed-in user's role does not allow the requested operation."""


class NotFoundError(BusinessRuleError):
    """A record that the operation depends on does not exist."""
