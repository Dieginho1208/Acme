"""The demo database generator."""

import tempfile
import unittest
from pathlib import Path

import setup_mock_db
from acme.core.context import AppContext


class MockDatabaseTests(unittest.TestCase):

    def test_generator_builds_a_consistent_database(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "inventory_mock.db"
            self.assertEqual(setup_mock_db.main(["--path", str(path), "--days", "30",
                                                 "--force"]), 0)
            app = AppContext(path)
            try:
                db = app.db
                self.assertEqual(db.scalar("SELECT COUNT(*) FROM items"), 100)
                self.assertEqual(db.scalar("SELECT COUNT(DISTINCT sku) FROM items"), 100)
                self.assertEqual(db.scalar("SELECT COUNT(*) FROM categories"), 10)
                self.assertEqual(db.scalar("SELECT COUNT(*) FROM stock WHERE quantity < 0"), 0)
                # The stock snapshot equals the sum of the movement ledger.
                drift = db.scalar(
                    "SELECT COUNT(*) FROM (SELECT item_id, location_id, SUM(quantity) AS q "
                    "FROM stock_movements GROUP BY 1, 2) m LEFT JOIN stock s "
                    "USING (item_id, location_id) WHERE m.q <> COALESCE(s.quantity, 0)")
                self.assertEqual(drift, 0)
                for role in ("admin", "manager", "warehouse", "sales", "accountant"):
                    user = app.sign_in(role, setup_mock_db.DEMO_PASSWORD)
                    self.assertIsInstance(app.reports.dashboard(user), dict)
            finally:
                app.close()

    def test_catalog_has_one_hundred_unique_products(self):
        products = [p for group in setup_mock_db.CATALOG.values() for p in group]
        self.assertEqual(len(products), 100)
        self.assertEqual(len({p[0] for p in products}), 100)
        self.assertTrue(all(price > cost for _n, _b, cost, price, _r in products))
