"""Payments, approvals, aging and statements."""

from acme.core.errors import BusinessRuleError, PermissionDeniedError
from tests.helpers import AppTestCase


class ReceivablesTests(AppTestCase):

    def setUp(self):
        super().setUp()
        self.invoice_id = self.invoice([self.issue_and_approve(quantity=10)])   # $108.25

    def test_sales_payment_waits_for_approval(self):
        rec = self.app.receivables
        payment = rec.record_payment(self.users["rep1"], self.invoice_id, "50", "Check", "123")
        self.assertEqual(self.app.billing.get_invoice(self.invoice_id)["paid"], 0)
        rec.approve_payment(self.users["acct"], payment)
        self.assertEqual(self.app.billing.get_invoice(self.invoice_id)["paid"], 5000)

    def test_accountant_payment_is_approved_and_settles_invoice(self):
        self.app.receivables.record_payment(self.users["acct"], self.invoice_id, "108.25",
                                            "Wire")
        self.assertEqual(self.app.billing.get_invoice(self.invoice_id)["status"], "PAID")

    def test_overpayment_counts_pending_payments(self):
        rec = self.app.receivables
        rec.record_payment(self.users["rep1"], self.invoice_id, "100", "Card")
        with self.assertRaises(BusinessRuleError):
            rec.record_payment(self.users["rep1"], self.invoice_id, "10", "Card")

    def test_rejected_payment_does_not_count(self):
        rec = self.app.receivables
        payment = rec.record_payment(self.users["rep1"], self.invoice_id, "100", "Card")
        rec.reject_payment(self.users["acct"], payment, "Not in the bank")
        with self.assertRaises(BusinessRuleError):
            rec.approve_payment(self.users["acct"], payment)
        self.assertEqual(rec.total_outstanding(self.users["acct"]), 10825)

    def test_rep_cannot_collect_for_another_reps_customer(self):
        with self.assertRaises(PermissionDeniedError):
            self.app.receivables.record_payment(self.users["rep2"], self.invoice_id, "1",
                                                "Card")

    def test_aging_buckets(self):
        rec = self.app.receivables
        self.assertEqual(rec.aging(self.users["acct"])["current"], 10825)
        self.clock.advance(days=30 + 45)                     # 45 days past due
        aging = rec.aging(self.users["acct"])
        self.assertEqual((aging["d31_60"], aging["total"]), (10825, 10825))
        self.assertEqual(rec.bucket_for(0), "current")
        self.assertEqual(rec.bucket_for(91), "d90_plus")

    def test_statement_running_balance(self):
        rec = self.app.receivables
        self.clock.advance(days=3)
        rec.record_payment(self.users["acct"], self.invoice_id, "8.25", "Card", "R1")
        lines = rec.statement(self.users["acct"], self.customer1)
        self.assertEqual([line["balance"] for line in lines], [10825, 10000])

    def test_sales_rep_sees_only_own_balances(self):
        self.invoice([self.issue_and_approve(self.customer2, rep="rep2")], self.customer2)
        names = [r["name"] for r in self.app.receivables.customer_balances(self.users["rep1"])]
        self.assertEqual(names, ["First Co"])
