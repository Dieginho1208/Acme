"""Stock movements and catalog rules."""

from acme.core.errors import BusinessRuleError, PermissionDeniedError
from tests.helpers import AppTestCase


class InventoryTests(AppTestCase):

    def test_receive_adds_stock_and_logs_movement(self):
        inv = self.app.inventory
        inv.receive(self.users["clerk"], self.mouse, self.bin_b, 7, "PO-1")
        self.assertEqual(inv.on_hand(self.mouse, self.bin_b), 7)
        self.assertEqual(inv.get_item(self.mouse)["on_hand"], 57)
        latest = inv.movements(item_id=self.mouse)[0]
        self.assertEqual((latest["kind"], latest["quantity"], latest["reference"]),
                         ("RECEIPT", 7, "PO-1"))

    def test_transfer_moves_between_locations(self):
        inv = self.app.inventory
        inv.transfer(self.users["clerk"], self.mouse, self.bin_a, self.bin_b, 20)
        self.assertEqual(inv.on_hand(self.mouse, self.bin_a), 30)
        self.assertEqual(inv.on_hand(self.mouse, self.bin_b), 20)
        kinds = {m["kind"] for m in inv.movements(item_id=self.mouse, limit=2)}
        self.assertEqual(kinds, {"TRANSFER_OUT", "TRANSFER_IN"})

    def test_stock_never_goes_negative(self):
        with self.assertRaises(BusinessRuleError):
            self.app.inventory.transfer(self.users["clerk"], self.mouse, self.bin_a,
                                        self.bin_b, 51)
        self.assertEqual(self.app.inventory.on_hand(self.mouse, self.bin_a), 50)
        self.assertEqual(self.app.inventory.on_hand(self.mouse, self.bin_b), 0)

    def test_adjustment_posts_the_difference(self):
        diff = self.app.inventory.adjust(self.users["clerk"], self.mouse, self.bin_a, 47,
                                         "Cycle count")
        self.assertEqual(diff, -3)
        self.assertEqual(self.app.inventory.on_hand(self.mouse, self.bin_a), 47)

    def test_adjustment_requires_reason_and_a_difference(self):
        inv = self.app.inventory
        with self.assertRaises(BusinessRuleError):
            inv.adjust(self.users["clerk"], self.mouse, self.bin_a, 40, "")
        with self.assertRaises(BusinessRuleError):
            inv.adjust(self.users["clerk"], self.mouse, self.bin_a, 50, "Cycle count")

    def test_sales_rep_cannot_move_stock(self):
        with self.assertRaises(PermissionDeniedError):
            self.app.inventory.receive(self.users["rep1"], self.mouse, self.bin_a, 1)

    def test_duplicate_sku_is_rejected(self):
        with self.assertRaises(BusinessRuleError):
            self.app.inventory.save_item(self.users["admin"], {
                "sku": "m-1", "name": "Other", "category_id": 1})

    def test_low_stock_filter(self):
        self.app.inventory.adjust(self.users["clerk"], self.mouse, self.bin_a, 5, "Count")
        low = [r["sku"] for r in self.app.inventory.low_stock_items()]
        self.assertEqual(low, ["M-1"])

    def test_stock_value_at_cost(self):
        self.assertEqual(self.app.inventory.stock_value(), 50 * 500 + 10 * 2000)
