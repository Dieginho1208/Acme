"""Test-suite. Password hashing is made cheaper here so the tests run fast."""

from acme.core import security

security.PBKDF2_ITERATIONS = 1_000
