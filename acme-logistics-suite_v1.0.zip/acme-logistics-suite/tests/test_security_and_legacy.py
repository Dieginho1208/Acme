"""Authentication, permissions, settings and the Legacy ERP bridge."""

import csv
import datetime as dt
from pathlib import Path

from acme.core.errors import BusinessRuleError, PermissionDeniedError
from acme.core.money import format_money, percent_of, to_cents
from acme.core.security import hash_password, verify_password
from tests.helpers import AppTestCase


class SecurityTests(AppTestCase):

    def test_password_hash_round_trip(self):
        stored = hash_password("correct horse")
        self.assertTrue(verify_password("correct horse", stored))
        self.assertFalse(verify_password("wrong", stored))
        self.assertNotIn("correct horse", stored)

    def test_login(self):
        self.assertEqual(self.app.sign_in("ADMIN", "secret").role, "admin")
        with self.assertRaises(BusinessRuleError):
            self.app.sign_in("admin", "nope")

    def test_inactive_user_cannot_sign_in(self):
        rep = self.users["rep1"]
        self.app.auth.update_user(self.users["admin"], rep.id, rep.full_name, "sales", False)
        with self.assertRaises(BusinessRuleError):
            self.app.sign_in("rep1", "secret")

    def test_admin_cannot_lock_themselves_out(self):
        admin = self.users["admin"]
        with self.assertRaises(BusinessRuleError):
            self.app.auth.update_user(admin, admin.id, "Admin", "sales", True)

    def test_only_admin_manages_users(self):
        with self.assertRaises(PermissionDeniedError):
            self.app.auth.create_user(self.users["manager"], "x123", "X", "sales", "secret")

    def test_settings_validation(self):
        with self.assertRaises(BusinessRuleError):
            self.app.settings.update(self.users["admin"], "Acme", "", "75")
        self.app.settings.update(self.users["admin"], "Acme West", "1 Road", "7.5")
        self.assertEqual(self.app.settings.tax_rate_bp, 750)

    def test_money_helpers(self):
        self.assertEqual(to_cents("1,299.995"), 130000)
        self.assertEqual(format_money(-123456), "-$1,234.56")
        self.assertEqual(percent_of(10000, 825), 825)
        with self.assertRaises(BusinessRuleError):
            to_cents("abc")

    def test_audit_log_records_changes(self):
        self.issue_and_approve()
        actions = {r["action"] for r in self.app.reports.audit_log(self.users["admin"])}
        self.assertTrue({"ISSUE", "APPROVE", "RECEIVE", "CREATE"} <= actions)


class LegacyErpTests(AppTestCase):

    def _write(self, rows):
        path = Path(self._tmp.name) / "items.csv"
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(["sku", "name", "category", "brand", "unit_cost", "unit_price",
                             "reorder_point"])
            writer.writerows(rows)
        return path

    def test_dry_run_saves_nothing(self):
        path = self._write([["N-1", "New thing", "Audio", "B", "1", "2", "3"],
                            ["M-1", "Mouse v2", "Peripherals", "", "5", "12", "5"]])
        report = self.app.legacy_erp.import_items(self.users["admin"], path, dry_run=True)
        self.assertEqual((report.created, report.updated, report.ok), (1, 1, True))
        self.assertEqual(self.app.inventory.get_item(self.mouse)["name"], "Mouse")

    def test_import_applies_when_valid(self):
        path = self._write([["N-1", "New thing", "Audio", "B", "1", "2", "3"]])
        report = self.app.legacy_erp.import_items(self.users["admin"], path, dry_run=False)
        self.assertTrue(report.ok)
        self.assertEqual(len(self.app.inventory.list_items(search="N-1")), 1)

    def test_import_with_errors_is_all_or_nothing(self):
        path = self._write([["N-1", "New thing", "Audio", "B", "1", "2", "3"],
                            ["N-2", "", "Audio", "B", "1", "2", "3"],
                            ["N-1", "Again", "Audio", "B", "1", "2", "3"]])
        report = self.app.legacy_erp.import_items(self.users["admin"], path, dry_run=False)
        self.assertEqual(len(report.errors), 2)
        self.assertEqual(self.app.inventory.list_items(search="N-"), [])

    def test_sales_ledger_export(self):
        self.invoice([self.issue_and_approve()])
        path = Path(self._tmp.name) / "ledger.csv"
        count = self.app.legacy_erp.export_sales_ledger(
            self.users["acct"], path, dt.date(2026, 3, 1), dt.date(2026, 3, 31))
        self.assertEqual(count, 1)
        with path.open(encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        self.assertEqual((rows[0]["DOC_NUMBER"], rows[0]["TOTAL_AMOUNT"]),
                         ("INV-000001", "43.30"))
