"""Shared fixtures for the test-suite."""

import datetime as dt
import tempfile
import unittest
from pathlib import Path

from acme.core.context import AppContext


class FakeClock:
    """A clock the tests can move forward."""

    def __init__(self, start=dt.datetime(2026, 3, 2, 9, 0)):
        self.now = start

    def __call__(self):
        return self.now

    def advance(self, days=0, hours=0):
        """Move time forward."""
        self.now += dt.timedelta(days=days, hours=hours)


class AppTestCase(unittest.TestCase):
    """Fresh database with a small catalog, one warehouse and two customers."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.clock = FakeClock()
        self.app = AppContext(Path(self._tmp.name) / "test.db", clock=self.clock)
        auth = self.app.auth
        for username, role in (("admin", "admin"), ("manager", "manager"),
                               ("clerk", "warehouse"), ("rep1", "sales"), ("rep2", "sales"),
                               ("acct", "accountant")):
            auth.create_user(None, username, username.title(), role, "secret")
        self.users = {u["username"]: self.app.auth.login(u["username"], "secret")
                      for u in auth.list_users()}
        admin = self.users["admin"]
        inv = self.app.inventory
        warehouse = inv.create_warehouse(admin, "MAIN", "Main")
        self.bin_a = inv.create_location(admin, warehouse, "A01")
        self.bin_b = inv.create_location(admin, warehouse, "B01")
        category = inv.category_id("Peripherals")
        self.mouse = inv.save_item(admin, {"sku": "M-1", "name": "Mouse", "category_id": category,
                                           "unit_cost": "5", "unit_price": "10.00",
                                           "reorder_point": 5})
        self.keyboard = inv.save_item(admin, {"sku": "K-1", "name": "Keyboard",
                                              "category_id": category, "unit_cost": "20",
                                              "unit_price": "40.00", "reorder_point": 2})
        inv.receive(self.users["clerk"], self.mouse, self.bin_a, 50)
        inv.receive(self.users["clerk"], self.keyboard, self.bin_a, 10)
        self.price_list = self.app.billing.create_price_list(self.users["acct"], "Standard",
                                                             is_default=True)
        manager = self.users["manager"]
        self.customer1 = self.app.customers.save(manager, {
            "code": "C1", "name": "First Co", "sales_rep_id": self.users["rep1"].id,
            "credit_days": 30})
        self.customer2 = self.app.customers.save(manager, {
            "code": "C2", "name": "Second Co", "sales_rep_id": self.users["rep2"].id,
            "credit_days": 15})

    def tearDown(self):
        self.app.close()
        self._tmp.cleanup()

    def issue_and_approve(self, customer=None, quantity=4, rep="rep1"):
        """Issue a delivery note for mice and approve it; returns its id."""
        note = self.app.dispatch.create_note(self.users[rep], customer or self.customer1,
                                             [(self.mouse, self.bin_a, quantity)])
        self.app.dispatch.approve(self.users["manager"], note)
        return note

    def invoice(self, note_ids, customer=None):
        """Invoice approved notes at list price; returns the invoice id."""
        acct = self.users["acct"]
        draft = self.app.billing.build_draft(acct, customer or self.customer1, note_ids)
        return self.app.billing.create_invoice(acct, draft)
