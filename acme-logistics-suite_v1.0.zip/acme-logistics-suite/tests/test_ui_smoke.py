"""Open every page for every role (skipped when no display is available)."""

import os
import tempfile
import time
import unittest
from pathlib import Path

try:
    import tkinter
except ImportError:                       # pragma: no cover - depends on the platform
    tkinter = None

import setup_mock_db


@unittest.skipIf(tkinter is None, "tkinter is not installed")
@unittest.skipIf(os.name != "nt" and not os.environ.get("DISPLAY"), "no display")
class UiSmokeTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls._tmp = tempfile.TemporaryDirectory()
        cls.path = Path(cls._tmp.name) / "ui.db"
        setup_mock_db.main(["--path", str(cls.path), "--days", "20", "--force"])

    @classmethod
    def tearDownClass(cls):
        cls._tmp.cleanup()

    def test_every_page_opens_for_every_role(self):
        from acme.core.context import AppContext
        from acme.ui.app import Application
        for username in ("admin", "manager", "warehouse", "sales", "accountant"):
            with self.subTest(user=username):
                app = Application(AppContext(self.path))
                try:
                    app.ctx.sign_in(username, setup_mock_db.DEMO_PASSWORD)
                    app.on_signed_in()
                    window = app.screen
                    for key, *_rest in window.allowed:
                        window.show(key)
                        app.root.update()
                    self.assertTrue(window.allowed)
                    for _ in range(20):          # let background loads finish
                        app.root.update()
                        time.sleep(0.03)
                finally:
                    app.root.destroy()
                    app.ctx.close()
