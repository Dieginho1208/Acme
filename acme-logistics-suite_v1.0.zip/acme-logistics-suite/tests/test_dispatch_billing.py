"""Delivery note life cycle, price lists and invoicing."""

import datetime as dt

from acme.core.errors import BusinessRuleError, PermissionDeniedError
from tests.helpers import AppTestCase


class DispatchTests(AppTestCase):

    def test_issuing_takes_goods_out_of_stock(self):
        note = self.app.dispatch.create_note(self.users["rep1"], self.customer1,
                                             [(self.mouse, self.bin_a, 4),
                                              (self.keyboard, self.bin_a, 1)])
        self.assertEqual(self.app.inventory.on_hand(self.mouse, self.bin_a), 46)
        self.assertEqual(self.app.dispatch.get_note(note)["status"], "ISSUED")
        self.assertEqual(len(self.app.dispatch.note_lines(note)), 2)

    def test_note_with_too_much_quantity_changes_nothing(self):
        with self.assertRaises(BusinessRuleError):
            self.app.dispatch.create_note(self.users["rep1"], self.customer1,
                                          [(self.mouse, self.bin_a, 2),
                                           (self.keyboard, self.bin_a, 99)])
        self.assertEqual(self.app.inventory.on_hand(self.mouse, self.bin_a), 50)
        self.assertEqual(self.app.dispatch.list_notes(self.users["admin"]), [])

    def test_rep_cannot_ship_to_another_reps_customer(self):
        with self.assertRaises(PermissionDeniedError):
            self.app.dispatch.create_note(self.users["rep2"], self.customer1,
                                          [(self.mouse, self.bin_a, 1)])

    def test_return_resubmit_approve(self):
        dispatch = self.app.dispatch
        note = dispatch.create_note(self.users["rep1"], self.customer1,
                                    [(self.mouse, self.bin_a, 1)])
        dispatch.return_to_sales(self.users["manager"], note, "Missing PO number")
        self.assertEqual(dispatch.get_note(note)["review_note"], "Missing PO number")
        dispatch.resubmit(self.users["rep1"], note, "PO 123")
        dispatch.approve(self.users["manager"], note)
        self.assertEqual(dispatch.get_note(note)["status"], "APPROVED")

    def test_void_restores_stock(self):
        note = self.app.dispatch.create_note(self.users["rep1"], self.customer1,
                                             [(self.mouse, self.bin_a, 10)])
        self.app.dispatch.void(self.users["manager"], note, "Order cancelled")
        self.assertEqual(self.app.inventory.on_hand(self.mouse, self.bin_a), 50)
        with self.assertRaises(BusinessRuleError):
            self.app.dispatch.approve(self.users["manager"], note)

    def test_sales_rep_only_sees_own_notes(self):
        self.issue_and_approve(self.customer1, rep="rep1")
        self.issue_and_approve(self.customer2, rep="rep2")
        self.assertEqual(len(self.app.dispatch.list_notes(self.users["rep1"])), 1)
        self.assertEqual(len(self.app.dispatch.list_notes(self.users["manager"])), 2)


class BillingTests(AppTestCase):

    def test_price_comes_from_list_valid_on_the_invoice_date(self):
        billing, acct = self.app.billing, self.users["acct"]
        billing.set_price(acct, self.price_list, self.mouse, "9.00", dt.date(2026, 1, 1))
        billing.set_price(acct, self.price_list, self.mouse, "11.00", dt.date(2026, 4, 1))
        self.assertEqual(billing.effective_price(self.price_list, self.mouse,
                                                 dt.date(2026, 3, 15)), 900)
        self.assertEqual(billing.effective_price(self.price_list, self.mouse,
                                                 dt.date(2026, 4, 1)), 1100)
        self.assertEqual(len(billing.price_history(self.price_list, self.mouse)), 2)
        # Items without a list price fall back to the item's base price.
        self.assertEqual(billing.effective_price(self.price_list, self.keyboard,
                                                 dt.date(2026, 3, 15)), 4000)

    def test_invoice_totals_tax_and_note_status(self):
        note = self.issue_and_approve(quantity=4)
        invoice_id = self.invoice([note])
        invoice = self.app.billing.get_invoice(invoice_id)
        self.assertEqual(invoice["subtotal"], 4000)          # 4 x $10.00
        self.assertEqual(invoice["tax_amount"], 330)         # 8.25 %
        self.assertEqual(invoice["total"], 4330)
        self.assertEqual(invoice["due_date"], "2026-04-01")  # 30 days of credit
        self.assertEqual(self.app.dispatch.get_note(note)["status"], "INVOICED")

    def test_edited_price_is_flagged(self):
        note = self.issue_and_approve(quantity=2)
        acct = self.users["acct"]
        draft = self.app.billing.build_draft(acct, self.customer1, [note])
        draft.lines[0].unit_price = 850
        invoice_id = self.app.billing.create_invoice(acct, draft)
        line = self.app.billing.invoice_lines(invoice_id)[0]
        self.assertEqual((line["unit_price"], line["price_overridden"]), (850, 1))

    def test_cannot_invoice_unapproved_or_foreign_notes(self):
        acct = self.users["acct"]
        issued = self.app.dispatch.create_note(self.users["rep1"], self.customer1,
                                               [(self.mouse, self.bin_a, 1)])
        with self.assertRaises(BusinessRuleError):
            self.app.billing.build_draft(acct, self.customer1, [issued])
        other = self.issue_and_approve(self.customer2, rep="rep2")
        with self.assertRaises(BusinessRuleError):
            self.app.billing.build_draft(acct, self.customer1, [other])

    def test_note_cannot_be_invoiced_twice(self):
        note = self.issue_and_approve()
        acct = self.users["acct"]
        draft = self.app.billing.build_draft(acct, self.customer1, [note])
        self.app.billing.create_invoice(acct, draft)
        with self.assertRaises(BusinessRuleError):
            self.app.billing.create_invoice(acct, draft)

    def test_void_invoice_releases_notes(self):
        note = self.issue_and_approve()
        invoice_id = self.invoice([note])
        self.app.billing.void_invoice(self.users["acct"], invoice_id, "Wrong customer")
        self.assertEqual(self.app.billing.get_invoice(invoice_id)["status"], "VOID")
        self.assertEqual(self.app.dispatch.get_note(note)["status"], "APPROVED")

    def test_invoice_with_payments_cannot_be_voided(self):
        invoice_id = self.invoice([self.issue_and_approve()])
        self.app.receivables.record_payment(self.users["acct"], invoice_id, "10", "Card")
        with self.assertRaises(BusinessRuleError):
            self.app.billing.void_invoice(self.users["acct"], invoice_id, "Wrong customer")
